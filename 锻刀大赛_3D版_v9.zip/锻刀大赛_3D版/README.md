# 锻刀大赛_3D版

独立的新版本：逻辑以《锻刀大赛_玩法设定案_V3.md》为基准，当前 2.0(2) 的成熟数据作为兼容基础，3D 主视觉采用现有 BladeSkin 引擎。

## 资产映射
- 原料：`assets/materials/ore_small.glb`
- 熔炼：`assets/materials/molten_sphere_small.glb`
- 胚体：`assets/materials/blank_ingot_small.glb`
- 成刀：现有 12 把原创 3D 刀模型
- 刀身材质：BladeSkin M01–M24
- 锻打纹理：T01–T12
- 淬火/工艺：F01–F12

## 玩法闭环
HOME → FORGE → 原料 → 熔炼 → 锻打+HAMMER → 定型 → 淬火+QUENCH → 回火 → 开刃 → 装配 → FINAL TUNE → 鉴定 → 藏刀 → CIRCUIT → 比赛 → 奖励/断刀 → 回到下一次锻刀。

## 运行
- 双击 `index.html` 可直接启动；项目保留 `bundle.inline.js`，用于 file:// 下的 3D 模型/HDR 内联兜底。
- 也可以在目录下执行：`python -m http.server 8899`，然后打开 `http://127.0.0.1:8899/`。

## 当前已实现

- 9 阶 FORGE：原料 → 熔炼 → 锻打 → 定型 → 淬火 → 回火 → 开刃 → 装配 → 最终调校。
- 3 个锻刀小游戏：HAMMER / QUENCH / FINAL TUNE；小游戏只提供有限修正。
- Risk 会在关键小游戏结算时进行确定性 BREAK CHECK；高风险可能直接终止本局，并记录失败状态。
- 组合发现：沿用当前数据中的 30 组组合条件，发现后写入成刀记录并授予对应 Trait。
- 成刀保存材料、六维、Forge Trait、材料 Trait、组合、锻造路径、外观配方、风险峰值和赛事记录。
- 赛事：SCHOOL TRIALS / NATIONAL CHAMPIONSHIP / GLOBAL APEX；POWER / CONTROL / ART 三回合，2:1 胜负。
- POWER / CONTROL / ART 各准备 3 种短小游戏模板；GLOBAL 的变化规则在整场比赛内固定。
- 失败后进入 BREAK CHECK；刀可断裂，也可能保留并累积 Loss Count。
- 赛事奖励可逐步解锁 Match Trait 与 Forge Trait。

## 验证

`tools/smoke_vm.js` 为逻辑层烟测：会验证 12 刀模型、60 材料、164 工艺卡、30 组合/特性数据、确定性 RNG、隐藏组合发现、Risk BREAK CHECK 与 POWER / CONTROL / ART 对手结构。浏览器真实渲染仍建议在本机 Chrome/Edge 中打开 `index.html` 或 HTTP 地址检查显卡/浏览器差异。

## 当前默认决策
1. 9 阶锻刀流程继续采用：原料 + 8 个工艺阶段。
2. 3 个关键锻刀小游戏：HAMMER / QUENCH / FINAL TUNE。
3. 赛事正式使用 POWER / CONTROL / ART，固定 3 回合。
4. Forge Trait 与 Match Trait 分离。
5. 失败后进入 BREAK CHECK，保留 Loss Count。
6. 当前用户消息没有实际附上名为“锻刀大赛原型.html”的文件，因此暂以当前 `锻刀大赛2.0(2).html` 与现有视觉测试页作为原型兼容基础；不会覆盖原工程。

## 兼容性说明
3D 渲染层与玩法数据层分离：后续可以单独替换模型、皮肤参数或数值，而不用重写流程。

## V3 继续完善
- 修复藏刀阁 3D Inspector 的 Viewer 容器定位：支持显式 host，避免抢到锻造页的 `.stage3d`。
- 锻造小游戏阶段的 3D 演出按实际阶段传递 `stage`，避免 `mini_forge` / `mini_quench` 被误判为最终鉴定效果。
- 扩展轻量阶段 FX：定型、淬火、回火、开刃、装配、调校、鉴定均有不同光效/粒子反馈。
- 保持 Viewer 只负责视觉呈现，属性、风险、配方与比赛判定仍由数据层控制。
- 回归检查：`node --check js/game.js`、`node tools/smoke_vm.js`、ZIP 完整性检查均通过。

## v4 赛事循环更新

- 六大流派试炼开始真正参与胜负计算：流派 Focus 会强化对应检验，同时让对应方向的对手更具针对性。
- 全国大赛晋级节点写入存档：资格赛 → 32强 → 16强 → 8强 → 半决赛 → 决赛，刷新页面后仍可继续。
- 全国冠军状态写入存档。
- 六大流派分别累计胜场。
- 全球巅峰赛累计独立胜场，并使用更高基础奖励。
- 旧版存档自动补充 `circuit` 数据结构，不需要手动清档。

## V5 长期养成更新

- 新增每把成刀的 `Mastery / 刀魂熟练度`。
- 赛事胜利获得 +10 刀魂，失败获得 +3 刀魂。
- 刀魂每 25 点提升一级，最高 6 级；等级只提供小幅 1.2%/级的赛事三维表现加成，不覆盖材料/工艺 Build。
- 刀魂等级对应称号：新铸 → 初露锋芒 → 百战淬锋 → 名匠之刃 → 宗师佩刃 → 传世名锋 → 神兵。
- 藏刀阁展示每把刀的刀魂、等级、称号。
- 赛事结算展示本场刀魂收益。
- 流派胜场、全球胜场、全国冠军状态继续持久化。
- 旧存档会自动补齐 `mastery` 与 `title` 字段。
