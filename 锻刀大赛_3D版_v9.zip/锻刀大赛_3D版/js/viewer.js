/* Knife3D · viewer.js
 * 3D 舞台：4:5 竖版画布、拖拽旋转 / 双指缩放、一键还原、缩略图快照。
 */
(function (global) {
'use strict';
const K3D = (global.K3D = global.K3D || {});
const THREE = global.THREE;

/**
 * 各刀型默认额外 Y 轴偏转（弧度）。
 * 正值 = 往右转，负值 = 往左转，0 = 不转。
 * 可按需在此补充，避免在 app.js 里硬编码刀型 ID 列表。
 */
const KNIFE_VIEW_ANGLE_Y = {
  knife_balisong: 0,   // 蝴蝶刀：保持默认朝向（开合面朝向相机）
  // 其余刀型使用全局默认 -15°
};
const DEFAULT_VIEW_ANGLE_Y = 0; // 所有其他模型：往后转15°（负值=往左转）

class Viewer {
  constructor(container) {
    this.container = container;
    this.disposed = false;
    this.root = null;
    this.modelSize = null;
    this.fitDistance = 1;
    this.needsRender = true;
    this.renderUntil = 0;

    const rect = container.getBoundingClientRect();
    const w = Math.max(1, rect.width), h = Math.max(1, rect.height);

    this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'high-performance' });
    // 移动端 4:5 舞台：DPR 1.5 足够保持锐度，同时明显降低 fill-rate。桌面端允许到 2。
    const dprCap = /Mobi|Android|iPhone|iPad/i.test(global.navigator?.userAgent || '') ? 1.5 : 2;
    this.renderer.setPixelRatio(Math.min(global.devicePixelRatio || 1, dprCap));
    this.renderer.setSize(w, h, false);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.9;
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(42, w / h, 0.01, 500);
    this.camera.position.set(0, 0.6, 3);

    this.pivot = new THREE.Group();
    this.scene.add(this.pivot);

    this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.enablePan = false;
    this.controls.rotateSpeed = 0.85;
    this.controls.zoomSpeed = 0.9;
    this.controls.autoRotate = false;
    this.controls.autoRotateSpeed = 1.6;
    this.controls.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_ROTATE };
    // OrbitControls 阻尼阶段需要连续几帧；静止时则完全不需要持续重绘。
    this.controls.addEventListener('change', () => this.invalidate(260));
    this.controls.addEventListener('start', () => this.invalidate(900));
    this.controls.addEventListener('end', () => this.invalidate(260));

    this.keyLight = new THREE.DirectionalLight(0xffffff, 1.4);
    this.keyLight.position.set(2.2, 3, 2.4);
    this.scene.add(this.keyLight);
    this.fillLight = new THREE.DirectionalLight(0xd4e0f0, 0.6);
    this.fillLight.position.set(-2.4, 0.6, -2);
    this.scene.add(this.fillLight);
    // 背面补光：从相机后方打光，让刀身另一面不被完全照黑
    this.backLight = new THREE.DirectionalLight(0xffffff, 0.5);
    this.backLight.position.set(0, 1, -3.5);
    this.scene.add(this.backLight);

    this.maxAnisotropy = this.renderer.capabilities.getMaxAnisotropy();
    this.clock = new THREE.Clock();
    this.renderer.setAnimationLoop(() => this._render());

    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(container);
    this.resize();
    // HDR 环境不在这里自动加载：file:// 模式下内联包（K3D_INLINE）由 engine.init()
    // 按需注入，构造时通常还不存在 —— 由 app.boot() 在 init 之后显式调用 loadEnvironment()
  }

  /**
   * 把 envMap 显式挂到场景内所有材质上。
   * 原因：three r169 在 `material.envMap === null && scene.environment` 时会用
   * `scene.environmentIntensity` 直接覆盖着色器的 envMapIntensity uniform，
   * 导致材质的 `envMapIntensity`（即"反射强度"滑块）完全失效。
   * 显式挂载后走 `material.envMapIntensity` 分支，材质级控制才生效。
   */
  _applyEnvMapToScene() {
    if (!this.envMap) return;
    this.scene.traverse((o) => {
      if (!o.isMesh) return;
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      for (const m of mats) {
        if (!m) continue;
        m.envMap = this.envMap;
        m.needsUpdate = true;
      }
    });
  }

  async loadEnvironment(url = 'assets/environment.hdr') {
    try {
      let src = url;
      if (global.location.protocol === 'file:' && global.K3D_INLINE && global.K3D_INLINE.hdr) {
        src = 'data:application/octet-stream;base64,' + global.K3D_INLINE.hdr;
      }
      const hdr = await new THREE.RGBELoader().loadAsync(src);
      if (this.disposed) return;
      hdr.mapping = THREE.EquirectangularReflectionMapping;
      const pmrem = new THREE.PMREMGenerator(this.renderer);
      this.envMap = pmrem.fromEquirectangular(hdr).texture;
      this.scene.environment = this.envMap;
      if ('environmentIntensity' in this.scene) this.scene.environmentIntensity = 0.55;
      hdr.dispose(); pmrem.dispose();
      // ⚠ three r169：用 scene.environment 时着色器取 scene.environmentIntensity，
      //   材质的 envMapIntensity 被忽略 → 必须把 envMap 显式挂到每个材质上，
      //   材质级的「反射强度」才生效。通知外部（engine）挂载。
      this._applyEnvMapToScene();
      if (this.onEnvMapReady) this.onEnvMapReady(this.envMap);
      this.needsRender = true;
    } catch (e) {
      // 环境贴图缺失只影响反射质感，不阻塞
    }
  }

  invalidate(ms = 0) {
    this.needsRender = true;
    if (ms > 0) this.renderUntil = Math.max(this.renderUntil, performance.now() + ms);
  }

  _render() {
    if (this.disposed) return;
    if (document.hidden && !this.needsRender) return;
    const now = performance.now();
    const animated = this.controls.autoRotate || now < this.renderUntil;
    if (!this.needsRender && !animated) return;
    this.controls.update();
    this.renderer.render(this.scene, this.camera);
    this.needsRender = false;
  }

  resize() {
    if (this.disposed) return;
    const rect = this.container.getBoundingClientRect();
    const w = Math.max(1, rect.width), h = Math.max(1, rect.height);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
    if (this.modelSize) {
      const current = this.camera.position.distanceTo(this.controls.target);
      const wasAtFit = !this.fitDistance || Math.abs(current - this.fitDistance) < this.fitDistance * 0.05;
      this._computeFit();
      if (wasAtFit) this.resetView();
    }
    this.invalidate();
  }

  /**
   * 放入一个已加载的 gltf.scene。
   * @param {string} [knifeId] - 可选的刀型 ID，用于从 KNIFE_VIEW_ANGLE_Y 查默认偏转角。
   *   蝴蝶刀不转（默认开合面朝向），其余刀型默认 +45° 偏转展示刀身厚度。
   */
  setModel(root, knifeId) {
    this._clearModel();
    const box = new THREE.Box3().setFromObject(root);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    root.position.sub(center);

    // 让刀身长边朝屏幕「竖直」方向 —— 舞台是 4:5 竖版，竖放才能填满画面。
    // （GLB 的朝向因导出工具而异：自制的长轴多在 x/z，CS 模型节点自带 -90° 旋转后
    //   长轴落在 y。三条分支都要归一化到"竖直"，不能只处理其中一种。）
    const axis = size.x >= size.y && size.x >= size.z ? 'x' : size.y >= size.z ? 'y' : 'z';
    this.pivot.rotation.set(0, 0, 0);
    if (axis === 'x') this.pivot.rotation.z = Math.PI / 2;        // x 长轴 → 转竖直
    else if (axis === 'z') this.pivot.rotation.x = -Math.PI / 2;  // z 长轴 → 转竖直
    // axis === 'y'：本身就竖直，无需旋转
    this.pivot.add(root);
    // 游戏坐标系朝向相反，绕 Y 轴翻转（与参考站一致）
    this.pivot.rotation.y += Math.PI;
    // 可选额外 Y 轴偏转：蝴蝶刀不转（开合面朝向），其余刀型默认 +180° 翻转刀身
    // 用四元数做复合旋转，避免欧拉角加法被 THREE.js 归一化（π+π≡0 导致无效）
    const viewAngleY = KNIFE_VIEW_ANGLE_Y[knifeId] ?? DEFAULT_VIEW_ANGLE_Y;
    if (viewAngleY !== 0) {
      const q = new THREE.Quaternion();
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), viewAngleY);
      this.pivot.quaternion.multiply(q);
    }
    // 记录「摆正后的基准姿态」，供 resetView 恢复（别丢 x/z 的摆正分量）
    this.baseRotation = this.pivot.rotation.clone();
    // 记录 Y 轴偏转量，供 resetView 决定相机在哪一侧（前/后）
    this.baseViewAngleY = viewAngleY;

    this.root = root;
    this.modelSize = size;
    this._computeFit();
    this.resetView();
    this.needsRender = true;
  }

  _computeFit() {
    // 长边已归一化为「竖直」→ 纵向用最长边 dims[0]，横向用次长边 dims[1]
    const dims = [this.modelSize.x, this.modelSize.y, this.modelSize.z].sort((a, b) => b - a);
    const halfFov = THREE.MathUtils.degToRad(this.camera.fov / 2);
    const aspect = Math.max(0.2, this.camera.aspect);
    const distV = (dims[0] / 2) / Math.tan(halfFov);
    const distH = (dims[1] / 2) / (Math.tan(halfFov) * aspect);
    this.fitDistance = Math.max(distV, distH) * 1.18;
    this.camera.near = Math.max(dims[0] * 0.005, 0.001);
    this.camera.far = dims[0] * 80;
    this.camera.updateProjectionMatrix();
    this.controls.minDistance = this.fitDistance * 0.32;
    this.controls.maxDistance = this.fitDistance * 3.2;
  }

  /** 一键还原：恢复「摆正后的基准姿态」+ 默认机位。 */
  resetView() {
    if (!this.fitDistance) return;
    // ⚠ 必须恢复 baseRotation，不能只留 y —— 长轴在 x/z 的模型靠 z/x 分量摆正，
    //   清掉它们会让刀变回横放（曾导致"CS 模型竖着、新模型横着"的不一致）
    if (this.baseRotation) this.pivot.rotation.copy(this.baseRotation);
    else this.pivot.rotation.set(0, this.pivot.rotation.y, 0);
    // 相机根据刀朝向自动切换前/后：
    // viewAngleY ≈ 0   → 刀尖朝相机，相机在负 Z 侧（正面）
    // viewAngleY ≈ π   → 刀尖远离相机，相机在正 Z 侧（背面）
    const camZ = (this.baseViewAngleY > Math.PI * 0.5) ? 1.0 : -1.0;
    // 默认视角：正对模型中心，无俯仰、无侧偏
    this.camera.position.set(0, 0, this.fitDistance * camZ);
    this.controls.target.set(0, 0, 0);
    this.controls.update();
    this.invalidate();
  }

  setAutoRotate(on) { this.controls.autoRotate = !!on; this.invalidate(); }
  setExposure(v) { this.renderer.toneMappingExposure = Math.min(2.5, Math.max(0.3, v)); this.invalidate(); }

  /** 渲染一帧并导出 dataURL（用于刀型卡片缩略图）。 */
  snapshot(w = 160, h = 120) {
    const oldSize = new THREE.Vector2();
    this.renderer.getSize(oldSize);
    const oldPR = this.renderer.getPixelRatio();
    this.renderer.setPixelRatio(1);
    this.renderer.setSize(w, h, false);
    const aspect = w / h;
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
    this.renderer.render(this.scene, this.camera);
    const url = this.renderer.domElement.toDataURL('image/webp', 0.8);
    this.renderer.setPixelRatio(oldPR);
    this.renderer.setSize(oldSize.x, oldSize.y, false);
    this.camera.aspect = oldSize.x / Math.max(1, oldSize.y);
    this.camera.updateProjectionMatrix();
    this.needsRender = true;
    return url;
  }

  _clearModel() {
    if (this.root) {
      this.pivot.remove(this.root);
      // Knife roots cached by Engine are shared/reused across stage changes.
      // Do not dispose their geometry/materials here; disposing them would leave
      // Engine.loaded pointing at already-disposed GPU resources. Stage-only GLBs
      // do not carry this ownership flag and are still disposed normally.
      if (!this.root.userData?.k3dEngineOwned) this._disposeObject(this.root);
      this.root = null;
    }
  }

  _disposeObject(obj) {
    obj.traverse((c) => {
      if (c.isMesh) {
        c.geometry && c.geometry.dispose();
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach((m) => m && m.dispose());
      }
    });
  }

  dispose() {
    this.disposed = true;
    this.renderer.setAnimationLoop(null);
    this.resizeObserver && this.resizeObserver.disconnect();
    this._clearModel();
    this.envMap && this.envMap.dispose();
    this.controls && this.controls.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}

K3D.Viewer = Viewer;

if (typeof module !== 'undefined' && module.exports) module.exports = { Viewer };
})(typeof window !== 'undefined' ? window : globalThis);
