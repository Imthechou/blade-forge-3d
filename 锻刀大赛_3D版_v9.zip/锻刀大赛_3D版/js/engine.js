/* Knife3D · engine.js
 * 组合层：模型清单加载（双协议）→ GLB 加载 → atlas 生成与缓存 → 皮肤应用。
 *
 * 资源通路（与 cs2-knife-viewer 同款）：
 *   file://  → 注入 js/bundle.inline.js（manifest + 模型 base64 + HDR base64）
 *   http(s):// → 直接 fetch models/manifest.json 与原始文件
 */
(function (global) {
'use strict';
const K3D = (global.K3D = global.K3D || {});
const THREE = global.THREE;
const skins = K3D.skins;
const mat = K3D.material;

const ATLAS_SIZE = 1024;
// 图案索引滑动会不断生成新 seed 的 atlas（每张 1024²×2 贴图 ≈ 8 MB 显存），
// 用 LRU 上限防堆叠。淘汰的最旧图集当前材质已不引用（引用还在调用方手上，安全）。
const ATLAS_CACHE_LIMIT = 6;    // 1024² atlas 每组约 8–12MB GPU；移动端控制在约 72MB 上限量级
const MAX_KNIFE_CACHE = 4;
const scriptCache = new Map();

function loadScriptOnce(src) {
  if (scriptCache.has(src)) return scriptCache.get(src);
  const existing = document.querySelector(`script[src="${src}"]`);
  if (existing) { scriptCache.set(src, Promise.resolve(true)); return scriptCache.get(src); }
  const p = new Promise((resolve, reject) => {
    const el = document.createElement('script');
    el.src = src; el.async = true;
    el.onload = () => resolve(true);
    el.onerror = () => reject(new Error('inline bundle 加载失败：' + src));
    document.head.appendChild(el);
  });
  scriptCache.set(src, p);
  return p;
}

function isFileProtocol() {
  return global.location && global.location.protocol === 'file:';
}

function base64ToBuffer(b64) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes.buffer;
}

/* ---------------------------------------------------------------- 引擎 */

class Engine {
  constructor() {
    this.knives = [];               // manifest 条目
    this.loaded = new Map();        // id -> {root, materials, geometryData, maps}
    this.loading = new Map();     // id -> Promise，避免同一刀型并发重复解析 GLB
    this.atlasCache = new Map();
    this.atlasRefs = new Map();   // key -> 当前已挂到材质上的引用数，LRU 不能淘汰这些纹理
    this.atlasByKnife = new Map();    // `${id}:${skin}` -> {colorTex, metalTex, stats}
    this.listeners = { status: [], error: [] };
    this.loader = new THREE.GLTFLoader();
  }

  onStatus(fn) { this.listeners.status.push(fn); }
  onError(fn) { this.listeners.error.push(fn); }
  _status(msg) { this.listeners.status.forEach((f) => f(msg)); }
  _error(msg) { this.listeners.error.forEach((f) => f(msg)); }

  /** 加载模型清单：file:// 用内联，http 用 fetch。 */
  async init() {
    if (isFileProtocol()) {
      try { await loadScriptOnce('js/bundle.inline.js'); } catch (e) { /* 走 fetch 兜底 */ }
    }
    const inline = global.K3D_INLINE;
    if (inline && inline.manifest) {
      this.knives = inline.manifest.knives || [];
      this.inline = inline;
    } else {
      const res = await fetch('assets/models/manifest.json');
      const data = await res.json();
      this.knives = data.knives || [];
    }
    this._status({ stage: 'manifest', count: this.knives.length });
    return this.knives;
  }

  async _loadGlb(url) {
    if (isFileProtocol() && this.inline && this.inline.models && this.inline.models[url]) {
      const buf = base64ToBuffer(this.inline.models[url]);
      return await new Promise((resolve, reject) => this.loader.parse(buf, '', resolve, reject));
    }
    return await this.loader.loadAsync(url);
  }

  /** 加载一把刀：解析几何、快照原版材质。 */
  async loadKnife(id) {
    const entry = this.knives.find((k) => k.id === id);
    if (!entry) throw new Error('未找到刀型：' + id);
    if (this.loaded.has(id)) {
      const info=this.loaded.get(id); info.lastUsed=performance.now(); return info;
    }
    if (this.loading.has(id)) return this.loading.get(id);

    const task=(async()=>{
      this._status({ stage: 'knife', id, message: '模型加载中…' });
      const gltf = await this._loadGlb(entry.file);
    const root = gltf.scene;
    // Engine owns cached knife roots. Viewer may move them between stage hosts,
    // but must never dispose their GPU resources while they remain cached here.
    root.userData = root.userData || {};
    root.userData.k3dEngineOwned = true;
    const materials = [];
    const maps = [];

    root.traverse((child) => {
      if (!child.isMesh || !child.material) return;
      const convert = (m) => {
        const p = mat.toPhysicalMaterial(m);
        // 显式挂 envMap：否则 three 会用 scene.environmentIntensity 覆盖
        // 材质的 envMapIntensity，导致「反射强度」滑块失效（r169 行为）
        if (this.envMap) p.envMap = this.envMap;
        p.userData.orig = {
          map: p.map, metalnessMap: p.metalnessMap, roughnessMap: p.roughnessMap,
          normalMap: p.normalMap,
          normalScale: p.normalScale ? p.normalScale.clone() : new THREE.Vector2(1, 1),
          roughness: p.roughness, metalness: p.metalness,
          envMapIntensity: p.envMapIntensity,
          color: p.color.clone(), clearcoat: 0, clearcoatRoughness: 0.1,
        };
        materials.push(p);
        return p;
      };
      child.material = Array.isArray(child.material) ? child.material.map(convert) : convert(child.material);
      maps.push(child);
    });

    const meshChild = (function find(node) {
      let found = null;
      node.traverse((c) => { if (!found && c.isMesh) found = c; });
      return found;
    })(root);

    const geo = meshChild.geometry;
    const idx = geo.index ? geo.index.array : null;
    const meshData = {
      positions: geo.attributes.position.array,
      normals: geo.attributes.normal ? geo.attributes.normal.array : null,
      uvs: geo.attributes.uv ? geo.attributes.uv.array : null,
      index: idx,
    };
    if (!meshData.index) {
      const n = meshData.positions.length / 3;
      const arr = new Uint32Array(n);
      for (let i = 0; i < n; i++) arr[i] = i;
      meshData.index = arr;
    }

    // ── 三区域顶点属性 aRegion（方案 v2 §3.2 主方案）──
    // vec3 One-Hot：r=刀身 / g=护手+尾部 / b=刀柄。用顶点属性而非纹理，
    // 不依赖 Packed UV、不增加纹理采样、不会因 UV 岛重叠误分区。
    // 边界取 js/regions.js 的固定值（逐刀配），两端用 FEATHER 做软过渡。
    this._buildRegionAttribute(geo, id);

    // ── 刀身局部坐标系（BladeSkin 程序化纹理的采样域，见 js/skin/shader/*）──
    // 不同刀型的最长轴可能落在 X/Y/Z 任一条上，先在 CPU 侧统一成
    // (长轴, 次长轴, 第三轴) 的局部坐标，shader 里才能用同一套参数化。
    const bladeFrame = this._buildBladeFrame(geo);
    // 模型自带基础色贴图（Wear 露底材用；必须在 applySkin 覆盖 map 之前保存引用）
    let baseMap = null;
    for (const m of materials) { if (!baseMap && m.userData.orig && m.userData.orig.map) baseMap = m.userData.orig.map; }

    const info = {
      id, entry, root, materials, meshData,
      maps: null,   // 延迟提取（首次生成 atlas 时）
      bladeFrame, baseMap,
    };
      info.lastUsed=performance.now();
      this.loaded.set(id, info);
      this._evictKnifeCache(id);
      this._status({ stage: 'knife-ready', id });
      return info;
    })();
    this.loading.set(id, task);
    try { return await task; } finally { this.loading.delete(id); }
  }

  /** 刀身局部坐标系：轴 = 包围盒三边按长度排序（长轴/次长轴/第三轴），原点 = 包围盒 min。
   *  返回 { basis(Matrix3, 行 = 各轴 → M·v 得到局部坐标), origin, span(局部序跨度) } */
  _buildBladeFrame(geo) {
    const pos = geo.attributes.position.array;
    const n = pos.length / 3;
    let mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < n; i++) {
      for (let d = 0; d < 3; d++) {
        const v = pos[i * 3 + d];
        if (v < mn[d]) mn[d] = v;
        if (v > mx[d]) mx[d] = v;
      }
    }
    const size = [mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]];
    const order = [0, 1, 2].sort((a, b) => size[b] - size[a]);   // 长轴 → 次长 → 第三
    // 行 i = 第 i 长的轴单位向量（行主序 set）
    const rows = [];
    for (let i = 0; i < 3; i++) {
      const r = [0, 0, 0];
      r[order[i]] = 1;
      rows.push(r);
    }
    const basis = new THREE.Matrix3().set(
      rows[0][0], rows[0][1], rows[0][2],
      rows[1][0], rows[1][1], rows[1][2],
      rows[2][0], rows[2][1], rows[2][2],
    );
    return {
      basis,
      origin: new THREE.Vector3(mn[0], mn[1], mn[2]),
      span: new THREE.Vector3(size[order[0]], size[order[1]], size[order[2]]),
      axisOrder: order,
    };
  }

  /**
   * 应用 BladeSkin（Material × Texture × Finish × Wear × Seed）到**刀身**。
   * 只写刀身：材质层的 PBR 属性（three 原生） + bladeSkin shader 注入；
   * 护手 / 刀柄的判定与观感一律不动（那两块仍由 regions + 旧 handle/guard 通道负责）。
   */
  applyBladeSkin(knifeId, pack, opts = {}) {
    K3D.activeKnifeId = knifeId;
    const info = this.loaded.get(knifeId);
    if (!info || !pack) return null;
    const M = pack.material;
    const frame = info.bladeFrame;
    let applied = null;
    for (const m of info.materials) {
      // 区域顶点属性（aRegion/aBladeT/aEdge）的声明必须存在（bladeAttrs hook）
      if (K3D.material && K3D.material.setBladeAttrs) K3D.material.setBladeAttrs(m);
      // ① 材质层：只用**能被区域遮罩住**的原生属性（保证护手/刀柄一点不被影响）
      //    ✔ metalness / roughness / clearcoat / iridescence —— 前两个由本系统的
      //      metalness/roughnessFragment 按 wB 混合，后两个由旧系统 physicalFragment
      //      钩子对 wG/wH 归零
      //    ✘ 刻意不设：emissive（会整把发光 → 改由 shader 侧只对刀身加）、
      //      transmission / ior（材质级，会作用到护手刀柄）、envMapIntensity（同上）、
      //      anisotropy（r169 无区域遮罩）。这三项改用别的方式表达，见下方注释。
      m.metalness = M.metalness;
      m.roughness = M.roughness;
      if ('clearcoat' in m) { m.clearcoat = M.clearcoat; m.clearcoatRoughness = M.clearcoatRoughness; }
      if ('iridescence' in m) {
        m.iridescence = pack.uniforms.uBladeIridescence;      // 已按 wear 衰减（§9.10）
        m.iridescenceIOR = M.iridescenceIOR;
        if (M.iridescenceThickness) m.iridescenceThicknessRange = M.iridescenceThickness;
      }
      // ② 纹理 / 工艺 / 多普勒 / Wear / 发光 走 shader 注入（全部只在 wB 区生效）
      K3D.bladeSkinShader.apply(m, pack, frame, {
        baseMap: info.baseMap,
        texStrength: opts.texStrength != null ? opts.texStrength : 1.0,
      });
      mat.invalidateHookProgram(this.renderer, m);
      applied = m;
    }
    return applied;
  }

  /** 从 three 贴图的 image 提取像素（走 offscreen canvas）。 */
  _pixelSource(texture) {
    if (!texture || !texture.image) return null;
    const img = texture.image;
    const w = img.width, h = img.height;
    if (!w || !h) return null;
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(img, 0, 0);
    const data = ctx.getImageData(0, 0, w, h).data;
    return { w, h, data, channels: 4 };
  }

  /** 提取模型自带贴图（ORM + baseColor），缓存到 info.maps。 */
  _ensureMaps(info) {
    if (info.maps) return info.maps;
    let orm = null, baseColor = null;
    for (const m of info.materials) {
      if (!orm && m.metalnessMap) orm = this._pixelSource(m.metalnessMap);
      if (!baseColor && m.map) baseColor = this._pixelSource(m.map);
    }
    info.maps = { orm, baseColor };
    // 有 ORM 后重建一次区域顶点属性：用金属度在护手带内精修（真刀护手是金属件）
    try {
      const mesh = (() => { let g = null; info.root.traverse((o) => { if (!g && o.isMesh) g = o; }); return g; })();
      if (mesh && orm) this._buildRegionAttribute(mesh.geometry, info.id, orm);
    } catch (e) { /* 区域重建失败不影响主流程 */ }
    return info.maps;
  }

  /** 生成（或取缓存）某刀某皮肤的 atlas。patternIndex 按 CSGO 两级结构映射成噪声种子。 */
  async ensureAtlas(knifeId, skinId, patternIndex = 0, handleMaterialId = null, texParams = null) {
    const seed = mapPatternSeed(patternIndex);
    const hmId = handleMaterialId || 'polymer';
    // 纹理参数（方案 §44 交互参数）：缩放/旋转/偏移 —— 烘焙进 atlas，必须进缓存 key
    const tp = texParams || {};
    const tpKey = [tp.scale, tp.rotation, tp.offsetU, tp.offsetV, tp.warp, tp.contrast, tp.fadeShift, tp.fadeSpan, tp.phase]
      .map((v) => (v === undefined || v === null ? '-' : Number(v).toFixed(3))).join(',');
    // ⚠ 刀柄材质是烘焙进 atlas 的，必须进缓存 key，否则换材质会命中旧缓存不生效
    // ⚠ region 边界（bladeStart/guardStart/angle）也烘焙进 atlas 的刀身 mask，必须进 key，
    //    否则调边界后命中旧缓存 → 覆盖线不跟着走。
    // ⚠ 线外浅铺 SKIRT/BLEED 同样参与烘焙 mask，也必须进 key（改常量后必须重烘焙）。
    const regionKey = (() => {
      const rg = (K3D.regions && K3D.regions.of) ? K3D.regions.of(knifeId) : null;
      if (!rg) return '';
      const n3 = (v) => (v == null ? '-' : Number(v).toFixed(3));
      return n3(rg.bladeStart) + '/' + n3(rg.guardStart) + '/' + ((rg.angle || 0)) + '/' +
             n3(K3D.regions.SKIRT) + '/' + n3(K3D.regions.BLEED) + '/' + n3(K3D.regions.PATTERN_EXTEND);
    })();
    const key = knifeId + ':' + skinId + ':' + seed + ':' + hmId + ':' + tpKey + ':' + regionKey;
    const cached = this.atlasCache.get(key);
    if (cached) {
      // LRU 碰触：移到队尾，防止正在用的被误逐
      this.atlasCache.delete(key);
      this.atlasCache.set(key, cached);
      this._evictAtlas();
      return cached;
    }
    // ── 持久化命中（IndexedDB）：上次会话烘好的直接复用，跳过 ~770ms 烘焙 ──
    if (K3D.AtlasStore) {
      const rec = await K3D.AtlasStore.get(key);
      if (rec && rec.ver === K3D.AtlasStore.VER && rec.color) {
        const entry = this._entryFromRecord(rec, key);
        if (entry) return entry;
      }
    }

    const info = await this.loadKnife(knifeId);
    const skin = skins.get(skinId);
    // ⚠ Skin/Texture 解耦后图案在 Texture 表里，skin.pattern 可能为空 ——
    //   这里曾经只判 skin.pattern，导致解耦后**所有皮肤都不生成 atlas**（全用模型自带贴图）。
    if (!skin.texture && !skin.pattern) return null;

    const maps = this._ensureMaps(info);
    // 种子（换噪声模板）+ 窗口偏移（花纹在刀身上平移/旋转）双通道
    const win = patternWindowOf(patternIndex);
    // 刀型个体差异：由 knifeId 派生的确定性偏移（不是随机）——
    // 同一套皮肤配方在不同刀上花纹相位/UV 缩放略有不同，但同刀同皮肤完全可复现。
    const salt = knifeSalt(knifeId);
    // 图案：**从 Texture 表按 skin.texture 取**（方案 §40 Skin/Texture 解耦）；
    // 仍保留 skin.pattern 兼容（未迁移的旧配方直接内联）
    const texSpec = (!skin.pattern && skin.texture && K3D.textures)
      ? K3D.textures.patternOf(skin.texture) : null;
    const pat = skin.pattern || texSpec || {};
    const spec = {
      ...pat, seedShift: seed,
      du: win.du, dv: win.dv, rot: win.rot,
      knifeSalt: salt,
      // 区域边界（与 aRegion 顶点属性同源，保证烘焙与 shader 判定一致）
      region: (K3D.regions && K3D.regions.of) ? K3D.regions.of(knifeId) : null,
      // 用户纹理参数（方案 §44）：缩放/旋转/偏移叠加在皮肤自带配方之上
      freqScale: tp.scale,
      rotExtra: tp.rotation,
      offU: tp.offsetU,
      offV: tp.offsetV,
      warpExtra: tp.warp,
      contrastExtra: tp.contrast,
      // Fade 渐变参数（方案 §15 的 start/end/scale）
      fadeShift: tp.fadeShift,
      fadeSpan: tp.fadeSpan,
      // Doppler / Damascus 的相位偏移（方案 §17 的 Phase）
      phase: tp.phase,
    };

    // ⚠ 刀柄不再在 atlas 侧着色（改由 material.js 的 bladeMask hook 统一负责，
    //    避免烘焙与 shader 双重应用，且刀柄颜色/质感才能实时可调）
    const result = K3D.Atlas.generate(info.meshData, maps, spec, {
      size: ATLAS_SIZE,
      handleTone: { gain: 1, tint: [1, 1, 1], desat: 0 },
      fallbackHandle: [0.18, 0.19, 0.21],
      targetLum: 196,
      dilate: 2,
      // 刀柄程序化材质纹理（12 种之一）
      handleMaterial: this._handleMatSpec(hmId),
      // P4 Damascus：大马士革钢亮带抛光 / 暗带磨砂（编码进 color A 通道）
      patternRough: spec.patternRough || 0,
    });

    const colorTex = new THREE.CanvasTexture(arrayToCanvas(result.color, ATLAS_SIZE));
    colorTex.colorSpace = THREE.SRGBColorSpace;
    colorTex.flipY = false;
    colorTex.wrapS = colorTex.wrapT = THREE.RepeatWrapping;
    colorTex.anisotropy = 4;

    const metalTex = new THREE.CanvasTexture(arrayToCanvas(result.metal, ATLAS_SIZE));
    metalTex.colorSpace = THREE.NoColorSpace;
    metalTex.flipY = false;
    metalTex.wrapS = metalTex.wrapT = THREE.RepeatWrapping;

    let normalTex = null;
    if (result.normal) {
      normalTex = new THREE.CanvasTexture(arrayToCanvas(result.normal, ATLAS_SIZE));
      normalTex.colorSpace = THREE.NoColorSpace;
      normalTex.flipY = false;
      normalTex.wrapS = normalTex.wrapT = THREE.RepeatWrapping;
    }

    const entry = { key, colorTex, metalTex, normalTex, stats: result.stats };
    this.atlasCache.set(key, entry);
    this._evictAtlas();
    this._status({ stage: 'atlas', knifeId, skinId, stats: result.stats });
    // ── 持久化（fire-and-forget）：下次会话/预热直接命中，跳过烘焙 ──
    if (K3D.AtlasStore) {
      K3D.AtlasStore.set(key, { color: result.color, metal: result.metal, normal: result.normal, stats: result.stats });
    }
    return entry;
  }

  /** 从持久化记录（TypedArrays）重建 atlas entry；格式不符返回 null */
  _entryFromRecord(rec, key) {
    if (!rec || !rec.color || !rec.metal || !ArrayBuffer.isView(rec.color) || !ArrayBuffer.isView(rec.metal)) return null;
    try {
      const n = rec.color.length;
      const color = rec.color instanceof Uint8ClampedArray ? rec.color : new Uint8ClampedArray(rec.color);
      const metal = rec.metal instanceof Uint8ClampedArray ? rec.metal : new Uint8ClampedArray(rec.metal);
      if (color.length !== n || metal.length !== n) return null;
      const colorTex = new THREE.CanvasTexture(arrayToCanvas(color, ATLAS_SIZE));
      colorTex.colorSpace = THREE.SRGBColorSpace;
      colorTex.flipY = false;
      colorTex.wrapS = colorTex.wrapT = THREE.RepeatWrapping;
      colorTex.anisotropy = 4;
      const metalTex = new THREE.CanvasTexture(arrayToCanvas(metal, ATLAS_SIZE));
      metalTex.colorSpace = THREE.NoColorSpace;
      metalTex.flipY = false;
      metalTex.wrapS = metalTex.wrapT = THREE.RepeatWrapping;
      let normalTex = null;
      if (rec.normal && ArrayBuffer.isView(rec.normal) && rec.normal.length === n) {
        const normal = rec.normal instanceof Uint8ClampedArray ? rec.normal : new Uint8ClampedArray(rec.normal);
        normalTex = new THREE.CanvasTexture(arrayToCanvas(normal, ATLAS_SIZE));
        normalTex.colorSpace = THREE.NoColorSpace;
        normalTex.flipY = false;
        normalTex.wrapS = normalTex.wrapT = THREE.RepeatWrapping;
      }
      const entry = { key, colorTex, metalTex, normalTex, stats: rec.stats, fromStore: true };
      this.atlasCache.delete(key);
      this.atlasCache.set(key, entry);
      this._evictAtlas();
      return entry;
    } catch (e) {
      console.warn('[atlas] 持久化记录损坏，回退到重新烘焙：', e && e.message);
      return null;
    }
  }

  /**
   * 生成三区域顶点属性 aRegion（vec3 One-Hot：r=刀身 / g=护手+尾部 / b=刀柄）。
   *
   * **纯位置分区 + 单位分解**（保证"护手绝不吃掉刀身"与"同参数必然同结果"）：
   *   ① t = 沿长轴的归一化位置（含切割角度倾角投影），0=柄尾 1=刀尖；
   *   ② 刀身 = t ≥ bladeStart；护手带 = [guardStart, bladeStart]（柄侧那段金属环），
   *      **guardStart 可以拉到 bladeStart（带宽 0 = 不要护手带）**；
   *      刀柄 = 柄侧剩余 → wB + wG + wH ≡ 1，两端 smoothstep 软过渡避免硬切。
   *   ③ 不使用 ORM 金属度（见下方注释：这批模型金属度无极变，且会导致重建前后不一致）。
   * @param {THREE.BufferGeometry} geo
   * @param {string} knifeId
   * @param {{w:number,h:number,data:Uint8ClampedArray}|null} orm  历史参数，现已不使用
   */
  _buildRegionAttribute(geo, knifeId, orm) {
    if (!geo || !geo.attributes || !geo.attributes.position) return;
    if (geo.attributes.aRegion) geo.deleteAttribute('aRegion');
    const rg = (K3D.regions && K3D.regions.of) ? K3D.regions.of(knifeId) : { bladeStart: 0.36, guardStart: 0.28 };
    const F = (K3D.regions && K3D.regions.FEATHER) || 0.012;
    const pos = geo.attributes.position.array;
    const uvAttr = geo.attributes.uv;
    const n = pos.length / 3;
    // 长轴 = 包围盒最长边
    let mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < n; i++) {
      for (let d = 0; d < 3; d++) {
        const v = pos[i * 3 + d];
        if (v < mn[d]) mn[d] = v;
        if (v > mx[d]) mx[d] = v;
      }
    }
    const size = [mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]];
    const ax = size[0] >= size[1] && size[0] >= size[2] ? 0 : (size[1] >= size[2] ? 1 : 2);
    const span = Math.max(size[ax], 1e-6);
    // 切割平面倾斜角度（度），0=垂直长轴，±45=最大倾斜
    const angleDeg = rg.angle || 0;
    const angleRad = angleDeg * Math.PI / 180;
    const cosA = Math.cos(angleRad), sinA = Math.sin(angleRad);
    // 次要轴 = 第二长的轴，用于计算倾斜投影
    const axSorted = [0,1,2].sort((a,b) => size[b] - size[a]);
    const ax2 = axSorted[1];
    const mn2 = mn[ax2], mx2 = mx[ax2], span2 = Math.max(mx2 - mn2, 1e-6);
    const ss = (e0, e1, x) => {
      const t = Math.min(1, Math.max(0, (x - e0) / Math.max(e1 - e0, 1e-6)));
      return t * t * (3 - 2 * t);
    };
    // ⚠ 已移除「ORM 金属度精修护手」（旧实现：guardW = rest * inBand * metal）。
    //   两个原因：
    //   ① 实测这批模型的金属度几乎处处 ≈0.8，无可用阶跃（tools/measure_guard.js 与
    //      tools/metalness_analyze.js 的输出都可复现），金属度并不携带护手信息；
    //   ② 该精修只在 loadKnife 首次构建时带 orm，rebuildRegions 重建时没有 orm
    //      → 同一把刀的护手形状在"首次构建"和"拖动滑块重建"之间会变。
    //   现在权重只依赖位置 + 分区边界，**同参数必然同结果**，重建稳定、可复现。
    void orm;   // 参数保留以兼容调用方签名（materials 提取仍在 _ensureMaps 用）
    // ── 护手带（结构上永不超过刀身边界）──────────────────────────────
    // 约定：guardStart ≤ bladeStart，护手带 = [guardStart, bladeStart]（柄侧那段金属环）。
    //   guardStart == bladeStart → 带宽为 0 = 这把刀不要护手带（护手整个收进刀身边界）。
    // ⚠ 事故根因（本文件曾用下面这种写法）：
    //     guardW = ss(gsLo, gsHi, t)
    //   smoothstep 在 t > gsHi 之后**恒为 1**，是"单侧阶跃"而非"带"；
    //   一旦 |bladeStart - guardStart| 变大（上一轮标定把 guardStart 写到了 bladeStart 之后），
    //   护手权重就把整段刀身吃满 → shader 里 mix(color, guardColor, wG) 把皮肤整片盖成护手质感。
    // 现在的三条硬约束：
    //   ① 护手带位置 = guardStart 本身（滑块 1:1，不再 ×1.6 偏移）；
    //   ② 位置强制夹在 [0.01, bladeStart] 内 —— 允许等于 bladeStart（零宽），越界则收窄；
    //   ③ guardW 乘 (1 - bladeW)，护手**不可能**盖到刀身；wB + wG + wH ≡ 1（单位分解，无白边夹缝）。
    const bsNum = Number(rg.bladeStart);
    const bladeStart = Number.isFinite(bsNum) ? bsNum : 0.36;
    const gsNum = Number(rg.guardStart);
    const guardStart = Math.max(0.01, Math.min(
      Number.isFinite(gsNum) ? gsNum : bladeStart - 0.06,
      bladeStart,
    ));
    // 线外浅铺参数（见 regions.js 注释：刀身花纹越过 bladeStart 往柄侧低透明度再铺一段，
    // 盖住交界处"只有护手/刀柄亮金属质感"的那条白痕）
    const SKIRT = (K3D.regions && Number(K3D.regions.SKIRT)) || 0.05;
    const BLEED = (K3D.regions && K3D.regions.BLEED != null) ? Number(K3D.regions.BLEED) : 0.35;
    const arr = new Float32Array(n * 3);
    const tArr = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      // 沿长轴 + 倾角投影到切割平面
      const tAx = (pos[i * 3 + ax] - mn[ax]) / span;
      const tAx2 = (pos[i * 3 + ax2] - mn2) / span2;
      // 倾斜投影：t = tAx·cos(angle) + tAx2·sin(angle)，再归一化回 [0,1]
      let tRaw = tAx * cosA + tAx2 * sinA;
      // 重新归一化到 [0,1]（假设倾斜后范围略大于原范围，用 clamp 兜底）
      const t = Math.max(0, Math.min(1, tRaw));
      tArr[i] = t;
      // 刀身权重 = 主体（t ≥ bladeStart 的一刀切）+ 线外浅铺（柄侧低透明度尾巴）
      // 主体：bladeStart ± F 软过渡，保证花纹边界干净利落
      const bladeCore = ss(bladeStart - F, bladeStart + F, t);
      // 浅铺：从 bladeStart 往柄侧延伸 SKIRT，最高 BLEED；与 atlas 烘焙侧同一公式
      const bladeTail = BLEED * ss(bladeStart - SKIRT, bladeStart + F, t);
      const bladeW = Math.max(bladeCore, bladeTail);
      // 柄侧剩余部分（刀身以外）
      const rest = 1 - bladeW;
      // 护手权重：带起点 = guardStart，天然在柄侧（①位置 ②夹紧 ③乘 rest）
      const inBand = ss(guardStart - F, guardStart + F, t);
      const guardW = rest * inBand;
      // 刀柄 = 柄侧剩余（wB + wG + wH 恒为 1，不会出现白边夹缝）
      const handleW = rest - guardW;
      arr[i * 3] = bladeW;
      arr[i * 3 + 1] = guardW;
      arr[i * 3 + 2] = handleW;
    }
    geo.setAttribute('aRegion', new THREE.BufferAttribute(arr, 3));
    geo.setAttribute('aBladeT', new THREE.BufferAttribute(tArr, 1));
    this._buildEdgeAttribute(geo);
  }

  /**
   * 几何边缘因子 aEdge（方案 v2 §7）：凸起=1 / 凹槽=0。
   * 用**顶点邻域平均位置**与法线的夹角估算曲率 —— 凸棱处邻域平均位置落在表面内侧
   * （与法线反向），凹槽处同向。零额外贴图，一次预计算。
   * 用途：WearFinal = UserWear × WearRate × EdgeFactor → 凸起先掉漆、凹槽保留颜色。
   */
  _buildEdgeAttribute(geo) {
    if (!geo || !geo.attributes.position || !geo.attributes.normal || !geo.index) return;
    if (geo.attributes.aEdge) geo.deleteAttribute('aEdge');
    const pos = geo.attributes.position.array;
    const nor = geo.attributes.normal.array;
    const idx = geo.index.array;
    const n = pos.length / 3;
    const acc = new Float32Array(n * 3);
    const cnt = new Uint32Array(n);
    for (let f = 0; f < idx.length; f += 3) {
      const a = idx[f], b = idx[f + 1], c = idx[f + 2];
      for (const [x, y] of [[a, b], [a, c], [b, a], [b, c], [c, a], [c, b]]) {
        acc[x * 3] += pos[y * 3];
        acc[x * 3 + 1] += pos[y * 3 + 1];
        acc[x * 3 + 2] += pos[y * 3 + 2];
        cnt[x]++;
      }
    }
    const out = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      if (!cnt[i]) { out[i] = 0.5; continue; }
      // L = 邻域平均位置 - 自身位置
      const lx = acc[i * 3] / cnt[i] - pos[i * 3];
      const ly = acc[i * 3 + 1] / cnt[i] - pos[i * 3 + 1];
      const lz = acc[i * 3 + 2] / cnt[i] - pos[i * 3 + 2];
      const len = Math.hypot(lx, ly, lz) || 1e-6;
      // 凸棱：L 与法线反向（邻域中心在表面内侧）→ conv > 0
      const conv = -(lx * nor[i * 3] + ly * nor[i * 3 + 1] + lz * nor[i * 3 + 2]) / len;
      out[i] = Math.min(1, Math.max(0, 0.5 + 0.5 * conv * 2.2));   // 0=凹 1=凸
    }
    geo.setAttribute('aEdge', new THREE.BufferAttribute(out, 1));
  }

  /** knifeId → 刀柄材质 spec（给 Atlas.generate） */
  _handleMatSpec(hmId) {
    const m = K3D.skins.materialOf ? K3D.skins.materialOf(hmId) : null;
    return m && m.pattern ? { kind: m.pattern.kind, seed: m.pattern.seed } : null;
  }

  /** 接收 viewer 加载好的环境贴图，并挂到所有已加载材质上（含之后新加载的）。 */
  setEnvMap(tex) {
    this.envMap = tex;
    for (const info of this.loaded.values()) {
      for (const m of info.materials) {
        m.envMap = tex;
        m.needsUpdate = true;
      }
    }
  }

  _setAtlasRef(knifeId, key) {
    const prev=this.atlasByKnife.get(knifeId);
    if(prev===key)return;
    if(prev){const n=(this.atlasRefs.get(prev)||1)-1;if(n<=0)this.atlasRefs.delete(prev);else this.atlasRefs.set(prev,n);}
    if(key){this.atlasByKnife.set(knifeId,key);this.atlasRefs.set(key,(this.atlasRefs.get(key)||0)+1);}
    else this.atlasByKnife.delete(knifeId);
  }

  /** LRU 淘汰：只淘汰没有任何材质正在引用的 atlas。 */
  _evictAtlas() {
    if (this.atlasCache.size <= ATLAS_CACHE_LIMIT) return;
    for (const [k, e] of this.atlasCache) {
      if (this.atlasCache.size <= ATLAS_CACHE_LIMIT) break;
      if ((this.atlasRefs.get(k)||0)>0) continue;
      e.colorTex?.dispose(); e.metalTex?.dispose(); e.normalTex?.dispose();
      this.atlasCache.delete(k);
    }
  }

  /**
   * 后台预热：把 12 把刀在当前皮肤配方下的 atlas 烘好并写 IDB。
   * 首刀 ready 后由 app.js 调（延迟 1.5s，不抢首屏）。IDB 命中时近零成本，
   * 未命中时每把 ~770ms（SwiftShader；真机 ~100ms）分片跑，不阻塞 UI。
   */
  async prewarm(skinId, paramOverride) {
    if (this._prewarmRunning || !this.knives) return;
    this._prewarmRunning = true;
    const po = paramOverride || {};
    for (const k of this.knives) {
      if (!k || !k.id) continue;
      try {
        await this.ensureAtlas(
          k.id, skinId,
          po.patternSeed || 0,
          po.handleMaterial || null,
          {
            scale: po.texScale, rotation: po.texRotation,
            offsetU: po.texOffsetU, offsetV: po.texOffsetV,
            warp: po.texWarp, contrast: po.texContrast,
            fadeShift: po.fadeShift, fadeSpan: po.fadeSpan, phase: po.texPhase,
          },
        );
      } catch (e) { /* 预热失败不影响功能 */ }
      await new Promise((r) => setTimeout(r, 30));   // 分片让出主线程
    }
    this._prewarmRunning = false;
  }
  /**
   * 应用皮肤：设置贴图 + 材质参数。
   * @returns {{applied, atlasStats|null}}
   */
  /**
   * 应用皮肤。fast=true 时**跳过 atlas 烘焙**（用模型自带贴图兜底刀柄 mask），
   * 让模型尽快上屏；atlas 由调用方在后台补烘（见 app.js selectKnife 的两步走）。
   * BladeSkin（新皮肤系统）的刀身效果不依赖 atlas —— 它走 shader 程序化通道，
   * 所以 fast 模式下刀身已经是"新皮肤"，只差刀柄的程序化材质纹理。
   */
  async applySkin(knifeId, skinId, paramOverride = {}, { fast = false } = {}) {
    K3D.activeKnifeId = knifeId;
    const info = await this.loadKnife(knifeId);
    const skin = skins.get(skinId);
    let atlasStats = null;

    let map = null, metalMap = null, normalMap = null;
    let atlas = null;
    // 有 Texture 引用（或旧的内联 pattern）才烘焙 atlas；原版走模型自带贴图
    if (!fast && (skin.texture || skin.pattern)) {
      atlas = await this.ensureAtlas(
        knifeId, skinId, paramOverride.patternSeed || 0,
        paramOverride.handleMaterial || null,
        // 纹理参数（方案 §44）：缩放/旋转/偏移/弯曲/对比
        {
          scale: paramOverride.texScale,
          rotation: paramOverride.texRotation,
          offsetU: paramOverride.texOffsetU,
          offsetV: paramOverride.texOffsetV,
          warp: paramOverride.texWarp,
          contrast: paramOverride.texContrast,
          fadeShift: paramOverride.fadeShift,
          fadeSpan: paramOverride.fadeSpan,
          phase: paramOverride.texPhase,
        },
      );
      if (atlas) { map = atlas.colorTex; metalMap = atlas.metalTex; normalMap = atlas.normalTex; atlasStats = atlas.stats; }
    }
    // 先拿到新 atlas，再切换引用；这样即使烘焙失败，旧材质仍然安全。
    this._setAtlasRef(knifeId, atlas?.key || null);
    if (!map) { map = null; metalMap = null; }   // original → 用模型自带贴图（orig.map）

    // 刀柄参数合并：皮肤配方打底、调用方覆盖优先。
    // ⚠ 不能把 bladeMask 展开在 paramOverride 之后 —— 那会把调用方的
    //   刀柄着色/材质预设整个丢掉（曾导致 12 种刀柄材质全部不生效）。
    const skinMask = skins.toneToMask(skin.handle) || undefined;
    const M = mat.normalizeMaterial({
      ...mat.defaultMaterial(), ...skin.material, ...paramOverride,
      bladeMask: { ...(skinMask || {}), ...(paramOverride.bladeMask || {}) },
    });

    let applied = null;
    for (const m of info.materials) {
      const orig = m.userData.orig;
      if (map) {
        m.map = map;
        m.metalnessMap = metalMap || orig.metalnessMap;
        m.normalMap = normalMap || orig.normalMap;
        // 记录遮罩来源：atlas metal 贴图的 A 通道 = 我们烘焙的刀身/刀柄分区（更准）
        m.userData.maskTex = metalMap || orig.metalnessMap;
        m.userData.maskAlpha = !!metalMap;
      } else {
        m.map = orig.map;
        m.metalnessMap = orig.metalnessMap;
        m.normalMap = orig.normalMap;
        m.userData.maskTex = orig.metalnessMap;
        m.userData.maskAlpha = false;   // 无皮肤 → 用模型自带 ORM 的 B 通道
      }
      m.needsUpdate = true;
      const r = mat.applyMaterialState(m, M, {
        patternRoughMap: atlas ? atlas.colorTex : null,
        patternRoughIntensity: atlas ? 1.0 : 0,
      });
      if (r && !applied) applied = r;
      mat.invalidateHookProgram(this.renderer, m);
    }
    return { applied, atlasStats, skin, params: M };
  }

  /** 只更新材质参数（不换贴图）。 */
  setParams(knifeId, paramOverride) {
    const info = this.loaded.get(knifeId);
    if (!info) return null;
    const M = mat.normalizeMaterial(paramOverride);
    let applied = null;
    for (const m of info.materials) {
      const r = mat.applyMaterialState(m, M);
      if (r && !applied) applied = r;
      mat.invalidateHookProgram(this.renderer, m);
    }
    return applied;
  }

  /** 设置某把刀的持久区域覆盖（写 K3D.regions.overrideMap，所有下游烘焙/顶点属性统一读取，无竞态）。
   *  override=null 清除覆盖。
   *  ⚠ 坑：`Number(null) === 0` 且 `isFinite(0) === true`，所以"用 isFinite 判 null"这种写法
   *     会把 null 写成 0 —— 结果是只拖 guardStart / 角度滑块时，bladeStart 被写成 0，
   *     `regions.of()` 返回 bladeStart=0 → 皮肤铺满整把刀、护手刀柄全没了。
   *     必须先显式排除 null/undefined/''，再判数值。 */
  setRegionOverride(knifeId, override) {
    if (!K3D.regions) return;
    if (!K3D.regions.overrideMap) K3D.regions.overrideMap = {};
    /** null / undefined / '' → null；其余转数值，非有限值也归 null */
    const numOrNull = (v) => {
      if (v === null || v === undefined || v === '') return null;
      const n = Number(v);
      return Number.isFinite(n) ? n : null;
    };
    const ov = {};
    if (override) {
      const bs = numOrNull(override.bladeStart);
      const gs = numOrNull(override.guardStart);
      const ag = numOrNull(override.angle);
      if (bs !== null) ov.bladeStart = bs;
      if (gs !== null) ov.guardStart = gs;
      // angle 显式写 0 也要存：否则拖到 0° 会被 KNIFE_REGIONS 的预设角度（如 -6°）覆盖回来，
      // 出现"滑块显示 0° 但渲染用的是 -6°"的错位。
      if (ag !== null) ov.angle = ag;
    }
    if (Object.keys(ov).length > 0) K3D.regions.overrideMap[knifeId] = ov;
    else delete K3D.regions.overrideMap[knifeId];
  }

  /** 重新计算某把刀的 aRegion 顶点属性（含 ORM 精修）。 */
  rebuildRegions(knifeId) {
    const info = this.loaded.get(knifeId);
    if (!info) return;
    info.root.traverse(child => {
      if (child.isMesh && child.geometry) {
        this._buildRegionAttribute(child.geometry, knifeId);
      }
    });
  }
}

/** '#rrggbb' → [r,g,b] 0..1（sRGB 数值，与 atlas 的颜色空间保持一致）。 */
/**
 * 图案索引 → 噪声种子映射（模拟 CSGO 的 pattern/index 结构）：
 *   索引 0..1000 分为 8 个「模板」档位（每档 125 个细节格）——
 *   跨档 = 完全不同的花纹布局，档内 = 同一族的细微波动。
 * 两个素数步距保证不同模板的噪声场互不重叠。
 */
function mapPatternSeed(v) {
  const clamped = Math.max(0, Math.min(1000, Math.round(v)));
  const tpl = Math.min(7, Math.floor(clamped / 125));
  const fine = clamped % 125;
  return tpl * 10007 + fine * 613;
}

/**
 * 图案索引 → 花纹「窗口偏移」。
 * ⚠ 注意：旋转/取模会破坏「沿刀身」的方向语义（fade 渐变、虎牙条纹依赖 s 方向），
 * 并对渐变产生接缝 —— 所以旋转恒为 0，只做横向轻微平移（u 方向不平移，保方向）。
 * 图案变化的"主力"仍是噪声种子 seedShift。
 */
function patternWindowOf(v) {
  const clamped = Math.max(0, Math.min(1000, Math.round(v)));
  const fine = clamped % 125;
  // 只平移横向 a（换采样窗口），不动 s（保住沿刀身方向）
  const dv = (fine * 0.381966) % 1;
  return { du: 0, dv, rot: 0 };
}

/**
 * 刀型个体差异：由 knifeId 哈希派生的确定性 [0,1) 数值（同一把刀永远相同，不是随机）。
 * 用途：同一套皮肤配方在不同刀上，花纹相位与 UV 缩放略有不同 —— 对应 CSGO 里
 * `Weapon UV Scale` 因刀型而异（折叠刀 0.36 / 猎杀者匕首 0.506）的效果，
 * 同时保证"多刀通用 + 同刀同皮肤完全可复现"。
 * @returns {[number, number]} [相位偏移, UV缩放因子]
 */
function knifeSalt(knifeId) {
  let h = 2166136261;                    // FNV-1a
  const s = String(knifeId || '');
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  const u = h >>> 0;
  return [((u % 10000) / 10000), ((Math.imul(u, 2654435761) >>> 0) % 10000) / 10000];
}

K3D.mapPatternSeed = mapPatternSeed;
K3D.patternWindowOf = patternWindowOf;
K3D.knifeSalt = knifeSalt;
K3D.patternTemplateOf = (v) => {
  const clamped = Math.max(0, Math.min(1000, Math.round(v)));
  return Math.min(7, Math.floor(clamped / 125));
};

function hexToLinear(hex) {
  const h = String(hex || '#ffffff').replace('#', '');
  return [
    parseInt(h.slice(0, 2), 16) / 255,
    parseInt(h.slice(2, 4), 16) / 255,
    parseInt(h.slice(4, 6), 16) / 255,
  ];
}

function arrayToCanvas(rgba, size) {
  const canvas = document.createElement('canvas');
  canvas.width = size; canvas.height = size;
  const ctx = canvas.getContext('2d');
  const img = new ImageData(rgba, size, size);
  ctx.putImageData(img, 0, 0);
  return canvas;
}

K3D.engine = Engine;

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { Engine };
}
})(typeof window !== 'undefined' ? window : globalThis);
