(function(){
'use strict';
const D=window.FORGE_DATA, THREE=window.THREE, K3D=window.K3D;
const $=s=>document.querySelector(s);
const TEST_MODE=new URLSearchParams(location.search).get('test')==='1';
const appState={screen:'home', viewer:null, engine:null, stageLoader:null, currentModel:null, currentKnife:null, loading:false, save:null, run:null, stageCards:[], stageCardsStage:null, selectedCard:null, mini:null, circuit:null, stageToken:0};
const STORE='blade_forge_3d_save_v2';
const LEGACY_STORE='blade_forge_3d_save_v1';
const SAVE_VERSION=2;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const rnames={common:'普通',uncommon:'精良',rare:'稀有',epic:'史诗',legendary:'传说',mythic:'神话'};
const rcolors={common:'#98A2B0',uncommon:'#2FD3A0',rare:'#6E7BFF',epic:'#E04FD8',legendary:'#FFC24B',mythic:'#FF9E4B'};
function seeded(seed){let s=seed>>>0;return()=>{s+=0x6D2B79F5;s=Math.imul(s^s>>>15,1|s);s^=s+Math.imul(s^s>>>7,61|s);return((s^s>>>14)>>>0)/4294967296}}
function rngFor(run,tag='main'){const h=hash32(`${run.seed}:${tag}:${run.rngCursor}`);return seeded(h)}
function hash32(str){let h=2166136261>>>0;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function save(){appState.save.saveVersion=SAVE_VERSION;localStorage.setItem(STORE,JSON.stringify(appState.save));renderHeader()}
function loadSave(){const base={saveVersion:SAVE_VERSION,cr:50,blades:[],broken:0,forgeCount:0,winCount:0,lossCount:0,bestScore:0,daily:{date:'',completed:false,score:0},achievements:{},meta:{unlockedForgeTraits:[],unlockedMatchTraits:['overdrive','steady_hand','showtime'],titles:[],frames:[]},circuit:{nationalNode:0,nationalChampion:false,schoolWins:{},globalWins:0}};try{let raw=JSON.parse(localStorage.getItem(STORE)||'null');if(!raw){const legacy=JSON.parse(localStorage.getItem(LEGACY_STORE)||'null');if(legacy){raw=legacy;try{localStorage.setItem(STORE,JSON.stringify(raw));localStorage.removeItem(LEGACY_STORE)}catch{}}}if(raw){const s={...base,...raw,saveVersion:SAVE_VERSION,meta:{...base.meta,...(raw.meta||{})},daily:{...base.daily,...(raw.daily||{})},circuit:{...base.circuit,...(raw.circuit||{})}};s.circuit.schoolWins={...((raw.circuit||{}).schoolWins||{})};s.blades=(s.blades||[]).map(b=>({...b,broken:!!b.broken,traits:b.traits||[],combos:b.combos||[],forgePath:b.forgePath||[],visual:b.visual||{materialId:'M01',textureId:'T04',finishId:'F02',wear:0,seed:0},record:{win:0,loss:0,lossCount:0,...(b.record||{})},mastery:Number(b.mastery||0),title:b.title||'',repairs:Number(b.repairs||0),legacy:b.legacy||null}));return s}}catch{}return base}
function renderHeader(){$('#crVal').textContent=Math.floor(appState.save?.cr??50);$('#backBtn').hidden=appState.screen==='home';const labels={home:'HOME',forge:'FORGE',circuit:'CIRCUIT',collection:'COLLECTION',codex:'CODEX',daily:'DAILY'};$('#screenEn').textContent=labels[appState.screen]||'BLADE FORGE'}
function showScreen(name){appState.screen=name;document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));$('#'+name+'Screen').classList.add('active');renderHeader()}
function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove('show'),1800)}
function rarityStyle(r){return `--rarity:${rcolors[r]||rcolors.common}`}
function fmtStats(s){return D.STAT_KEYS.map(k=>`<i>${D.STAT_CN[k]} ${Math.round(s[k]||0)}</i>`).join('')}
function randomSeed(){return (crypto?.getRandomValues?crypto.getRandomValues(new Uint32Array(1))[0]:Date.now()>>>0)}
function dateKey(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}

async function boot3D(){
  const canvasHost=document.createElement('div');
  // Engine itself owns a viewer per screen; keep one viewer attached to a hidden bootstrap container and move its canvas between shells.
  appState.engine=new K3D.engine();
  await appState.engine.init();
  const host=document.createElement('div');host.style.cssText='position:absolute;left:-10000px;top:-10000px;width:1px;height:1px;pointer-events:none';document.body.appendChild(host);
  appState.viewer=new K3D.Viewer(host); await appState.viewer.loadEnvironment(); appState.engine.envMap=appState.viewer.envMap; appState.engine.renderer=appState.viewer.renderer;
  appState.stageLoader=new THREE.GLTFLoader();
}
function attachViewer(host){const canvas=appState.viewer?.renderer?.domElement;if(!canvas||!host)return;if(appState.viewerResizeObserver)appState.viewerResizeObserver.disconnect();canvas.style.position='absolute';canvas.style.inset='0';host.appendChild(canvas);appState.viewer.container=host;appState.viewer.resize();appState.viewerResizeObserver=new ResizeObserver(()=>appState.viewer?.resize());appState.viewerResizeObserver.observe(host)}
function detachViewer(){const canvas=appState.viewer?.renderer?.domElement;if(canvas&&canvas.parentElement?.classList.contains('stage3d'))canvas.parentElement.removeChild(canvas)}
function decodeB64(s){const bin=atob(s),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return u.buffer}
async function loadStageModel(url){
  if(window.location.protocol==='file:'&&window.FORGE_STAGE_INLINE?.models?.[url]) return new Promise((resolve,reject)=>appState.stageLoader.parse(decodeB64(window.FORGE_STAGE_INLINE.models[url]),'',resolve,reject));
  return appState.stageLoader.loadAsync(url);
}
async function showStageModel(kind, opts={}){
  const token=++appState.stageToken;
  const host=opts.host||$('.stage3d');if(!host||!appState.viewer)return;
  detachViewer(); appState.currentModel=null;
  const urls={material:D?.ASSETS?.materialModel||'assets/materials/ore_small.glb',melt:'assets/materials/molten_sphere_small.glb',blank:'assets/materials/blank_ingot_small.glb'};
  if(kind==='knife'){
    const knife=opts.knifeId||appState.currentKnife||D.BLADE_TYPES_3D[0].id;
    try{const info=await appState.engine.loadKnife(knife);if(token!==appState.stageToken)return;attachViewer(host);appState.viewer.setModel(info.root,knife);appState.currentModel=info.root;await applyVisual(opts.run||appState.run||{},knife);addStageFX('knife',opts)}catch(e){console.error(e);toast('刀模型加载失败')}
    return;
  }
  try{const gltf=await loadStageModel(urls[kind]||urls.material);if(token!==appState.stageToken)return;const root=gltf.scene;root.traverse(o=>{if(!o.isMesh)return;const ms=Array.isArray(o.material)?o.material:[o.material];ms.forEach(m=>{if(m.color){m.color.lerp(new THREE.Color('#ffffff'),kind==='melt'?.05:.15)}if(kind==='melt'){if('emissive' in m){m.emissive=new THREE.Color('#ff6b1a');m.emissiveIntensity=.8}}})});attachViewer(host);appState.viewer.setModel(root,'stage');appState.currentModel=root; addStageFX(kind)}catch(e){console.error(e);toast('阶段模型加载失败')}
}
function addStageFX(kind,opts={}){const p=appState.viewer.pivot; if(!p)return;const old=p.userData.forgeFx; if(old){old.forEach(o=>{p.remove(o);if(o.isMesh){o.geometry?.dispose();const ms=Array.isArray(o.material)?o.material:[o.material];ms.forEach(m=>m?.dispose())}})} const fx=[];
  if(kind==='melt'){const l=new THREE.PointLight(0xff6a22,2.3,4);l.position.set(0,-.35,.2);p.add(l);fx.push(l);for(let i=0;i<8;i++){const g=new THREE.SphereGeometry(.018+Math.random()*.012,8,6),m=new THREE.MeshBasicMaterial({color:0xffb13b});const s=new THREE.Mesh(g,m);s.position.set((Math.random()-.5)*.55,-.1+Math.random()*.15,.12);s.userData.born=performance.now()+i*90;s.userData.baseY=s.position.y;s.userData.baseX=s.position.x;s.userData.baseZ=s.position.z;p.add(s);fx.push(s)}}
  if(kind==='blank'){const l=new THREE.DirectionalLight(0xffd59b,.5);l.position.set(-1,1,1);p.add(l);fx.push(l)}
  if(kind==='material'){const l=new THREE.DirectionalLight(0xdfeaff,.4);l.position.set(1,.4,1);p.add(l);fx.push(l)}
  if(kind==='knife'){
    const stage=opts.stage||opts.run?.stage||'appraisal';
    const cfg={
      fold:['#b58cff',1.15],quench:['#65b9ff',1.7],temper:['#ff9d45',1.35],edge:['#e7f7ff',1.5],handle:['#d8a35b',1.0],tune:['#77e5ff',1.2],appraisal:['#fff1b0',1.1]
    }[stage]||['#ffffff',.7];
    const l=new THREE.PointLight(cfg[0],cfg[1],3.8);l.position.set(.35,.15,.65);p.add(l);fx.push(l);
    if(['fold','quench','temper','edge','tune','appraisal'].includes(stage)){
      for(let i=0;i<6;i++){const g=new THREE.SphereGeometry(.008+i*.001,7,5),m=new THREE.MeshBasicMaterial({color:cfg[0],transparent:true,opacity:.55});const s=new THREE.Mesh(g,m);const a=(i/6)*Math.PI*2;s.position.set(Math.cos(a)*(.18+.02*(i%2)),(-.15+i*.06),Math.sin(a)*.12);s.userData.born=performance.now()+i*110;s.userData.baseY=s.position.y;s.userData.baseX=s.position.x;s.userData.baseZ=s.position.z;s.userData.orbit=a;p.add(s);fx.push(s)}
    }
  }
  p.userData.forgeFx=fx;
  if (fx.some(o => o.isMesh && o.userData.born)) start3DFX();
  appState.viewer.invalidate(120);
}
function start3DFX(){
  if(appState.fxRunning)return;
  appState.fxRunning=true;
  const tick=()=>{
    const p=appState.viewer?.pivot, list=p?.userData?.forgeFx||[];
    const now=performance.now(); let active=false;
    for(const o of list){
      if(!o.isMesh||!o.userData.born)continue;
      const t=(now-o.userData.born)/1000, life=1.6;
      if(t<life+0.15) active=true;
      const age=Math.max(0,t);
      o.position.y=o.userData.baseY+Math.min(1.2,age)*0.25;
      o.material.opacity=Math.max(0,1-Math.min(1,age/life));
      o.material.transparent=true;
      if(o.userData.orbit!=null){const a=o.userData.orbit+age*.65;o.position.x=o.userData.baseX+Math.cos(a)*.018;o.position.z=o.userData.baseZ+Math.sin(a)*.018}
    }
    appState.viewer?.invalidate(active?80:0);
    if(active && appState.viewer && !appState.viewer.disposed) requestAnimationFrame(tick);
    else appState.fxRunning=false;
  };
  requestAnimationFrame(tick);
}

function createRun(seed,mode='normal'){return{seed:seed>>>0,rngCursor:0,mode,stage:'material',material:null,stats:{...D.BASE_STATS},risk:0,riskPeak:0,traits:[],materialTraits:[],forgeTraits:[],combos:[],path:[],counts:{melt:0,forge:0,fold:0,quench:0,temper:0,edge:0,handle:0,tune:0},bladeType:null,textureId:'T04',finishId:'F02',handleId:'leather',edgeStyle:'flat',quench:'water',miniResults:{},score:0,rarity:'common',quality:'普通',cr:0,broken:false,record:{win:0,loss:0,lossCount:0},visual:{materialId:'M01',textureId:'T04',finishId:'F02',wear:0,seed:seed>>>0},lastFailure:false,saved:false,daily:false}}
function advanceRng(run,n=1){run.rngCursor+=n}
function pickCards(run,stage,count=3){const list=D.CARDS.filter(c=>c.stage===stage);const rr=rngFor(run,stage+run.path.length);const out=[];const used=new Set();while(out.length<Math.min(count,list.length)){let c=list[Math.floor(rr()*list.length)];if(used.has(c.id))continue;used.add(c.id);out.push(c)}advanceRng(run,1);return out}
function materialCandidates(run,count=3){const rr=rngFor(run,'material');const pool=[...D.MATERIALS];const out=[];const used=new Set();while(out.length<count){const m=pool[Math.floor(rr()*pool.length)];if(used.has(m.id))continue;used.add(m.id);out.push(m)}advanceRng(run,1);return out}
function statSnapshot(s){return Object.fromEntries(D.STAT_KEYS.map(k=>[k,Math.round(s[k]||0)]))}
function cardRisk(card,run){let risk=(card.cardRisk||0)+(card.riskMod||0);const mat=run.material;if(mat){for(const tag of card.tags||[]){if((mat.tabooTags||[]).includes(tag))risk+=5;if((mat.preferTags||[]).includes(tag))risk-=3}}return Math.max(0,risk)}
function cardGainMultiplier(run,card){
  let mult=1;
  for(const id of run.materialTraits||[]){
    const t=D.TRAITS.find(x=>x.id===id),e=t?.effect;if(!e)continue;
    if(e.stage===card.stage)mult*=e.mult||1;
    if(e.tag&&card.tags?.includes(e.tag))mult*=e.mult||1;
  }
  return mult;
}
function applyCard(run,card){
  const gainMult=cardGainMultiplier(run,card);
  for(const k of D.STAT_KEYS)if(card.stats?.[k])run.stats[k]+=Math.round(card.stats[k]*gainMult);
  const risk=cardRisk(card,run);run.risk=clamp(run.risk+risk,0,95);run.riskPeak=Math.max(run.riskPeak||0,run.risk);
  run.path.push(card.id);run.counts[card.stage]++;
  if(card.blade)run.bladeType=card.blade;if(card.es)run.edgeStyle=card.es;if(card.handle)run.handleId=card.handle;if(card.quench)run.quench=card.quench;
  if(card.special==='exotic'){const xs=D.BLADE_TYPES_3D.filter(x=>x.id.includes('knife_'));const rr=rngFor(run,'exotic');run.bladeType=xs[Math.floor(rr()*xs.length)].id}
  updateVisualFromRoute(run,card);resolveTraitsAfterCard(run,card);advanceRng(run,1)
}
function resolveTraitsAfterCard(run,card){
  const mat=run.material;
  if(mat?.trait&&!run.materialTraits.includes(mat.trait))run.materialTraits.push(mat.trait);
  const tags=new Set(run.path.flatMap(id=>{const c=D.CARDS.find(x=>x.id===id);return c?.tags||[]}));
  const add=id=>{if(!run.forgeTraits.includes(id))run.forgeTraits.push(id)};
  if(tags.has('折叠')&&run.counts.fold>=2)add('forge_folded_vein');
  if(tags.has('高温')&&run.risk>=12)add('forge_overheat');
  if(run.counts.forge>=2&&['perfect','great'].includes(run.miniResults.hammer?.rating||''))add('forge_thousand_strikes');
  if(run.miniResults.quench?.rating==='perfect')add('forge_quench_window');
  if(run.lastFailure&&run.riskPeak>=10&&appState.save?.meta?.unlockedForgeTraits?.includes('forge_broken_edge'))add('forge_broken_edge');
  for(const cb of D.COMBOS){
    if(run.combos.includes(cb.id))continue;
    const ok=(cb.needs||[]).every(n=>{
      if(n.material)return run.material?.id===n.material;
      if(n.cardId)return run.path.includes(n.cardId);
      if(n.cardTag)return run.path.some(id=>{const c=D.CARDS.find(x=>x.id===id);return c?.tags?.includes(n.cardTag)});
      if(n.bladeType)return run.bladeType===n.bladeType;
      return false;
    });
    if(ok){
      run.combos.push(cb.id);
      const trait=cb.grantsTrait;
      if(trait&&!run.traits.includes(trait))run.traits.push(trait);
    }
  }
}
function updateVisualFromRoute(run,card){
  const m=run.material;run.visual.materialId=D.materialToSkinMaterialId(m);run.visual.textureId=pickTextureId(run,card);run.visual.finishId=D.QUENCH_FINISH_MAP[run.quench]||run.visual.finishId;run.visual.seed=hash32(`${run.seed}:${run.path.join(',')}`)
}
function pickTextureId(run,card){const tags=card?.tags||[];const map={折叠:['T07','T08','T09'],手工:['T03','T05','T10'],重锤:['T06','T11'],精密:['T04','T12'],热锻:['T02','T06'],古法:['T08','T09'],星尘:['T10','T12'],锻打:['T02','T06','T07','T08']};for(const t of tags)if(map[t])return map[t][hash32(`${run.seed}:${card.id}`)%map[t].length];return ['T01','T04','T05'][hash32(`${run.seed}:${card.id}`)%3]}
function applyForgeTraitStats(run){
  if(run.forgeTraits.includes('forge_overheat'))run.stats.strength+=8;
  if(run.forgeTraits.includes('forge_thousand_strikes'))run.stats.strength+=Math.max(0,run.counts.forge-1)*2;
  if(run.forgeTraits.includes('forge_folded_vein')){run.stats.craft+=3;run.stats.design+=2}
  if(run.forgeTraits.includes('forge_broken_edge'))run.stats.edge+=9;
  if(run.forgeTraits.includes('forge_master_hand'))run.stats.craft+=6;
  if(run.materialTraits.includes('trait_glass_edge')){run.stats.edge+=3;run.stats.toughness=Math.max(1,run.stats.toughness-2)}
}
function miniMult(r){return{perfect:1.15,great:1.08,good:1.03,miss:.95}[r]||1}
function miniScoreFromPos(pos){const d=Math.abs(pos-.5);return d<.07?'perfect':d<.16?'great':d<.27?'good':'miss'}
function stageStatusText(run){return `Risk ${Math.round(run.risk)}% · ${run.rarity==='common'?'普通':rnames[run.rarity]}`}

async function applyVisual(run,knifeId){
  if(!run||!knifeId)return;
  const info=await appState.engine.loadKnife(knifeId);
  const handle=D.HANDLES[run.handleId]||D.HANDLES.leather;
  const handleTint=handle.c2||handle.c1||'#6b4423';
  await appState.engine.applySkin(knifeId,'original',{bladeMask:{active:true,handleGain:1,handleTint,handleDesat:.12,handleMetalness:handle.tex==='metal'?.8:handle.tex==='carbon'?.5:0.05,handleRoughness:handle.tex==='metal'?.42:.72,handleReflection:1.1,guardGain:.88,guardTint:handle.c1||'#4a4e55',guardDesat:.68,guardMetalness:1,guardRoughness:.6,guardReflection:.9}},{fast:true});
  const pack=K3D.bladeSkin.composeBladeSkin({materialId:run.visual.materialId||'M01',textureId:run.visual.textureId||'T04',finishId:run.visual.finishId||'F02',wear:run.visual.wear||0,seed:run.visual.seed||run.seed,patternSeed:hash32(`${run.seed}:${run.path.join('|')}`)%1001});
  appState.engine.applyBladeSkin(knifeId,pack,{texStrength:1});
  appState.currentKnife=knifeId;appState.engine.envMap=appState.viewer.envMap;
  return info
}
function showForgeStage(run,stage){const host=$('#forgeStageHost'); if(!host)return;host.querySelector('.stage-label').textContent=(D.BLADE3D_MAP[run.bladeType]?.en||D.STAGES?.[0]?.en||'FORGE'); host.querySelectorAll('.stage-step i').forEach((e,i)=>e.classList.toggle('on',i<=Math.max(0,['material','melt','forge','fold','quench','temper','edge','handle','tune','appraisal'].indexOf(stage))));
  const model=stage==='material'?'material':stage==='melt'?'melt':(['forge'].includes(stage)?'blank':(['fold','quench','temper','edge','handle','tune','appraisal'].includes(stage)?'knife':'blank'));
  return showStageModel(model,{knifeId:run.bladeType||D.BLADE_TYPES_3D[0].id,run});
}

function homeHTML(){return `<div class="hero"><h1>锻刀大赛</h1><p>选材 · 构筑 · 手艺 · 夺冠</p><div class="en">BLADE FORGE 3D</div></div><div class="home-grid"><button class="tile primary" data-go="forge"><strong>开始锻刀</strong><span>FORGE / 创造一把刀</span></button><button class="tile" data-go="circuit"><strong>赛事</strong><span>CIRCUIT / 带刀出战</span></button><button class="tile" data-go="collection"><strong>藏刀阁</strong><span>COLLECTION / 管理成刀</span></button><button class="tile" data-go="codex"><strong>图鉴</strong><span>CODEX / 解锁进度</span></button><button class="tile" data-go="daily"><strong>每日挑战</strong><span>DAILY / 固定种子</span></button><button class="tile" data-reset="1"><strong>重置存档</strong><span>LOCAL SAVE / 本机数据</span></button></div><div class="footer-note">材料 + 卡牌 + Forge Trait ≈ 80% · 小游戏 ≈ 10–20%<br>3D Viewer 只负责呈现结果，数据层决定成刀。</div>`}
function renderHome(){const el=$('#homeScreen');el.innerHTML=homeHTML();el.onclick=e=>{const go=e.target.closest('[data-go]')?.dataset.go;if(go){if(go==='forge')startForge();else if(go==='circuit')renderCircuitHome();else showScreen(go);renderCurrent()}if(e.target.closest('[data-reset]')){localStorage.removeItem(STORE);appState.save=loadSave();toast('已重置本机存档');renderHome();renderHeader()}};showScreen('home')}
function renderCurrent(){if(appState.screen==='home')renderHome();else if(appState.screen==='forge')renderForge();else if(appState.screen==='circuit')renderCircuitHome();else if(appState.screen==='collection')renderCollection();else if(appState.screen==='codex')renderCodex();else if(appState.screen==='daily')renderDaily()}

function startForge(mode='normal'){appState.run=createRun(randomSeed(),mode);appState.run.stage='material';appState.selectedCard=null;appState.stageCards=[];appState.stageCardsStage=null;showScreen('forge');renderForge()}
function renderForge(){const run=appState.run;if(!run){startForge();return}const el=$('#forgeScreen');el.innerHTML=`<div class="section-head"><div><h2>${stageName(run.stage)}</h2><small>${stageEn(run.stage)}</small></div><small>${stageStatusText(run)}</small></div><div id="forgeStageHost" class="stage-shell"><div class="stage3d"></div><span class="stage-label">3D STAGE</span><div class="stage-step">${Array.from({length:10},(_,i)=>`<i class="${i===0?'on':''}"></i>`).join('')}</div><span class="stage-hint">拖动旋转 · 双指缩放</span></div><div class="stats">${D.STAT_KEYS.slice(0,6).map(k=>`<div class="stat"><span>${D.STAT_CN[k]}</span><b>${Math.round(run.stats[k])}</b></div>`).join('')}</div><div id="forgeBody" style="flex:1;min-height:0;display:flex;flex-direction:column"></div>`;
  renderForgeBody();showForgeStage(run,run.stage)
}
function stageName(s){return({material:'原料',melt:'熔炼',forge:'锻打',fold:'定型',quench:'淬火',temper:'回火',edge:'开刃',handle:'装配',tune:'最终调校',appraisal:'鉴定',failed:'锻造失败',finished:'完成'})[s]||s}
function stageEn(s){return({material:'MATERIAL',melt:'MELTING',forge:'FORGING',fold:'FORMING',quench:'QUENCHING',temper:'TEMPERING',edge:'EDGING',handle:'MOUNTING',tune:'FINAL TUNE',appraisal:'APPRAISAL',failed:'FAILED'})[s]||'FORGE'}
function renderForgeBody(){const run=appState.run,body=$('#forgeBody');if(!body)return;if(run.stage==='failed'){body.innerHTML=`<div class="metric-card"><b>锻造失败</b><span>${run.failureStage==='forge'?'锻打失控，锻造路线中断。':'淬火失控，刀胚未能稳定下来。'}</span><p style="font-size:10px;color:var(--muted);line-height:1.5;margin-top:8px">本次关键判定 Risk ${Math.round(run.lastRiskCheck?.risk||run.riskPeak||0)}%，失败结果已记录。高风险不是纯负面：它允许你继续赌，但也可能直接结束本局。</p></div><div class="action-row"><button class="btn ghost" id="discardFailed">返回首页</button><button class="btn main" id="retryFailed">重新锻刀</button></div>`;$('#discardFailed').onclick=()=>{appState.run=null;renderHome()};$('#retryFailed').onclick=()=>startForge(run.mode);return}if(run.stage==='material'){if(appState.stageCardsStage!=='material'||!appState.stageCards.length){const mats=materialCandidates(run);appState.stageCards=mats;appState.stageCardsStage='material'}const mats=appState.stageCards;body.innerHTML=`<div class="cards">${mats.map(m=>`<button class="card" data-mat="${m.id}" ${rarityStyle(m.rarity)}><span class="rarity">${rnames[m.rarity]}</span><div class="icon">⬢</div><strong>${m.name}</strong><p>${m.flavor}</p><div class="mini-stats">${fmtStats({...D.BASE_STATS,...m.stats})}</div><div class="risk">BASE RISK +${m.baseRisk}%</div></button>`).join('')}</div><div class="action-row"><button class="btn main" id="confirmChoice" disabled>选择原料</button></div>`;let sel=null;body.onclick=e=>{const b=e.target.closest('[data-mat]');if(!b)return;sel=D.MATERIALS.find(x=>x.id===b.dataset.mat);body.querySelectorAll('.card').forEach(x=>x.classList.toggle('sel',x===b));$('#confirmChoice').disabled=false;$('#confirmChoice').onclick=()=>selectMaterial(sel)};return}if(['melt','forge','fold','quench','temper','edge','handle'].includes(run.stage)){if(appState.stageCardsStage!==run.stage||!appState.stageCards.length){appState.stageCards=pickCards(run,run.stage,3);appState.stageCardsStage=run.stage}const cards=appState.stageCards;body.innerHTML=`<div class="cards">${cards.map(c=>cardHTML(c,run)).join('')}</div>${run.stage==='fold'?`<div style="flex:none;display:flex;gap:6px;overflow:auto;padding:0 0 7px">${D.BLADE_TYPES_3D.map(x=>`<button class="btn ghost" data-knife="${x.id}" style="height:34px;padding:0 9px;font-size:9px;white-space:nowrap;${run.bladeType===x.id?'border-color:var(--ink);color:var(--ink)':''}">${x.name}</button>`).join('')}</div>`:''}<div class="action-row"><button class="btn ghost" id="refreshCards">刷新 ${Math.min(20,10+run.counts[run.stage]*5)} CR</button><button class="btn main" id="confirmCard" disabled>确认工艺</button></div>`;let sel=null;body.onclick=e=>{const k=e.target.closest('[data-knife]');if(k){run.bladeType=k.dataset.knife;showStageModel('knife',{run,knifeId:run.bladeType});body.querySelectorAll('[data-knife]').forEach(x=>x.style.borderColor=x===k?'var(--ink)':'');body.querySelectorAll('[data-knife]').forEach(x=>x.style.color=x===k?'var(--ink)':'');return}const b=e.target.closest('[data-card]');if(b){sel=cards.find(x=>x.id===b.dataset.card);body.querySelectorAll('.card').forEach(x=>x.classList.toggle('sel',x===b));$('#confirmCard').disabled=false}if(e.target.id==='confirmCard'&&sel)selectForgeCard(sel);if(e.target.id==='refreshCards'){const cost=Math.min(20,10+run.counts[run.stage]*5);if(appState.save.cr>=cost){appState.save.cr-=cost;appState.stageCards=[];appState.stageCardsStage=null;save();renderForge()}else toast('CR 不足')}};return}if(run.stage==='tune'){body.innerHTML=`<div class="mini-stage"><div class="trace-wrap"><canvas id="traceCanvas"></canvas><span class="trace-label">FOLLOW THE EDGE</span></div><div class="mini-help">沿着发光刃线滑动，尽量贴近路径。重点是稳定，不是速度。</div><button class="btn main" id="tuneStart">开始精修</button><div class="result-pop" id="miniResult"></div></div>`;prepareTuneGame();return}if(run.stage==='appraisal'){renderAppraisal();return}}
function cardHTML(c,run){const stats=c.stats||{};return `<button class="card" data-card="${c.id}" ${rarityStyle(c.rarity)}><span class="rarity">${rnames[c.rarity]}</span><div class="icon">${iconFor(c.icon)}</div><strong>${c.name}</strong><p>${c.desc}</p><div class="mini-stats">${D.STAT_KEYS.filter(k=>stats[k]).slice(0,6).map(k=>`<i>${D.STAT_CN[k]} ${stats[k]>0?'+':''}${stats[k]}</i>`).join('')}</div>${cardRisk(c,run)?`<div class="risk">RISK +${cardRisk(c,run)}%</div>`:''}</button>`}
function iconFor(i){return({flame:'🔥',snow:'❄️',scale:'◉',wind:'〰',anvil:'▣',hand:'✦',spiral:'◌',bolt:'ϟ',drop:'◇',eye:'◉',gem:'◆',moon:'☾',sun:'☀',hammer:'⬟',blade:'▱',shield:'⬡',needle:'⌁',cross:'✚',wave:'〰'}[i]||'◆')}
function selectMaterial(m){const run=appState.run;run.material=m;for(const k of D.STAT_KEYS)run.stats[k]+=m.stats?.[k]||0;run.risk=m.baseRisk||0;run.riskPeak=run.risk;run.materialTraits=m.trait?[m.trait]:[];run.visual.materialId=D.materialToSkinMaterialId(m);run.stage='melt';appState.stageCards=[];appState.stageCardsStage=null;toast(`已选 ${m.name}`);renderForge()}
function nextStage(s){const seq=['material','melt','forge','fold','quench','temper','edge','handle','tune','appraisal'];return seq[seq.indexOf(s)+1]||'appraisal'}
function selectForgeCard(card){const run=appState.run;const stage=run.stage;applyCard(run,card);appState.stageCards=[];appState.stageCardsStage=null;if(stage==='forge')run.miniTarget=run.counts.forge;else if(stage==='quench')run.miniTarget=run.quench||'water';run.stage=nextStage(stage);if(stage==='forge')run.visual.textureId=pickTextureId(run,card);if(stage==='quench')run.visual.finishId=D.QUENCH_FINISH_MAP[run.quench]||'F02';if(stage==='fold'&&!run.bladeType)run.bladeType=D.BLADE_TYPES_3D[hash32(run.seed+'blade')%D.BLADE_TYPES_3D.length].id;if(stage==='handle'&&run.handleId==null)run.handleId='leather';if(run.stage==='appraisal')finishForge();else if(stage==='forge'||stage==='quench')startMini(stage);else renderForge()}
function startMini(type){appState.run.stage='mini_'+type;showScreen('forge');const run=appState.run;const body=$('#forgeBody'),host=$('#forgeStageHost');if(!body||!host)return;showStageModel(type==='forge'?'blank':'knife',{run,stage:type,knifeId:run.bladeType||D.BLADE_TYPES_3D[0].id,host:host.querySelector('.stage3d')});body.innerHTML=`<div class="mini-stage"><div class="mini-title"><b>${type==='forge'?'HAMMER / 锤击':'QUENCH / 控温'}</b><span>${type==='forge'?'TIMING STRIKE':'TEMPERATURE WINDOW'}</span></div><div class="mini-track" id="miniTrack"><div class="zone"></div><div class="marker" id="miniMarker"></div></div><button class="mini-large-btn" id="miniTap">${type==='forge'?'落锤':'淬火'}</button><div class="mini-help">${type==='forge'?'点击时机决定这一锤的质量。':'温度不断下降，在金色窗口点击停止。'} PERFECT / GREAT / GOOD / MISS</div><div class="result-pop" id="miniResult"></div></div>`;runMiniTiming(type)}
function runMiniTiming(type){const marker=$('#miniMarker');let start=performance.now();let duration=type==='forge'?1500:2100;let stopped=false;function tick(now){if(stopped)return;let t=((now-start)%duration)/duration;let x=.08+.84*(.5+.5*Math.sin(t*Math.PI*2));marker.style.left=(x*100)+'%';requestAnimationFrame(tick)}requestAnimationFrame(tick);$('#miniTap').onclick=()=>{if(stopped)return;stopped=true;const x=parseFloat(marker.style.left)/100;const rating=miniScoreFromPos(x);applyMiniResult(type,rating);};}
function riskBreakCheck(run,type,rating){
  const riskBefore=run.risk||0;
  const missBoost=rating==='miss'?1.28:1;
  const stageBase=type==='forge'?0.0065:0.007;
  const chance=clamp(riskBefore*stageBase*missBoost,0,0.30);
  const roll=seeded(hash32(`${run.seed}:risk:${type}:${run.path.length}:${run.miniResults[type]?.score||0}`))();
  run.lastRiskCheck={type,risk:riskBefore,chance,roll};
  run.risk=0;
  if(roll<chance){run.lastFailure=true;run.failureStage=type;run.stage='failed';return true}
  return false;
}
function applyMiniResult(type,rating){
  const run=appState.run;
  const mult=miniMult(rating);
  run.miniResults[type]={type,rating,score:Math.round(mult*100),multiplier:mult,perfect:rating==='perfect',miss:rating==='miss'};
  const broke=riskBreakCheck(run,type,rating);
  if(broke){resolveTraitsAfterCard(run,{tags:[]});const pop=$('#miniResult');if(pop){pop.textContent='BREAK';pop.className='result-pop show'}setTimeout(()=>renderForge(),650);return}
  if(type==='forge'){
    const c=run.path.length?D.CARDS.find(x=>x.id===run.path[run.path.length-1]):null;
    for(const k of D.STAT_KEYS)if(c?.stats?.[k])run.stats[k]+=Math.round(c.stats[k]*(mult-1));
    if(rating==='miss')run.lastFailure=true;
    run.counts.forge=Math.max(1,run.counts.forge);
    run.stage='fold';
  }else{
    if(rating==='perfect'){run.stats.toughness+=7;run.stats.edge+=5}
    else if(rating==='great')run.stats.toughness+=4;
    else if(rating==='miss'){run.riskPeak=Math.max(run.riskPeak||0,run.risk+8);run.lastFailure=true}
    run.stage='temper';
  }
  resolveTraitsAfterCard(run,{tags:[]});
  const pop=$('#miniResult');
  if(pop){pop.textContent=rating.toUpperCase();pop.className='result-pop show';setTimeout(()=>renderForge(),550)}else renderForge()
}
function finishForge(){const run=appState.run;if(appState.save?.meta?.unlockedForgeTraits?.includes('forge_master_hand')&&['hammer','quench','tune'].every(k=>run.miniResults[k]?.rating&&run.miniResults[k].rating!=='miss'))run.forgeTraits.push('forge_master_hand');run.forgeTraits=[...new Set(run.forgeTraits)];applyForgeTraitStats(run);run.visual.materialId=D.materialToSkinMaterialId(run.material);run.visual.finishId=D.QUENCH_FINISH_MAP[run.quench]||'F02';run.visual.textureId=run.visual.textureId||'T04';run.score=Math.round(D.STAT_KEYS.reduce((a,k)=>a+run.stats[k],0)/6);const traitBonus=run.forgeTraits.length*7;run.score+=traitBonus;const q=D.QUALITY.find(x=>run.score>=x.min)||D.QUALITY[D.QUALITY.length-1];run.rarity=q.rarity;run.quality=q.name;run.cr=q.cr;run.stage='appraisal';renderForge()}
function renderAppraisal(){const run=appState.run,el=$('#forgeScreen');el.innerHTML=`<div class="section-head"><div><h2>鉴定结果</h2><small>APPRAISAL</small></div><small>${run.score} SCORE</small></div><div id="forgeStageHost" class="stage-shell"><div class="stage3d"></div><span class="stage-label">FINAL BLADE</span><span class="stage-hint">拖动旋转检查刀身效果</span></div><div class="section-head"><div><h2>${bladeName(run.bladeType)} · ${run.material.name}</h2><small style="color:${rcolors[run.rarity]}">${rnames[run.rarity].toUpperCase()}</small></div></div><div class="stats">${D.STAT_KEYS.map(k=>`<div class="stat"><span>${D.STAT_CN[k]}</span><b>${Math.round(run.stats[k])}</b></div>`).join('')}</div><div class="list"><div class="trait" style="--tc:${rcolors[run.rarity]}"><b>Forge Trait</b><span>${run.forgeTraits.length?run.forgeTraits.map(id=>D.FORGE_TRAIT_DEFS.find(x=>x.id===id)?.name||id).join(' · '):'本局没有额外锻刀特性'}</span></div><div class="trait" style="--tc:#6E7BFF"><b>组合 / 固有特性</b><span>${run.combos.length?run.combos.map(id=>D.COMBOS.find(x=>x.id===id)?.id||id).join(' · '):'暂无隐藏组合'}${run.traits.length?' · '+run.traits.map(id=>D.TRAITS.find(x=>x.id===id)?.name||id).join(' · '):''}</span></div><div class="trait" style="--tc:#6E7BFF"><b>外观配方</b><span>${run.visual.materialId} · ${run.visual.textureId} · ${run.visual.finishId} · ${run.handleId}</span></div></div><div class="action-row"><button class="btn ghost" id="redoForge">再锻一把</button><button class="btn main" id="saveBlade">收入藏刀阁 +${run.cr} CR</button></div>`;showStageModel('knife',{run,knifeId:run.bladeType,host:document.querySelector('#forgeStageHost .stage3d')});$('#saveBlade').onclick=()=>saveBlade();$('#redoForge').onclick=()=>startForge()}
function bladeName(id){return D.BLADE3D_MAP[id]?.name||'未知刀型'}
function renderFailedForge(){renderForge()}
function checkAchievements(){const s=appState.save;const defs=[['first_blade',s.forgeCount>=1,'初铸','完成第一把成刀'],['five_blades',s.forgeCount>=5,'百炼成钢','完成 5 把成刀'],['first_win',s.winCount>=1,'初战告捷','赢得第一场赛事'],['three_wins',s.winCount>=3,'连胜','累计赢得 3 场赛事'],['collector',s.blades.filter(b=>!b.broken).length>=9,'藏锋','同时保有 9 把未断成刀'],['mythic',s.bestScore>=150,'神话工艺','鉴定出 150 分以上成刀'],['daily_master',s.daily.completed&&s.daily.score>=100,'每日匠心','每日挑战达到 100 分']];const newly=[];for(const [id,ok,name,desc] of defs)if(ok&&!s.achievements[id]){s.achievements[id]={name,desc,date:Date.now()};newly.push(name)}return newly}
function saveBlade(){const run=appState.run;if(run.saved){toast('这把刀已经收入藏刀阁');return}const blade={id:`blade_${Date.now()}_${hash32(run.seed+'blade')}`,name:bladeName(run.bladeType)+' · '+(run.forgeTraits[0]?D.FORGE_TRAIT_DEFS.find(x=>x.id===run.forgeTraits[0])?.name:'锻造品'),material:run.material.name,materialId:run.material.id,bladeType:run.bladeType,stats:statSnapshot(run.stats),rarity:run.rarity,quality:run.quality,score:run.score,cr:run.cr,forgeTraits:[...run.forgeTraits],materialTraits:[...run.materialTraits],traits:[...run.traits],combos:[...run.combos],visual:{...run.visual},handleId:run.handleId,quench:run.quench,edgeStyle:run.edgeStyle,forgePath:[...run.path],riskPeak:run.riskPeak||0,record:{win:0,loss:0,lossCount:0},mastery:0,title:'新铸',broken:false,repairs:0,legacy:null};appState.save.blades.push(blade);appState.save.cr+=run.cr;appState.save.forgeCount++;if(run.daily)appState.save.daily={date:dateKey(),completed:true,score:run.score};appState.save.bestScore=Math.max(appState.save.bestScore,run.score);const unlocked=checkAchievements();run.saved=true;save();toast(unlocked.length?'成就解锁：'+unlocked[0]:'成刀已收入藏刀阁');setTimeout(()=>{showScreen('collection');renderCollection()},450)}

function renderCollection(){const el=$('#collectionScreen');const s=appState.save;el.innerHTML=`<div class="section-head"><div><h2>藏刀阁</h2><small>COLLECTION / ${s.blades.length} BLADES</small></div><button class="btn ghost" id="newForge" style="height:34px;font-size:11px">+ 锻刀</button></div><div class="collection-summary"><span>在库 ${s.blades.filter(b=>!b.broken).length}</span><span>断刀 ${s.blades.filter(b=>b.broken).length}</span><span>最高 ${s.bestScore}</span></div><div class="list">${s.blades.length?s.blades.map(b=>`<div class="list-item" data-blade="${b.id}"><button class="thumb blade-open" data-id="${b.id}"><span style="font-size:22px">▱</span></button><div><h4>${b.name}${b.broken?' · 已断':''}</h4><p>${b.material} · ${bladeName(b.bladeType)}<br>SCORE ${b.score} · ${b.record.win}W / ${b.record.loss}L · ${bladeLegacy(b)} Lv.${bladeMastery(b).level}<br>Mastery ${b.mastery||0} · Loss ${b.record.lossCount}${b.repairs?' · 重铸 '+b.repairs+'次':''}</p><span class="badge" style="${rarityStyle(b.rarity)}">${rnames[b.rarity]}</span></div><button class="btn ghost use-blade" data-id="${b.id}" ${b.broken?'disabled':''} style="height:34px;padding:0 8px;font-size:10px">${b.broken?'已断刀':'出战'}</button></div>`).join(''):'<div class="metric-card"><b>还没有成刀</b><span>先完成一次锻造，再带它进入赛事。</span></div>'}</div>`;$('#newForge').onclick=()=>startForge();el.onclick=e=>{const battle=e.target.closest('.use-blade')?.dataset.id;if(battle){openCircuitForBlade(battle);return}const id=e.target.closest('.blade-open')?.dataset.id;if(id)openBladeDetail(id)};showScreen('collection')}
function openBladeDetail(id){const b=appState.save.blades.find(x=>x.id===id);if(!b)return;const fake={material:{id:b.materialId,name:b.material},visual:{...b.visual},handleId:b.handleId,quench:b.quench,edgeStyle:b.edgeStyle,seed:b.visual?.seed||hash32(b.id),path:b.forgePath||[],stats:b.stats,bladeType:b.bladeType};const cost=bladeRepairCost(b);openModal(`<h3>${b.name}</h3><div class="sub">${bladeName(b.bladeType)} · ${rnames[b.rarity]} · ${b.score} SCORE</div><div class="trait" style="--tc:#D9A63C"><b>传奇履历</b><span>${bladeLegacy(b)} · ${b.record.win} 胜 / ${b.record.loss} 负${b.repairs?' · 重铸 '+b.repairs+' 次':''}</span></div><div id="collectionPreview" class="stage-shell compact-preview"><div class="stage3d"></div><span class="stage-label">BLADE INSPECTOR</span><span class="stage-hint">拖动旋转 · 双指缩放</span></div><div class="stats">${D.STAT_KEYS.map(k=>`<div class="stat"><span>${D.STAT_CN[k]}</span><b>${Math.round(b.stats?.[k]||0)}</b></div>`).join('')}</div><div class="trait"><b>锻造配方</b><span>${b.material} · ${b.visual?.materialId||'-'} · ${b.visual?.textureId||'-'} · ${b.visual?.finishId||'-'} · ${b.handleId||'-'} · ${b.quench||'-'}</span></div><div class="trait"><b>战绩</b><span>Mastery ${b.mastery||0} · Loss Count ${b.record.lossCount} · 峰值 Risk ${b.riskPeak||0}%</span></div><div class="action-row"><button class="btn ghost" id="closeBladeDetail">关闭</button>${b.broken?`<button class="btn main" id="repairBlade">重铸 · ${cost} CR</button>`:'<button class="btn main" id="bladeBattle">选择参赛</button>'}</div>`,root=>{showStageModel('knife',{run:fake,knifeId:b.bladeType,host:document.querySelector('#collectionPreview .stage3d')});$('#closeBladeDetail').onclick=closeModal;$('#bladeBattle')?.addEventListener('click',()=>{closeModal();openCircuitForBlade(b.id)});$('#repairBlade')?.addEventListener('click',()=>{closeModal();repairBlade(b.id)})})}
function openCircuitForBlade(id){const b=appState.save.blades.find(x=>x.id===id);if(!b)return;if(b.broken){toast('这把刀已经断裂，不能参赛');return}appState.circuit={bladeId:id,mode:null,schoolId:null,node:0,round:0,wins:0,rounds:[],matchTrait:null,traitChoices:[]};renderCircuitHome();showScreen('circuit')}

function renderCircuitHome(){const el=$('#circuitScreen');const has=appState.save.blades.some(b=>!b.broken);const cp=appState.save.circuit||{};const schoolWins=cp.schoolWins||{};const nationalDone=!!cp.nationalChampion;el.innerHTML=`<div class="section-head"><div><h2>赛事</h2><small>CIRCUIT / BUILD VALIDATION</small></div><small>${appState.save.winCount} W · ${appState.save.broken} BREAK</small></div><div class="list">${D.SCHOOL_MODES.map(m=>`<button class="circuit-mode" data-mode="school:${m.id}"><strong>${m.cn}</strong><small>${m.name} · ${schoolWins[m.id]||0} W</small><p>${m.desc}</p></button>`).join('')}<button class="circuit-mode" data-mode="national"><strong>NATIONAL CHAMPIONSHIP</strong><small>${nationalDone?'全国冠军已达成':'全国大赛'} · ${nationalDone?'6/6 完成':`${Math.min(6,(cp.nationalNode||0)+1)}/6`}</small><p>资格赛 → 32强 → 16强 → 8强 → 半决赛 → 决赛。${nationalDone?' 可继续挑战刷奖励。':' 晋级进度会自动保存。'}</p></button><button class="circuit-mode" data-mode="global"><strong>GLOBAL APEX</strong><small>全球巅峰赛 · ${cp.globalWins||0} W</small><p>每局附加变化规则，重点考验你选择的成刀 Build。</p></button></div><div class="action-row"><button class="btn main" id="selectBladeBtn" ${has?'':'disabled'}>选择参赛刀${has?'':' · 暂无可用成刀'}</button></div>`;$('#selectBladeBtn').onclick=()=>pickBattleBlade();el.onclick=e=>{const b=e.target.closest('[data-mode]');if(b){if(!has){toast('先锻造一把可用成刀');return}pickBattleBlade(b.dataset.mode)}};showScreen('circuit')}
function pickBattleBlade(mode=null){const blades=appState.save.blades.filter(b=>!b.broken);if(!blades.length){toast('当前没有可参赛的成刀');return}openModal(`<h3>选择参赛刀</h3><div class="sub">SELECT BLADE${mode?' · '+mode.toUpperCase():''}</div>${blades.map(b=>`<button class="circuit-mode" data-pick="${b.id}"><strong>${b.name}</strong><small>${bladeName(b.bladeType)} · ${rnames[b.rarity]} · ${b.score} · ${b.record.win}W/${b.record.loss}L</small></button>`).join('')}`,(root)=>{root.onclick=e=>{const id=e.target.closest('[data-pick]')?.dataset.pick;if(id){closeModal();openCircuitForBlade(id);if(mode)startCircuit(mode)}}})}
function startCircuit(mode){if(!appState.circuit?.bladeId){pickBattleBlade(mode);return}const b=appState.save.blades.find(x=>x.id===appState.circuit.bladeId);if(!b||b.broken){toast('参赛刀不可用');return}if(mode.startsWith('school:')){appState.circuit.mode='school';appState.circuit.schoolId=mode.split(':')[1];appState.circuit.node=0}else{appState.circuit.mode=mode;appState.circuit.schoolId=null;appState.circuit.node=mode==='national'?Math.min(5,appState.save.circuit?.nationalNode||0):0}appState.circuit.round=0;appState.circuit.wins=0;appState.circuit.rounds=[];appState.circuit.matchTrait=null;appState.circuit.globalRule=appState.circuit.mode==='global'?D.GLOBAL_RULES[hash32(`${b.id}:${appState.circuit.node}:globalRule`)%D.GLOBAL_RULES.length]:null;appState.circuit.metricOrder=['POWER','CONTROL','ART'];if(appState.circuit.globalRule?.metric==='RANDOM'){const rr=seeded(hash32(`${b.id}:${appState.circuit.node}:order`));for(let i=appState.circuit.metricOrder.length-1;i>0;i--){const j=Math.floor(rr()*(i+1));[appState.circuit.metricOrder[i],appState.circuit.metricOrder[j]]=[appState.circuit.metricOrder[j],appState.circuit.metricOrder[i]]}}chooseMatchTrait()}
function pickMatchTraits(){const c=appState.circuit;if(!c)return D.MATCH_TRAITS.slice(0,3);const unlocked=appState.save.meta?.unlockedMatchTraits||['overdrive','steady_hand','showtime'];const pool=D.MATCH_TRAITS.filter(t=>unlocked.includes(t.id));const safePool=pool.length>=3?pool:D.MATCH_TRAITS.slice(0,3);const out=[];const used=new Set();const rr=seeded(hash32(`${c.bladeId}:${c.mode}:${c.schoolId||''}:${c.node}:trait`));while(out.length<Math.min(3,safePool.length)){const t=safePool[Math.floor(rr()*safePool.length)];if(used.has(t.id))continue;used.add(t.id);out.push(t)}return out}
function chooseMatchTrait(){const c=appState.circuit;const choices=pickMatchTraits();c.traitChoices=choices;openModal(`<h3>赛前选择 Match Trait</h3><div class="sub">临场策略 · 本场有效</div><p>同一把刀，不同的比赛可以采用不同策略。选择一个本场生效的 Match Trait。</p>${choices.map(t=>`<button class="circuit-mode" data-trait="${t.id}"><strong>${t.name}</strong><small>${rnames[t.rarity]}</small><p>${t.description}</p></button>`).join('')}`,(root)=>{root.onclick=e=>{const id=e.target.closest('[data-trait]')?.dataset.trait;if(!id)return;c.matchTrait=choices.find(t=>t.id===id)||choices[0];closeModal();renderMatch()}})}
function bladeMastery(b){const m=Number(b?.mastery||0);return{xp:m,level:Math.min(6,1+Math.floor(m/25)),title:b?.title||(['新铸','初露锋芒','百战淬锋','名匠之刃','宗师佩刃','传世名锋','神兵'][Math.min(6,1+Math.floor(m/25))]||'新铸')}}
function bladeLegacy(b){if(!b)return '新铸';const w=Number(b.record?.win||0),l=Number(b.record?.loss||0),m=Number(b.mastery||0),s=Number(b.score||0),r=Number(b.repairs||0);if(w>=10)return '十胜名锋';if(w>=6)return '赛场名刃';if(s>=150)return '神话工艺';if(m>=125)return '传世名锋';if(r>=2)return '百炼旧锋';if(l>=3)return '百战淬锋';return bladeMastery(b).title}
function bladeRepairCost(b){return Math.max(60,Math.min(220,Math.round((Number(b.score||80)*0.65))))}
function repairBlade(id){const b=appState.save.blades.find(x=>x.id===id);if(!b||!b.broken)return;if((appState.save.cr||0)<bladeRepairCost(b)){toast('CR 不足，无法重铸');return}const cost=bladeRepairCost(b);appState.save.cr-=cost;b.broken=false;b.repairs=Number(b.repairs||0)+1;b.record=b.record||{win:0,loss:0,lossCount:0};b.legacy=bladeLegacy(b);save();renderHeader();toast(`重铸完成 · -${cost} CR`);openBladeDetail(id)}
function applyBladeMastery(b,won){if(!b)return;const gain=won?10:3;b.mastery=Number(b.mastery||0)+gain;const m=bladeMastery(b);b.title=m.title;b.legacy=bladeLegacy(b);return gain}
function computeMetrics(b){const s=b.stats,m=bladeMastery(b),bonus=1+(m.level-1)*0.012;return{POWER:(s.strength+s.edge)/2*bonus,CONTROL:(s.toughness+s.craft)/2*bonus,ART:(s.design+s.spirit)/2*bonus}}
function opponentFor(circuit,round){const b=appState.save.blades.find(x=>x.id===circuit.bladeId);const node=circuit.mode==='national'?circuit.node:0;const base=(b?.score||60)*.72 + 32 + node*5 + round*6 + (circuit.mode==='global'?8:0) + (circuit.mode==='school'&&circuit.schoolId?2:0);const r=seeded(hash32(`${circuit.bladeId}:${circuit.mode}:${circuit.schoolId||''}:${node}:${round}`));const variance=()=>base*(.86+r()*.22);const out={POWER:variance(),CONTROL:variance(),ART:variance()};if(circuit.mode==='school'&&circuit.schoolId){const mode=D.SCHOOL_MODES.find(x=>x.id===circuit.schoolId);for(const key of mode?.focus||[])out[key]*=1.08}const names=['赤铁学徒','霜刃大师','折纹匠','精密猎手','世界客座匠师','钢魂挑战者','星铸评审'];return{...out,name:names[Math.floor(r()*names.length)]||'对手',code:`OP-${100+node*13+round*7+Math.floor(r()*80)}`}}
function renderMatch(){const c=appState.circuit,b=appState.save.blades.find(x=>x.id===c.bladeId);if(!b||b.broken){toast('参赛刀已不可用');renderCircuitHome();return}const metric=(c.metricOrder||['POWER','CONTROL','ART'])[c.round%3];const mm=computeMetrics(b);const opp=opponentFor(c,c.round);const nodeNames=['资格赛','32强','16强','8强','半决赛','决赛'];const title=c.mode==='national'?'全国大赛':c.mode==='global'?'全球巅峰':D.SCHOOL_MODES.find(x=>x.id===c.schoolId)?.cn||'流派试炼';const nodeLabel=c.mode==='national'?`${nodeNames[c.node]||'节点 '+(c.node+1)} · ${c.node+1}/6`:c.mode==='global'?'APEX RUN':'SCHOOL TRIAL';const activeRule=c.mode==='global'?c.globalRule:null;const el=$('#circuitScreen');el.innerHTML=`<div class="section-head"><div><h2>${title}</h2><small>${nodeLabel} · ${metric} · ROUND ${c.round+1}/3</small></div><small>${c.wins} W</small></div>${activeRule?`<div class="trait" style="--tc:#FF7A29"><b>GLOBAL RULE</b><span>${activeRule.name}${activeRule.metric!=='RANDOM'?' · '+activeRule.metric+' × '+activeRule.factor:' · 本场随机判定顺序'}</span></div>`:''}<div class="match-box"><div class="versus"><div class="fighter"><b>${b.name}</b><span>${rnames[b.rarity]} · SCORE ${b.score}</span></div><div class="vs">VS</div><div class="fighter"><b>${opp.name}</b><span>${opp.code}</span></div></div><div class="bars">${['POWER','CONTROL','ART'].map(k=>`<div class="bar-row"><span>${k}</span><div class="bar"><i style="width:${clamp(mm[k]/Math.max(mm[k],opp[k])*100,8,100)}%"></i></div><span>${Math.round(mm[k])} / ${Math.round(opp[k])}</span></div>`).join('')}</div></div><div class="trait" style="--tc:#6E7BFF"><b>Match Trait</b><span>${c.matchTrait?c.matchTrait.name+' · '+c.matchTrait.description:'待选择'}</span></div><div class="round-head"><b>回合</b><div class="round-dots">${[0,1,2].map(i=>`<i class="${c.rounds[i]?.win?'win':c.rounds[i]?'lose':''}"></i>`).join('')}</div></div><div class="mini-stage" style="justify-content:flex-start;padding-top:14px"><div class="mini-title"><b>${metric} 小游戏</b><span>判定形式随机 · 操作只提供有限修正</span></div><button class="mini-large-btn" id="matchStart">开始 ${metric}</button><div class="mini-help">Build 是主体，小游戏只是把你已经锻好的刀发挥出来。</div><div class="result-pop" id="miniResult"></div></div>`;$('#matchStart').onclick=()=>runMatchMini(metric,mm[metric],opp[metric])}
function runMatchMini(metric,player,enemy){const c=appState.circuit;const host=$('#circuitScreen .mini-stage');const trait=c.matchTrait||D.MATCH_TRAITS[0];const factor=trait.effect?.[metric]||1;const template=hash32(`${c.bladeId}:${c.node}:${c.round}:${metric}:template`)%3;host.onpointerdown=null;host.onpointerup=null;let finishOnce=false;const finish=(quality)=>{if(finishOnce)return;finishOnce=true;finishMatchRound(metric,player,enemy,factor,quality)};
  if(metric==='ART'){
    const mode=template;
    if(mode===0){host.innerHTML=`<div class="mini-title"><b>ART / 图纹匹配</b><span>找出与刀身纹理一致的图案</span></div><div style="display:flex;gap:10px;justify-content:center">${[0,1,2].map(i=>`<button class="tile" data-art="${i}" style="width:84px;height:84px;align-items:center;justify-content:center;font-size:24px">${['◈','✦','✥'][(hash32(c.bladeId+':pat')+i)%3]}</button>`).join('')}</div><div class="mini-help">选择正确纹理。</div>`;const correct=hash32(`${c.bladeId}:${c.node}:${c.round}:art:0`)%3;host.onclick=e=>{const x=e.target.closest('[data-art]')?.dataset.art;if(x!=null)finish(Number(x)===correct?'perfect':'miss')};
    }else if(mode===1){host.innerHTML=`<div class="mini-title"><b>ART / 视觉抉择</b><span>在三种构图中选出最契合的刀型气质</span></div><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;width:100%">${[0,1,2].map(i=>`<button class="tile" data-art="${i}" style="height:76px;font-size:13px">${['锐','衡','魂'][i]}</button>`).join('')}</div><div class="mini-help">关注刀型与纹理是否统一。</div>`;const correct=hash32(`${c.bladeId}:${c.node}:${c.round}:art:1`)%3;host.onclick=e=>{const x=e.target.closest('[data-art]')?.dataset.art;if(x!=null)finish(Number(x)===correct?'perfect':'miss')};
    }else{host.innerHTML=`<div class="mini-title"><b>ART / 精准描线</b><span>拖过亮点路径，完成一次短笔触</span></div><div class="trace-wrap" style="height:140px"><canvas id="matchTrace"></canvas></div><div class="mini-help">从左向右沿金色轨迹滑动，偏离越小越好。</div>`;const canvas=$('#matchTrace');const dpr=Math.min(2,devicePixelRatio||1);canvas.width=canvas.clientWidth*dpr;canvas.height=canvas.clientHeight*dpr;const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);const w=canvas.clientWidth,h=canvas.clientHeight;const pts=[];for(let i=0;i<=80;i++){const t=i/80;pts.push({x:18+t*(w-36),y:h*.55+Math.sin(t*Math.PI*2)*20})}ctx.strokeStyle='#D9A63C';ctx.globalAlpha=.3;ctx.lineWidth=6;ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();let active=false,err=0,n=0;const pos=e=>{const r=canvas.getBoundingClientRect(),p=e.touches?.[0]||e;return{x:p.clientX-r.left,y:p.clientY-r.top}};canvas.onpointerdown=e=>{active=true;err=0;n=0;e.preventDefault()};canvas.onpointermove=e=>{if(!active)return;const q=pos(e),idx=clamp(Math.round((q.x-18)/(w-36)*80),0,80),t=pts[idx];err+=Math.hypot(q.x-t.x,q.y-t.y);n++;e.preventDefault()};canvas.onpointerup=()=>{if(!active)return;active=false;const avg=n?err/n:999;finish(avg<8?'perfect':avg<15?'great':avg<25?'good':'miss')};
    }
    return;
  }
  if(metric==='POWER'&&template===2){host.innerHTML=`<div class="mini-title"><b>POWER / 连击落锤</b><span>连续 3 次点击，平均命中金色窗口</span></div><div class="mini-track"><div class="zone"></div><div class="marker" id="burstMarker"></div></div><button class="mini-large-btn" id="burstTap">第 1 锤</button><div class="mini-help" id="burstHelp">还需要 3 次</div>`;let start=performance.now(),dur=1050,stopped=false,qualities=[];const marker=$('#burstMarker');const tick=now=>{if(stopped)return;const t=((now-start)%dur)/dur;marker.style.left=(.08+.84*(.5+.5*Math.sin(t*Math.PI*2)))+'%';requestAnimationFrame(tick)};requestAnimationFrame(tick);$('#burstTap').onclick=()=>{const q=miniScoreFromPos(parseFloat(marker.style.left)/100);qualities.push(q);if(qualities.length>=3){stopped=true;const rank={perfect:3,great:2,good:1,miss:0},score=qualities.reduce((a,q)=>a+rank[q],0)/3;finish(score>=2.6?'perfect':score>=1.8?'great':score>=.8?'good':'miss')}else{$('#burstTap').textContent='第 '+(qualities.length+1)+' 锤';$('#burstHelp').textContent='还需要 '+(3-qualities.length)+' 次'}};return}
  if(metric==='POWER'&&template===1){host.innerHTML=`<div class="mini-title"><b>POWER / Charge Stop</b><span>蓄力越接近中心，释放越精准</span></div><div class="mini-track"><div class="zone" style="left:44%;width:12%"></div><div class="marker" id="chargeMarker"></div></div><button class="mini-large-btn" id="chargeTap">释放蓄力</button>`;let start=performance.now(),dur=1900,stopped=false,marker=$('#chargeMarker');const tick=now=>{if(stopped)return;const t=((now-start)%dur)/dur;marker.style.left=(.08+.84*(.5+.5*Math.sin(t*Math.PI)))+'%';requestAnimationFrame(tick)};requestAnimationFrame(tick);$('#chargeTap').onclick=()=>{stopped=true;finish(miniScoreFromPos((parseFloat(marker.style.left)/100)))};return}
  if(metric==='CONTROL'&&template===1){host.innerHTML=`<div class="mini-title"><b>CONTROL / Reaction Chain</b><span>按顺序点亮 4 个稳定节点</span></div><div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;width:100%">${[0,1,2,3].map(i=>`<button class="tile" data-rx="${i}" style="height:64px;font-size:18px">${i+1}</button>`).join('')}</div><div class="mini-help" id="rxHelp">第 1 个</div>`;const order=[0,1,2,3];const rr=seeded(hash32(`${c.bladeId}:${c.node}:${c.round}:rx`));for(let i=order.length-1;i>0;i--){const j=Math.floor(rr()*(i+1));[order[i],order[j]]=[order[j],order[i]]};let idx=0,wrong=false;host.onclick=e=>{const x=e.target.closest('[data-rx]')?.dataset.rx;if(x==null||wrong)return;if(Number(x)!==Number(order[idx])){wrong=true;finish('miss');return}idx++;if(idx>=4)finish('perfect');else $('#rxHelp').textContent='第 '+(idx+1)+' 个'};return}
  if(metric==='CONTROL'&&template===2){host.innerHTML=`<div class="mini-title"><b>CONTROL / Rhythm Control</b><span>跟随 4 拍节奏点击</span></div><div class="mini-track" id="rhythmTrack"><div class="zone"></div><div class="marker" id="rhythmMarker"></div></div><button class="mini-large-btn" id="rhythmTap">第 1 拍</button><div class="mini-help" id="rhythmHelp">还需要 4 拍</div>`;let start=performance.now(),dur=1200,stopped=false,qs=[];const marker=$('#rhythmMarker');const tick=now=>{if(stopped)return;const t=((now-start)%dur)/dur;marker.style.left=(.08+.84*(.5+.5*Math.sin(t*Math.PI*2)))+'%';requestAnimationFrame(tick)};requestAnimationFrame(tick);$('#rhythmTap').onclick=()=>{qs.push(miniScoreFromPos(parseFloat(marker.style.left)/100));if(qs.length>=4){stopped=true;const rank={perfect:3,great:2,good:1,miss:0},avg=qs.reduce((a,q)=>a+rank[q],0)/4;finish(avg>=2.5?'perfect':avg>=1.7?'great':avg>=.8?'good':'miss')}else{$('#rhythmTap').textContent='第 '+(qs.length+1)+' 拍';$('#rhythmHelp').textContent='还需要 '+(4-qs.length)+' 拍'}};return}
  if(metric==='CONTROL'&&template===0){host.innerHTML=`<div class="mini-title"><b>CONTROL / Balance Hold</b><span>把指针稳在中心，按住后松开</span></div><div class="mini-track"><div class="zone"></div><div class="marker" id="holdMarker"></div></div><button class="mini-large-btn" id="holdBtn">按住稳定</button><div class="mini-help">保持 1.2 秒。</div>`;let start=performance.now(),dur=1500,active=false,err=0,last=0,raf=0;const marker=$('#holdMarker');const tick=now=>{if(!active)return;const t=((now-last)%900)/900;marker.style.left=(.08+.84*(.5+.5*Math.sin(t*Math.PI*2)))+'%';const pos=parseFloat(marker.style.left)/100;err+=Math.abs(pos-.5);last=now;raf=requestAnimationFrame(tick)};const end=()=>{if(!active)return;active=false;cancelAnimationFrame(raf);const avg=err/Math.max(1,(performance.now()-start)/16);finish(avg<.055?'perfect':avg<.09?'great':avg<.14?'good':'miss')};const btn=$('#holdBtn');btn.onpointerdown=e=>{active=true;start=last=performance.now();err=0;tick(start);e.preventDefault()};btn.onpointerup=end;btn.onpointercancel=end;btn.onpointerleave=end;return}
  let start=performance.now(),dur=metric==='POWER'?1200:1600,stopped=false,markerId=metric==='POWER'?'matchMarker':'matchMarker';host.innerHTML=`<div class="mini-title"><b>${metric} / Timing Strike</b><span>把指针停在金色窗口</span></div><div class="mini-track"><div class="zone"></div><div class="marker" id="${markerId}"></div></div><button class="mini-large-btn" id="matchTap">${metric}</button><div class="mini-help">PERFECT / GREAT / GOOD / MISS</div>`;let marker=$( '#'+markerId);const loop=now=>{if(stopped)return;const t=((now-start)%dur)/dur;const x=.08+.84*(.5+.5*Math.sin(t*Math.PI*2));marker.style.left=x*100+'%';requestAnimationFrame(loop)};requestAnimationFrame(loop);$('#matchTap').onclick=()=>{stopped=true;finish(miniScoreFromPos(parseFloat(marker.style.left)/100))}}

function finishMatchRound(metric,player,enemy,factor,quality){
  const c=appState.circuit,b=appState.save.blades.find(x=>x.id===c.bladeId);if(!b)return;
  let pf=miniMult(quality);
  const trait=c.matchTrait||D.MATCH_TRAITS[0];
  if(trait.effect?.riskPower&&metric==='POWER')pf*=1+Math.min(0.15,(b.riskPeak||0)*trait.effect.riskPower);
  if(trait.effect?.round3&&c.round===2)pf*=trait.effect.round3;
  if(trait.effect?.early&&c.round<2)pf*=trait.effect.early;
  const legacyTraits=[...(b.traits||[]),...(b.materialTraits||[])];
  for(const id of legacyTraits){const t=D.TRAITS.find(x=>x.id===id);const tests=t?.effect?.tests||{};let vals=[];if(metric==='POWER'){if(tests.strength)vals.push(tests.strength);if(tests.sharpness)vals.push(tests.sharpness)}if(metric==='CONTROL'){if(tests.durability)vals.push(tests.durability);if(tests.finish)vals.push(tests.finish)}if(metric==='ART'&&tests.finish)vals.push(tests.finish);if(vals.length)pf*=vals.reduce((a,v)=>a+v,0)/vals.length;if(t?.effect?.kind==='random_test'&&metric===(c.metricOrder||['POWER','CONTROL','ART'])[c.round%3])pf*=t.effect.mult;if(t?.effect?.kind==='first_round'&&c.round===0)pf*=t.effect.mult;if(t?.effect?.kind==='stress_break'&&quality==='miss')pf*=.96}
  let score=player*factor*pf;
  if(c.mode==='school'&&c.schoolId){const school=D.SCHOOL_MODES.find(x=>x.id===c.schoolId);if(school?.focus?.includes(metric))score*=1.10}if(c.mode==='global'&&c.globalRule){if(c.globalRule.metric===metric)score*=c.globalRule.factor;if(c.globalRule.metric==='TRAIT'&&trait.rarity==='epic')score*=.92}
  const win=score>=enemy;const round={metric,quality,score,enemy,win};c.rounds[c.round]=round;if(win)c.wins++;
  const pop=$('#miniResult');if(pop){pop.textContent=win?'WIN':'LOSS';pop.className='result-pop show'}
  setTimeout(()=>{if(c.round<2){c.round++;renderMatch()}else finishMatch()},600)
}
function grantCircuitRewards(){const s=appState.save;s.meta={unlockedForgeTraits:[],unlockedMatchTraits:['overdrive','steady_hand','showtime'],titles:[],frames:[],...(s.meta||{})};s.meta.unlockedForgeTraits=Array.isArray(s.meta.unlockedForgeTraits)?s.meta.unlockedForgeTraits:[];s.meta.unlockedMatchTraits=Array.isArray(s.meta.unlockedMatchTraits)?s.meta.unlockedMatchTraits:['overdrive','steady_hand','showtime'];const newly=[];const add=(kind,id)=>{const key=kind==='forge'?'unlockedForgeTraits':'unlockedMatchTraits';if(!s.meta[key].includes(id)){s.meta[key].push(id);newly.push({kind,id})}};if(s.winCount>=1){add('match','last_stand');add('forge','forge_master_hand')}if(s.winCount>=2)add('match','risk_taker');if(s.winCount>=3)add('forge','forge_broken_edge');return newly.map(x=>x.kind==='match'?D.MATCH_TRAITS.find(t=>t.id===x.id)?.name:D.FORGE_TRAIT_DEFS.find(t=>t.id===x.id)?.name).filter(Boolean)}

function finishMatch(){
  const c=appState.circuit;
  const b=appState.save.blades.find(x=>x.id===c.bladeId);
  if(!b)return;
  const won=c.wins>=2;
  b.record[won?'win':'loss']++;
  if(!won)b.record.lossCount++;
  const masteryGain=applyBladeMastery(b,won);
  if(won&&c.mode==='school'&&c.schoolId){appState.save.circuit.schoolWins[c.schoolId]=(appState.save.circuit.schoolWins[c.schoolId]||0)+1}
  if(won&&c.mode==='global')appState.save.circuit.globalWins=(appState.save.circuit.globalWins||0)+1;
  if(won&&c.mode==='national'&&c.node===5)appState.save.circuit.nationalChampion=true;
  const stressTrait=(b.traits||[]).includes('trait_stress')||(b.materialTraits||[]).includes('trait_stress');
  const stressRoll=stressTrait?seeded(hash32(`${b.id}:${b.record.win}:${b.record.loss}:${c.mode}:${c.node}:stress`))():1;
  const stressBreak=stressTrait&&stressRoll<0.08;
  b.legacy=bladeLegacy(b);
  if(stressBreak&&!b.broken){b.broken=true;b.legacy=bladeLegacy(b);appState.save.broken++;save();openModal(`<h3>应力断裂</h3><div class="sub">STRESS BREAK · 8%</div><p>这把刀带有“应力刀”特性，本场结束后触发了额外断裂判定。</p><div class="action-row" style="margin-top:12px"><button class="btn main" id="backCircuit">返回赛事</button></div>`,root=>{$('#backCircuit').onclick=()=>{closeModal();renderCircuitHome()}});return}
  if(won){
    const reward=20+(c.node||0)*8;
    if(c.mode==='national'&&c.node<5){
      c.node++;
      appState.save.circuit.nationalNode=c.node;
      appState.save.winCount++;
      const unlocks=grantCircuitRewards();
      appState.save.cr+=reward;
      save();
      openModal(
        `<h3>晋级成功</h3><div class="sub">${['资格赛','32强','16强','8强','半决赛','决赛'][c.node]}</div><p>本节点 ${c.wins} : ${3-c.wins}。下一节点已经解锁，重新选择一个 Match Trait 再战。</p><div class="trait" style="--tc:#2FD3A0"><b>奖励</b><span>CR +${reward} · 当前赛事节点 ${c.node+1}/6${unlocks.length?' · 解锁：'+unlocks.join(' / '):''}</span></div><div class="action-row" style="margin-top:12px"><button class="btn main" id="nextNational">进入下一节点</button></div>`,
        root=>{
          $('#nextNational').onclick=()=>{
            closeModal();
            c.round=0;
            c.wins=0;
            c.rounds=[];
            c.matchTrait=null;
            chooseMatchTrait();
          };
        }
      );
      return;
    }
    appState.save.winCount++;
    const unlocks=grantCircuitRewards();
    appState.save.cr+=reward;
    save();
    openModal(
      `<h3>${c.mode==='national'?'全国决赛夺冠':c.mode==='global'?'全球巅峰完成':'试炼胜利'}</h3><div class="sub">MATCH WON · ${c.wins}:${3-c.wins}</div><p>${c.mode==='national'?'你完成了全国大赛六节点晋级。':'本场比赛已经完成。'} 这把刀可以继续留在藏刀阁。</p><div class="trait" style="--tc:#2FD3A0"><b>奖励</b><span>CR +${reward} · 刀魂 +${masteryGain}${unlocks.length?' · 解锁：'+unlocks.join(' / '):''}</span></div><div class="action-row" style="margin-top:12px"><button class="btn main" id="backCircuit">返回赛事</button></div>`,
      root=>{
        $('#backCircuit').onclick=()=>{closeModal();renderCircuitHome()};
      }
    );
  }else{
    appState.save.lossCount++;
    const breakChance=clamp(.08+b.record.lossCount*.08,0,.55);
    const r=seeded(hash32(`${b.id}:${b.record.lossCount}:${c.mode}:${c.node}`))();
    if(r<breakChance&&!b.broken){
      b.broken=true;
      appState.save.broken++;
      toast('BREAK CHECK：这把刀断了');
    }else{
      toast('BREAK CHECK：刀保住了，Loss Count +1');
    }
    save();
    openModal(
      `<h3>比赛结束</h3><div class="sub">MATCH LOST · ${c.wins}:${3-c.wins}</div><p>失败后进入 BREAK CHECK；Loss Count 越高，后续断刀风险越高。</p><div class="divider"></div><div class="trait" style="--tc:#F2555A"><b>结果</b><span>${b.broken?'刀已断裂':'刀仍在藏刀阁'} · 刀魂 +${masteryGain} · Mastery ${b.mastery||0} · Loss Count ${b.record.lossCount}</span></div><div class="action-row" style="margin-top:12px"><button class="btn main" id="backCircuit">返回赛事</button></div>`,
      root=>{
        $('#backCircuit').onclick=()=>{closeModal();renderCircuitHome()};
      }
    );
  }
}

function prepareTuneGame(){const canvas=$('#traceCanvas');if(!canvas)return;const dpr=Math.min(2,devicePixelRatio||1);canvas.width=canvas.clientWidth*dpr;canvas.height=canvas.clientHeight*dpr;const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);const w=canvas.clientWidth,h=canvas.clientHeight;const pts=[];for(let i=0;i<=100;i++){const t=i/100;pts.push({x:22+t*(w-44),y:h*.53+Math.sin(t*Math.PI*2.3)*36+Math.sin(t*Math.PI*5)*8})}ctx.lineWidth=4;ctx.strokeStyle='#D9A63C';ctx.globalAlpha=.22;ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();ctx.globalAlpha=1;ctx.strokeStyle='#23262E';ctx.lineWidth=1.4;ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();let drawing=false,err=0,count=0,lastX=0;const get=(e)=>{const r=canvas.getBoundingClientRect();const t=e.touches?e.touches[0]:e;return{x:t.clientX-r.left,y:t.clientY-r.top}};function down(e){drawing=true;const p=get(e);lastX=p.x;err=0;count=0;e.preventDefault()}function move(e){if(!drawing)return;const p=get(e);const idx=clamp(Math.round((p.x-22)/(w-44)*100),0,100);const target=pts[idx];err+=Math.hypot(p.x-target.x,p.y-target.y);count++;ctx.fillStyle='#FF7A29';ctx.beginPath();ctx.arc(p.x,p.y,2.2,0,Math.PI*2);ctx.fill();lastX=p.x;e.preventDefault()}function up(){if(!drawing)return;drawing=false;const avg=count?err/count:999;const rating=avg<7?'perfect':avg<13?'great':avg<22?'good':'miss';const run=appState.run;run.miniResults.tune={type:'tune',rating,score:Math.max(0,100-Math.round(avg*3)),multiplier:miniMult(rating),perfect:rating==='perfect',miss:rating==='miss'};if(rating==='perfect'){run.stats.craft+=10;run.stats.design+=3}else if(rating==='great')run.stats.craft+=7;else if(rating==='good')run.stats.craft+=4;run.stage='appraisal';const pop=$('#miniResult');if(pop){pop.textContent=rating.toUpperCase();pop.className='result-pop show'}setTimeout(()=>finishForge(),550)}canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);$('#tuneStart').onclick=()=>{$('#tuneStart').disabled=true;toast('沿金色路径滑动')};const pop=document.createElement('div');pop.id='miniResult';pop.className='result-pop';document.querySelector('.mini-stage')?.appendChild(pop)}

function openModal(html,setup){const m=$('#modal');m.hidden=false;m.innerHTML=`<div class="sheet">${html}</div>`;setup?.(m.querySelector('.sheet'));}
function closeModal(){$('#modal').hidden=true;$('#modal').innerHTML=''}
$('#modal').addEventListener('click',e=>{if(e.target.id==='modal')closeModal()});
$('#backBtn').onclick=()=>{if(appState.screen==='forge'&&appState.run?.stage!=='appraisal'){if(confirm('退出本局锻刀？本局进度不会保存。')){appState.run=null;renderHome()}}else{showScreen('home');renderCurrent()}}

function renderCodex(){const s=appState.save;const matDone=new Set(s.blades.map(b=>b.materialId)).size;const types=new Set(s.blades.map(b=>b.bladeType)).size;const traits=new Set(s.blades.flatMap(b=>[...(b.forgeTraits||[]),...(b.traits||[]),...(b.materialTraits||[])])).size;const combos=new Set(s.blades.flatMap(b=>b.combos||[])).size;const achievements=Object.values(s.achievements||{});const el=$('#codexScreen');el.innerHTML=`<div class="section-head"><div><h2>图鉴</h2><small>CODEX / META</small></div><small>${achievements.length} ACHIEVEMENTS</small></div><div class="metrics-grid"><div class="metric-card"><b>${matDone}<small> / ${D.MATERIALS.length}</small></b><span>材料记录</span></div><div class="metric-card"><b>${types}<small> / ${D.BLADE_TYPES_3D.length}</small></b><span>刀型</span></div><div class="metric-card"><b>${traits}</b><span>特性记录</span></div><div class="metric-card"><b>${combos}<small> / ${D.COMBOS.length}</small></b><span>组合发现</span></div></div><div class="list"><div class="metric-card"><b>${s.bestScore}</b><span>最高鉴定分</span></div><div class="metric-card"><b>${s.forgeCount}</b><span>总锻刀次数</span></div><div class="metric-card"><b>${s.broken}</b><span>断刀记录</span></div><div class="metric-card"><b>${achievements.length} / 7</b><span>成就</span></div><div class="metric-card"><b>${Math.max(0,...s.blades.map(b=>b.mastery||0))}</b><span>最高刀魂</span></div><div class="metric-card"><b>${s.circuit.globalWins||0}</b><span>全球胜场</span></div><div class="metric-card"><b>${s.blades.reduce((n,b)=>n+(b.repairs||0),0)}</b><span>重铸次数</span></div><div class="achievement-list">${[['first_blade','初铸','完成第一把成刀'],['five_blades','百炼成钢','完成 5 把成刀'],['first_win','初战告捷','赢得第一场赛事'],['three_wins','连胜','累计赢得 3 场赛事'],['collector','藏锋','同时保有 9 把未断成刀'],['mythic','神话工艺','鉴定出 150 分以上成刀'],['daily_master','每日匠心','每日挑战达到 100 分']].map(([id,n,d])=>`<div class="achievement ${s.achievements[id]?'done':''}"><b>${s.achievements[id]?'✓':'○'} ${n}</b><span>${d}</span></div>`).join('')}</div></div>`;showScreen('codex')}
function renderDaily(){const date=dateKey();const done=appState.save.daily.date===date&&appState.save.daily.completed;const seed=hash32('daily:'+date);const el=$('#dailyScreen');el.innerHTML=`<div class="section-head"><div><h2>每日挑战</h2><small>DAILY CHALLENGE</small></div><small>${date}</small></div><div class="metric-card" style="margin-bottom:10px"><b>固定种子</b><span>${seed}</span><p style="font-size:10px;color:var(--muted);margin-top:8px;line-height:1.5">每天使用固定逻辑种子。完成后记录本日成绩，并计入每日成就。</p></div><div class="metric-card" style="margin-bottom:10px"><b>${done?'今日完成':'尚未完成'}</b><span>${done?'本日成绩 '+(appState.save.daily.score||0):'完成一次完整锻造即可记录成绩'}</span></div><div class="action-row"><button class="btn main" id="startDaily" ${done?'disabled':''}>${done?'今日已完成':'开始今日锻刀'}</button></div>`;$('#startDaily').onclick=()=>{appState.run=createRun(seed,'daily');appState.run.material=null;appState.run.daily=true;showScreen('forge');renderForge();toast('Daily Seed 已锁定')};showScreen('daily')}

if(TEST_MODE)window.__FORGE_API__={appState,createRun,materialCandidates,pickCards,applyCard,resolveTraitsAfterCard,updateVisualFromRoute,pickTextureId,applyForgeTraitStats,miniMult,miniScoreFromPos,computeMetrics,opponentFor,pickMatchTraits,applyMiniResult,riskBreakCheck,finishForge};

function boot(){appState.save=loadSave();appState.save.meta={unlockedForgeTraits:[],unlockedMatchTraits:['overdrive','steady_hand','showtime'],titles:[],frames:[],...(appState.save.meta||{})};renderHeader();renderHome();if(TEST_MODE){window.__FORGE_SMOKE__={home:$('#homeScreen')?.textContent.includes('开始锻刀')};return}appState.loading=true;boot3D().then(()=>{appState.loading=false;if(appState.screen==='forge')renderForge();else if(appState.screen==='collection')renderCollection();else if(appState.screen==='circuit')renderCircuitHome();}).catch(e=>{appState.loading=false;console.error(e);toast('3D 引擎初始化失败，请用本地 HTTP 打开')});}
// Daily completion hook: saving a blade from a daily run could be expanded later; for now the daily seed is functional and replayable.
boot();
})();
