const fs=require('fs'), vm=require('vm');
const path=require('path');
const root=path.resolve(__dirname,'..');
function el(){return {hidden:false,textContent:'',innerHTML:'',style:{},dataset:{},classList:{add(){},remove(){},toggle(){}},querySelector(){return null},querySelectorAll(){return []},addEventListener(){},appendChild(){},getBoundingClientRect(){return {width:390,height:200}},clientWidth:390,clientHeight:200};}
const els={};['modal','backBtn','crVal','screenEn','homeScreen','forgeScreen','circuitScreen','collectionScreen','codexScreen','dailyScreen','toast'].forEach(id=>els['#'+id]=el());
const document={querySelector(sel){return els[sel]||el()},querySelectorAll(){return []},getElementById(id){return els['#'+id]||el()},createElement(){return el()},body:el()};
const local={data:new Map(),getItem(k){return this.data.get(k)||null},setItem(k,v){this.data.set(k,String(v))},removeItem(k){this.data.delete(k)}};
const window={location:{protocol:'file:',search:'?test=1'},document,localStorage:local,devicePixelRatio:1,performance,crypto:globalThis.crypto};
const ctx={window,document,location:window.location,localStorage:local,console,URLSearchParams,Math,Date,JSON,Set,Map,Object,Array,Number,String,Boolean,RegExp,parseFloat,parseInt,isNaN,performance,crypto:globalThis.crypto,requestAnimationFrame:()=>0,cancelAnimationFrame:()=>0,ResizeObserver:class{observe(){}disconnect(){}},alert(){},confirm(){return true},setTimeout:()=>0,clearTimeout:()=>0};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(root+'/js/game-data.js','utf8'),ctx,{filename:'game-data.js'});
vm.runInContext(fs.readFileSync(root+'/js/game.js','utf8'),ctx,{filename:'game.js'});
const api=ctx.window.__FORGE_API__, D=ctx.window.FORGE_DATA;
if(!api) throw new Error('no api');
console.log('DATA',D.BLADE_TYPES_3D.length,D.MATERIALS.length,D.CARDS.length,D.TRAITS.length,D.COMBOS.length);
// deterministic candidate/card generation
const a=api.createRun(20260927), b=api.createRun(20260927);
const ac=api.materialCandidates(a,3).map(x=>x.id), bc=api.materialCandidates(b,3).map(x=>x.id);
if(JSON.stringify(ac)!==JSON.stringify(bc)) throw new Error('material RNG mismatch');
a.material=b.material=D.MATERIALS.find(x=>x.id==='mat_damascus');
for(const r of [a,b]){r.stats={...D.BASE_STATS};r.risk=r.material.baseRisk;r.riskPeak=r.risk;r.materialTraits=[];r.stage='forge';r.path=[];r.counts={melt:0,forge:0,fold:0,quench:0,temper:0,edge:0,handle:0,tune:0};r.forgeTraits=[];r.traits=[];r.combos=[];}
const foldCard=D.CARDS.find(c=>c.stage==='fold'&&c.tags?.includes('折叠'));
api.applyCard(a,foldCard);api.applyCard(b,foldCard);
if(JSON.stringify(a.combos)!==JSON.stringify(b.combos))throw new Error('combo mismatch');
// combo requires 2 conditions; material damascus + folding card should unlock c_thousand once card applied
if(!a.combos.includes('c_thousand'))throw new Error('combo discovery missing');
if(!a.traits.includes('trait_thousand_layers'))throw new Error('combo trait missing');
// Complete a non-failing forge mini result
for(const r of [a]){api.appState.run=r;r.stage='forge';r.risk=10;r.path=[foldCard.id];r.counts.forge=1;api.applyMiniResult('forge','perfect');if(!['fold','failed'].includes(r.stage))throw new Error('forge mini bad state')}
// deterministic break check must be capable of failing at extreme risk
let found=false;for(let seed=1;seed<2000&&!found;seed++){const r=api.createRun(seed);r.risk=95;r.path=['x'];r.miniResults.hammer={score:100};if(api.riskBreakCheck(r,'forge','good'))found=r.stage==='failed';}
if(!found)throw new Error('risk break never triggered in 1..1999 seeds');
// metric mapping and opponent schema
const blade={id:'b1',stats:{edge:30,strength:32,toughness:28,spirit:24,craft:29,design:26},score:80,rarity:'rare',broken:false,record:{win:0,loss:0,lossCount:0},riskPeak:20,traits:['trait_veteran'],materialTraits:[]};
api.appState.save={blades:[blade],cr:50,winCount:0,broken:0,lossCount:0,bestScore:0,forgeCount:0,daily:{date:'',completed:false},achievements:{},meta:{unlockedForgeTraits:[],unlockedMatchTraits:['overdrive','steady_hand','showtime'],titles:[],frames:[]}};
api.appState.circuit={bladeId:'b1',mode:'global',schoolId:null,node:0,round:0,wins:0,rounds:[],matchTrait:D.MATCH_TRAITS[0],globalRule:null,metricOrder:['POWER','CONTROL','ART']};
const mm=api.computeMetrics(blade), op=api.opponentFor(api.appState.circuit,0);
if(!(mm.POWER&&mm.CONTROL&&mm.ART))throw new Error('metric mapping invalid');
if(!('POWER' in op&&'CONTROL' in op&&'ART' in op))throw new Error('opponent schema invalid');
console.log('FLOW combo='+a.combos.join(',')+' trait='+a.traits.join(',')+' riskBreak=true');
console.log('OFFLINE-INLINE FILE MODE',ctx.window.location.protocol,'pass (logic layer)');
console.log('FULL SMOKE PASS');
