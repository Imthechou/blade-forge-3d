@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

rem ============================================================
rem   锻刀大赛 · 通用启动脚本
rem
rem   作用：自动找到 Node.js 与游戏目录，启动本地服务并打开浏览器。
rem   特点：不依赖固定的文件夹名，换了目录名或解压到别处也能用。
rem
rem   需要：Node.js 22 或更新版本（https://nodejs.org/）
rem   存档：存在浏览器 localStorage 里，请始终使用同一浏览器 + 同一地址
rem         http://127.0.0.1:8123/
rem ============================================================

cd /d "%~dp0"

set "PORT=8123"
set "HOST=127.0.0.1"
set "GAMEDIR="

rem ---- 1) 定位游戏目录：优先 Forge_AI / 游戏本体，其次当前目录 ----
for %%D in ("Forge_AI" "游戏本体" ".") do (
  if not defined GAMEDIR (
    if exist "%%~D\serve.cjs" (
      if exist "%%~D\index.html" set "GAMEDIR=%%~D"
    )
  )
)

if not defined GAMEDIR (
  echo.
  echo   [错误] 找不到游戏目录。
  echo   请在压缩包解压后的完整目录里运行本脚本，
  echo   或确认 serve.cjs 与 index.html 存在。
  echo.
  pause
  exit /b 1
)

echo   游戏目录：%GAMEDIR%

rem ---- 2) 定位 Node.js ----
set "NODE_EXE="

where node.exe >nul 2>nul
if not errorlevel 1 (
  for /f "delims=" %%P in ('where node.exe') do (
    if not defined NODE_EXE set "NODE_EXE=%%P"
  )
)

if not defined NODE_EXE (
  if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "NODE_EXE=%LOCALAPPDATA%\Programs\nodejs\node.exe"
)
if not defined NODE_EXE (
  if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
)
if not defined NODE_EXE (
  if exist "%ProgramFiles(x86)%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles(x86)%\nodejs\node.exe"
)

if not defined NODE_EXE (
  echo.
  echo   [错误] 没有找到 Node.js。
  echo   请先安装 Node.js 22 或更新版本，然后重新双击本脚本。
  echo   下载地址：https://nodejs.org/
  echo.
  pause
  exit /b 1
)

echo   Node.js：%NODE_EXE%

rem ---- 3) 检查 Node.js 主版本 >= 22 ----
"%NODE_EXE%" -e "process.exit(Number(process.versions.node.split('.')[0])>=22?0:1)"
if errorlevel 1 (
  echo.
  echo   [错误] Node.js 版本过低，需要 22 或更新版本。
  "%NODE_EXE%" -v
  echo   请升级后重新运行。下载地址：https://nodejs.org/
  echo.
  pause
  exit /b 1
)

rem ---- 4) 启动服务 ----
rem 优先用带「复用已启动服务 + 自动开浏览器」的启动器；
rem 没有就用 serve.cjs 直接起服务，再手工开浏览器。
if exist "%GAMEDIR%\tools\launch.cjs" (
  "%NODE_EXE%" "%GAMEDIR%\tools\launch.cjs"
) else (
  start "" "http://%HOST%:%PORT%/"
  "%NODE_EXE%" "%GAMEDIR%\serve.cjs" %PORT% %HOST%
)

if errorlevel 1 (
  echo.
  echo   [提示] 服务未能启动，请看上面的错误信息。
  echo   如果提示端口被占用，请关闭占用 %PORT% 端口的程序后重试。
  echo.
  pause
  exit /b 1
)
