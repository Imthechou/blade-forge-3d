# 锻刀大赛_3D版

独立的新版本：逻辑以《锻刀大赛_玩法设定案_V3.md》为基准，当前 2.0(2) 的成熟数据作为兼容基础，3D 主视觉采用现有 BladeSkin 引擎。

## 资产映射
- 原料：`assets/materials/ore_small.glb`
- 熔炼：`assets/materials/molten_sphere_small.glb`
- 胚体：`assets/materials/blank_ingot_small.glb`
- 成刀：现有 12 把原创 3D 刀模型
- 刀身材质：BladeSkin M01–M24
- 锻打纹理：T01–T12
- 淬火/工艺：F01–F12

## 玩法闭环
HOME → FORGE → 原料 → 熔炼 → 锻打+HAMMER → 定型 → 淬火+QUENCH → 回火 → 开刃 → 装配 → FINAL TUNE → 鉴定 → 藏刀 → CIRCUIT → 比赛 → 奖励/断刀 → 回到下一次锻刀。

## 运行
- 双击 `index.html` 可直接启动；项目保留 `bundle.inline.js`，用于 file:// 下的 3D 模型/HDR 内联兜底。
- 也可以在目录下执行：`python -m http.server 8899`，然后打开 `http://127.0.0.1:8899/`。

## 当前已实现

- 9 阶 FORGE：原料 → 熔炼 → 锻打 → 定型 → 淬火 → 回火 → 开刃 → 装配 → 最终调校。
- 3 个锻刀小游戏：HAMMER / QUENCH / FINAL TUNE；小游戏只提供有限修正。
- Risk 会在关键小游戏结算时进行确定性 BREAK CHECK；高风险可能直接终止本局，并记录失败状态。
- 组合发现：沿用当前数据中的 30 组组合条件，发现后写入成刀记录并授予对应 Trait。
- 成刀保存材料、六维、Forge Trait、材料 Trait、组合、锻造路径、外观配方、风险峰值和赛事记录。
- 赛事：SCHOOL TRIALS / NATIONAL CHAMPIONSHIP / GLOBAL APEX；POWER / CONTROL / ART 三回合，2:1 胜负。
- POWER / CONTROL / ART 各准备 3 种短小游戏模板；GLOBAL 的变化规则在整场比赛内固定。
- 失败后进入 BREAK CHECK；刀可断裂，也可能保留并累积 Loss Count。
- 赛事奖励可逐步解锁 Match Trait 与 Forge Trait。

## 验证

`tools/smoke_vm.js` 为逻辑层烟测：会验证 12 刀模型、60 材料、164 工艺卡、30 组合/特性数据、确定性 RNG、隐藏组合发现、Risk BREAK CHECK 与 POWER / CONTROL / ART 对手结构。浏览器真实渲染仍建议在本机 Chrome/Edge 中打开 `index.html` 或 HTTP 地址检查显卡/浏览器差异。

## 当前默认决策
1. 9 阶锻刀流程继续采用：原料 + 8 个工艺阶段。
2. 3 个关键锻刀小游戏：HAMMER / QUENCH / FINAL TUNE。
3. 赛事正式使用 POWER / CONTROL / ART，固定 3 回合。
4. Forge Trait 与 Match Trait 分离。
5. 失败后进入 BREAK CHECK，保留 Loss Count。
6. 当前用户消息没有实际附上名为“锻刀大赛原型.html”的文件，因此暂以当前 `锻刀大赛2.0(2).html` 与现有视觉测试页作为原型兼容基础；不会覆盖原工程。

## 兼容性说明
3D 渲染层与玩法数据层分离：后续可以单独替换模型、皮肤参数或数值，而不用重写流程。

## V3 继续完善
- 修复藏刀阁 3D Inspector 的 Viewer 容器定位：支持显式 host，避免抢到锻造页的 `.stage3d`。
- 锻造小游戏阶段的 3D 演出按实际阶段传递 `stage`，避免 `mini_forge` / `mini_quench` 被误判为最终鉴定效果。
- 扩展轻量阶段 FX：定型、淬火、回火、开刃、装配、调校、鉴定均有不同光效/粒子反馈。
- 保持 Viewer 只负责视觉呈现，属性、风险、配方与比赛判定仍由数据层控制。
- 回归检查：`node --check js/game.js`、`node tools/smoke_vm.js`、ZIP 完整性检查均通过。

## v4 赛事循环更新

- 六大流派试炼开始真正参与胜负计算：流派 Focus 会强化对应检验，同时让对应方向的对手更具针对性。
- 全国大赛晋级节点写入存档：资格赛 → 32强 → 16强 → 8强 → 半决赛 → 决赛，刷新页面后仍可继续。
- 全国冠军状态写入存档。
- 六大流派分别累计胜场。
- 全球巅峰赛累计独立胜场，并使用更高基础奖励。
- 旧版存档自动补充 `circuit` 数据结构，不需要手动清档。

## V5 长期养成更新

- 新增每把成刀的 `Mastery / 刀魂熟练度`。
- 赛事胜利获得 +10 刀魂，失败获得 +3 刀魂。
- 刀魂每 25 点提升一级，最高 6 级；等级只提供小幅 1.2%/级的赛事三维表现加成，不覆盖材料/工艺 Build。
- 刀魂等级对应称号：新铸 → 初露锋芒 → 百战淬锋 → 名匠之刃 → 宗师佩刃 → 传世名锋 → 神兵。
- 藏刀阁展示每把刀的刀魂、等级、称号。
- 赛事结算展示本场刀魂收益。
- 流派胜场、全球胜场、全国冠军状态继续持久化。
- 旧存档会自动补齐 `mastery` 与 `title` 字段。

## v13 刀皮选择机制

锻刀流程中的视觉皮肤现在与锻造阶段绑定：

- 原料 MATERIAL：刀身材质，从 24 种 BladeSkin Material 中三选一。
- 锻打 FORGING：刀身纹理，从 12 种 BladeSkin Texture 中三选一。
- 淬火 QUENCHING：表面工艺，从 12 种 BladeSkin Finish 中三选一。

刀皮选择与原有锻造卡牌并行：卡牌继续负责六维属性、风险和路线，刀皮三选一只决定对应视觉层。
每个刀皮阶段都可以消耗 CR 刷新候选，费用按该阶段刷新次数递增：10 / 15 / 20 / 25 / 30 CR。
选择结果会写入最终 BladeSkinState，并随成刀存档。

## V15 自由锻造改造

本版本将 FORGE 明确定位为“自由探索的 Roguelite 锻造构筑”，锻造阶段不再向玩家强调或推荐任何流派。

- 锻造主界面核心信息固定为：3D 当前视觉、六维属性、当前阶段决策卡、阶段刷新。
- 锻造卡只描述工艺行为、属性变化与风险，不显示“力量流/精准流”等流派标签，也不提供最佳路线推荐。
- 视觉层仍使用 BladeSkin：原料对应 Material、锻打对应 Texture、淬火对应 Finish；视觉候选以紧凑的三选一方式展示，不抢占主视觉。
- 阶段刷新统一消耗 CR，并按该阶段刷新次数递增：10 / 15 / 25 / 40 / 60 / 85 / 120 / 160 / 200 CR。每个锻造阶段独立累计刷新次数。
- 刷新会同时重新生成该阶段的决策卡和对应视觉候选；价格不会因为切换阶段而继承。
- Wear 开始由关键小游戏结果产生，进入 BladeSkinState 并最终保存到成刀。
- HAMMER / QUENCH 仍可根据工艺选择改变小游戏节奏与窗口，但界面不再用“路线/流派”强化提示。
- 流派、权重、路线与 Match Trait 只在 CIRCUIT 赛事阶段出现，由赛事规则决定玩家如何使用已经锻好的刀。
- 成刀继续保存完整 BladeRecord，包括视觉配方、Seed、Wear、锻造路径、刷新历史、风险峰值、Forge Trait 与赛事记录。

### V15 核心原则

> 锻造不教玩家怎么玩，只告诉玩家“你做了什么”和“它变成了什么”。
>
> 赛事才告诉玩家“这个赛场怎么玩”。

## V15.1 · Forge Feedback / Event Layer

在 V15 核心循环之上继续补齐可直接落地的系统：

- **动态工艺卡池**：当前六维属性、Risk、已走过的标签、Forge Trait 会影响候选卡权重；不改变确定性 Seed 机制。
- **Forge Event**：熔炼 / 定型 / 回火 / 开刃有概率触发一次性事件；事件提供取舍，不标记“正确答案”。
- **阶段反馈**：纯度、回火、刃口、磨损、花纹尺度/旋转进入 BladeSkinState 的可复现参数。
- **BladeSkin 参数真正接入**：`patternScale / patternRotation / patternOffset` 不再只是状态字段，会进入纹理参数；材质与工艺也允许通过 `variantParams` 做轻量变体。
- **鉴定信息增强**：最终结果展示纯度、回火、刃口、磨损与事件次数，让玩家看到“这把刀是怎么来的”。

### 当前原则

事件与动态卡池只改变“可能遇到什么”，不直接告诉玩家哪条路线更正确；最终表现仍由数据层计算，3D Viewer 只负责呈现。

## V15.5 — 完整游戏循环深化

本轮继续从“可玩的锻刀原型”向完整循环推进：

- **阶段 3D 演出**：熔炼、锻打、淬火、回火、开刃加入一次性 3D 舞台演出。使用现有 GLB + Three.js 光源、粒子、脉冲、扫描与过渡，不新增重型模型依赖。
- **锻打**：刀胚加入锤击脉冲与火花表现。
- **淬火**：刀身加入冷却蓝光脉冲与粒子。
- **回火**：加入沿刀身移动的热处理光扫。
- **开刃**：加入沿刃口移动的高亮与火花。
- **熔炼**：熔融球加入炉火脉冲。
- **Roguelite 事件**：继续保留阶段事件的随机取舍，并记录 eventLog；事件结果进入最终刀的履历。
- **Forge Trait 系统化**：Forge Trait 不再只在鉴定时加分；会影响后续卡池权重、风险条件、特定标签卡出现倾向，以及最终属性。
- **鉴定 Reveal**：最终鉴定改为稀有度 → 分数 → 六维 → Forge Trait → 配方/履历的分层揭示。
- **藏刀阁**：列表直接显示材质/纹理/工艺、磨损、事件数量；详情仍可打开独立 3D Inspector。
- **CODEX**：增加纹理、工艺、事件、Forge Trait 等发现进度。
- **Daily**：每日挑战不再只有固定 Seed；每一天从 5 套固定规则中确定 1 套，规则与 Seed 一起锁定。
- **Circuit**：除 Global Rule 外，学校/全国等赛事节点也会获得确定性的 Match Rule；规则可以影响专精项目、首回合、逆风、ART/CONTROL 权重或 Risk 转化。

核心循环现在进一步收敛为：

`选择材料 → 阶段卡牌 → 随机事件 → 3D 加工演出 → 小游戏修正 → 视觉状态变化 → Forge Trait → 鉴定 Reveal → 藏刀阁 → Circuit → Match Trait / Rule → 战绩与刀魂 → CODEX / Daily`

注意：3D 演出仍采用轻量运行时效果，不引入刚体物理或重型动画资源；真实浏览器/WebGL 截图验证仍需要在可运行浏览器环境中进行。

## V15.2 完整循环继续深化（2026-09-28）
- 10阶段3D演出链继续保留并增强：原料 → 熔炼 → 锻打 → 定型 → 淬火 → 回火 → 开刃 → 装配 → 调校 → 鉴定；阶段灯光强度会读取 Purity / Temper / Edge。
- 锻造主界面增加过程反馈条：Purity / Temper / Edge / Risk，与 Material / Texture / Finish / Wear 并列作为结果反馈，不提供路线推荐。
- BladeSkin PatternSeed / PatternOffset 正式写入 Run.visual，并传入程序化 BladeSkin 组合。
- Roguelite 事件修正：事件 ID 与“已在该阶段触发”状态分离，避免同一事件被错误重复计入或错误阻塞其他事件。
- Daily Challenge 增强为固定 Seed + 固定材料池 + 固定特殊规则；净锻日/匠心日拥有明确的三材料限制。
- Collection 的 BladeRecord 增加 creationRecord / tournamentHistory / breakHistory，记录作品完整生命周期。
- CODEX 从纯统计升级为分类发现记录：材料、纹理、工艺、卡牌、Forge Trait、Match Trait、组合、事件。
- Circuit 赛事会把每场比赛写入作品的 tournamentHistory；断刀写入 breakHistory。

## V15 Final Loop Pass — 2026-09-28

本轮以《V15 完整改造方案》为验收基线，继续补齐“选择 → 工艺演出 → 参数变化 → 作品记录 → 长期循环”。

### 本轮重点
- 10 阶段演出继续深化：原料 / 熔炼 / 锻打 / 定型 / 淬火 / 回火 / 开刃 / 装配 / 调校 / 鉴定均有阶段化轻量 3D 演出。
- 卡牌选择开始直接驱动视觉过程参数：Purity、Pattern Scale / Rotation / Offset、Temper、Edge、Wear、Pattern Seed。
- 每次工艺选择记录 `lastAction` 与 `stageHistory`，最终写入 `creationRecord`。
- Forge Trait 增加净锻、精密刃口、热处理掌控，并根据实际锻造结果触发，而不是作为流派标签。
- 增加两个隐藏视觉发现：冰紫雾影、大马士革棱彩；仅在运行时组合满足条件时记录。
- CODEX 增加特殊视觉发现与 Meta 解锁记录。
- Meta 解锁包含首次刷新免费、材料发现、锻造档案、赛事档案奖励。
- Daily 增加“换手日”，固定 Seed + 固定材料池 + 特殊规则继续扩展。
- 藏刀阁作品详情增加 Seed、Pattern、Forge Trait、事件与阶段履历。
- Circuit 奖励会读取赛事档案 Meta 解锁。

### 重要边界
本轮通过 `node --check`、离线 VM smoke test 与 ZIP 完整性检查；仍未宣称真实移动端 WebGL 截图 / 实机 QA 已完成。


## V15 资源基准（以当前工程实际模型为准）

当前 3D 刀型仅包含以下 12 个 GLB，不再使用历史策划案中未落地的刀型名称或虚拟模型 ID：

- 蝴蝶刀 `knife_balisong.glb`
- 刺刀 `knife_bayonet.glb`
- 折叠刀 `knife_folding.glb`
- 短剑 `knife_gladius.glb`
- 爪子刀 `knife_karambit.glb`
- 马来剑 `knife_kris.glb`
- 开山刀 `knife_machete.glb`
- 弯刀 `knife_saber.glb`
- 骷髅匕首 `knife_skull.glb`
- 直刀 `knife_straight.glb`
- 求生匕首 `knife_survival.glb`
- 唐刀 `knife_tangdao.glb`

后续 FORGE、Collection、CODEX、赛事与视觉系统均以 `BLADE_TYPES_3D` 和这些实际 GLB 资源为唯一刀型来源。
