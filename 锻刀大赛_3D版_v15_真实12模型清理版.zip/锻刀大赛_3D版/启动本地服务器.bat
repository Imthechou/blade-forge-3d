@echo off
cd /d "%~dp0"
echo Starting Blade Forge 3D at http://127.0.0.1:8899/index.html
start "Blade Forge 3D" http://127.0.0.1:8899/index.html
python -m http.server 8899
