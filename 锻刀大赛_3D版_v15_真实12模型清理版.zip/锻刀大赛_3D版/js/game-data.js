// Auto-extracted gameplay data from 锻刀大赛2.0(2).html; rendering is replaced by the 3D layer.

const STAT_KEYS=['edge','strength','toughness','spirit','craft','design'];

const STAT_CN={edge:'锋利',strength:'强度',toughness:'韧性',spirit:'灵性',craft:'工艺',design:'设计'};

const BASE_STATS={edge:14,strength:14,toughness:14,spirit:10,craft:14,design:12};

const RARITY={
  common:{name:'普通',color:'#B8BFC9',w:52,glow:0},
  uncommon:{name:'精良',color:'#2DD4A7',w:26,glow:6},
  rare:{name:'稀有',color:'#7C7CFF',w:13,glow:10},
  epic:{name:'史诗',color:'#E04FD8',w:5.5,glow:14},
  legendary:{name:'传说',color:'#FFC24B',w:3,glow:18},
  mythic:{name:'神话',color:'#FF9E4B',w:0.5,glow:24},
};
const RARITY_ORDER=['common','uncommon','rare','epic','legendary','mythic'];
const QUALITY=[
  {min:150,name:'神话',rarity:'mythic',cr:400},
  {min:120,name:'传说',rarity:'legendary',cr:200},
  {min:100,name:'史诗',rarity:'epic',cr:120},
  {min:80,name:'稀有',rarity:'rare',cr:70},
  {min:60,name:'精良',rarity:'uncommon',cr:40},
  {min:0,name:'普通',rarity:'common',cr:20},
];
const TIERS=[
  {t:1,en:'QUALIFIER',cn:'资格赛',base:45},{t:2,en:'ROUND OF 32',cn:'32强',base:55},
  {t:3,en:'ROUND OF 16',cn:'16强',base:65},{t:4,en:'ROUND OF 8',cn:'8强',base:73,mastery:1.02},
  {t:5,en:'QUARTER FINAL',cn:'四强赛',base:82,mastery:1.05},{t:6,en:'SEMI FINAL',cn:'半决赛',base:94,mastery:1.07},
  {t:7,en:'WORLD FINAL',cn:'世界决赛',base:107,mastery:1.09},{t:8,en:'THE BEST',cn:'地表最强',base:132,mastery:1.13},
];
const TESTS=[
  {id:'sharpness',cn:'锋利度测试',en:'SHARPNESS'},
  {id:'strength',cn:'强度测试',en:'STRENGTH'},
  {id:'durability',cn:'耐用度测试',en:'DURABILITY'},
  {id:'finish',cn:'完成度评价',en:'FINISH'},
];
const REFRESH_COSTS=[20,40,80,120,200];
function M(id,name,cat,rarity,stats,baseRisk,trait,prefer,taboo,flavor,palette){return{id,name,category:cat,rarity,stats,baseRisk,trait,preferTags:prefer,tabooTags:taboo,flavor,palette}}

const MATERIALS=[
// A 矿石 ×10
M('mat_hematite','赤铁矿','ore','common',{strength:18,toughness:8,craft:4},2,null,['高温'],['冷加工'],'最常见的炼铁原料，稳定可靠。','iron'),
M('mat_magnetite','磁铁矿','ore','uncommon',{strength:15,craft:12,spirit:4},3,'trait_magcore',['高温','精密'],['手工'],'自带微弱磁性的黑色矿石。','darksteel'),
M('mat_chromite','铬铁矿','ore','uncommon',{toughness:16,craft:8,design:6},2,null,['精密'],['重锤'],'赋予钢材出色的抗蚀性。','steel'),
M('mat_manganese','锰矿','ore','common',{toughness:14,strength:10},1,null,['重锤'],['冷加工'],'提升韧性的经典添加剂。','iron'),
M('mat_ilmenite','钛铁矿','ore','rare',{edge:10,toughness:12,design:8},3,null,['冷加工'],['高温'],'轻而强的金属之源。','steel'),
M('mat_nickel_ore','镍矿','ore','uncommon',{toughness:12,design:10,craft:6},2,null,['折叠'],['极限热锻'],'层层折叠后泛起银色波纹。','silver'),
M('mat_copper_ore','铜矿','ore','common',{design:12,spirit:6,strength:4},1,null,['手工'],['极限热锻'],'古老的金属，温润而柔软。','copper'),
M('mat_siderite','菱铁矿','ore','common',{strength:14,craft:8},1,null,['高温'],['精密'],'菱形结晶的贫铁矿。','rust'),
M('mat_limonite','褐铁矿','ore','common',{toughness:10,strength:8,design:4},1,null,['重锤'],['精密'],'沼泽与河床中的馈赠。','rust'),
M('mat_stibnite','辉锑矿','ore','rare',{edge:14,spirit:10,toughness:-4},4,null,['冷加工'],['重锤'],'银灰色晶柱，性脆而锋。','silver'),
// B 金属 ×8
M('mat_iron','铁','metal','common',{strength:16,toughness:10,craft:4},0,null,['重锤','高温'],['冷加工'],'最朴素的起点。','iron'),
M('mat_copper','铜','metal','common',{design:14,spirit:6},0,null,['手工'],['高温'],'延展性极佳的红色金属。','copper'),
M('mat_aluminum','铝','metal','common',{design:10,toughness:6,strength:-4},0,null,['精密'],['重锤'],'轻若鸿毛，难当重击。','silver'),
M('mat_titanium','钛','metal','rare',{strength:18,toughness:14,design:6},4,null,['冷加工','精密'],['高温'],'航天级的强度重量比。','steel'),
M('mat_nickel','镍','metal','uncommon',{toughness:12,design:12},1,null,['折叠'],['极限热锻'],'大马士革花纹的另一半。','silver'),
M('mat_cobalt','钴','metal','rare',{edge:14,strength:10,spirit:4},3,null,['高温'],['冷加工'],'高温下依然坚硬的蓝色金属。','darksteel'),
M('mat_zinc','锌','metal','common',{design:8,craft:6},0,null,['冷加工'],['高温'],'熔点很低，锻打需格外小心。','silver'),
M('mat_lead','铅','metal','common',{spirit:8,strength:-6,design:6},2,null,['冷加工'],['重锤','高温'],'沉重而柔软的灰色金属。','darksteel'),
// C 钢材 ×8
M('mat_hc_steel','高碳钢','steel','uncommon',{edge:22,strength:8,toughness:-4},3,'trait_carbonheart',['淬火','差温'],['冷加工'],'含碳量决定它能有多锋利。','steel'),
M('mat_tool_steel','工具钢','steel','common',{strength:16,edge:10,craft:4},1,null,['重锤'],['冷加工'],'为切削而生的钢。','iron'),
M('mat_spring_steel','弹簧钢','steel','uncommon',{toughness:22,strength:8},2,null,['差温','折叠'],['极限热锻'],'弯而不折是它的天性。','darksteel'),
M('mat_bearing_steel','轴承钢','steel','uncommon',{edge:14,strength:12,craft:6},2,null,['精密'],['手工'],'为承受百万次转动而生。','steel'),
M('mat_stainless','不锈钢','steel','common',{toughness:12,design:12,craft:4},1,'trait_silverscale',['冷加工'],['高温'],'永不生锈的日常之选。','silver'),
M('mat_hss','高速钢','steel','rare',{edge:24,strength:10,toughness:-6},4,null,['高温','精密'],['手工'],'红硬性极佳，切削如飞。','darksteel'),
M('mat_die_steel','模具钢','steel','uncommon',{strength:18,toughness:8},2,null,['重锤','精密'],['冷加工'],'在模具中沉默地承受一切。','iron'),
M('mat_carbon_steel','碳素钢','steel','common',{edge:12,strength:12},0,null,['热锻'],['冷加工'],'中规中矩的入门钢材。','iron'),
// D 合金 ×9
M('mat_ti_alloy','钛合金','alloy','rare',{strength:20,toughness:14,design:8},4,null,['冷加工','精密'],['高温'],'轻量化与强度的平衡之作。','steel'),
M('mat_ni_alloy','镍基合金','alloy','rare',{toughness:18,strength:14,spirit:4},4,null,['高温'],['冷加工'],'航空发动机叶片的材料。','silver'),
M('mat_co_alloy','钴合金','alloy','rare',{edge:16,strength:12,toughness:6},4,null,['高温'],['冷加工'],'耐磨与红硬的代名词。','darksteel'),
M('mat_tungsten_alloy','钨合金','alloy','epic',{strength:26,edge:12,spirit:6},6,'trait_tungcore',['重锤','高温'],['冷加工'],'密度惊人的重金属。','darksteel'),
M('mat_crmo','铬钼钢','alloy','uncommon',{strength:16,toughness:12},2,null,['热锻'],['精密'],'自行车架的经典选择。','iron'),
M('mat_super_alloy','特种合金','alloy','epic',{edge:14,strength:16,spirit:10,craft:6},6,null,['精密','星尘'],['手工'],'配方保密的军规材料。','unknown'),
M('mat_memory_alloy','记忆合金','alloy','epic',{toughness:20,spirit:14,strength:4},6,null,['冷加工'],['极限热锻'],'弯折之后，总会记得自己的形状。','silver'),
M('mat_mg_alloy','镁合金','alloy','uncommon',{design:12,toughness:8,strength:-6},3,null,['冷加工'],['高温','重锤'],'点燃它只需要一点火花。','silver'),
M('mat_beryllium_cu','铍青铜','alloy','rare',{spirit:12,design:14,strength:6},4,null,['手工','冷加工'],['高温'],'敲击时会发出钟鸣般的清音。','copper'),
// E 传统 ×8
M('mat_damascus','大马士革钢','traditional','rare',{craft:14,design:16,edge:8},4,null,['折叠'],['极限热锻'],'流淌着水波纹的传奇之钢。','damascus'),
M('mat_wootz','乌兹钢','traditional','epic',{edge:20,craft:14,spirit:6},6,null,['古法','手工'],['精密'],'古印度坩埚钢的结晶纹理。','wootz'),
M('mat_tamahagane','玉钢','traditional','rare',{edge:16,craft:12,spirit:8},5,'trait_jadesoul',['手工','古法'],['重锤'],'日本刀匠的毕生追求。','tamahagane'),
M('mat_cast_iron','铸铁','traditional','common',{strength:14,toughness:-8,craft:8},4,null,['高温'],['重锤','冷加工'],'坚硬但脆，需以柔克刚。','darksteel'),
M('mat_pattern_steel','花纹钢','traditional','uncommon',{design:16,craft:10},2,null,['折叠'],['高温'],'为花纹而生的复合钢。','damascus'),
M('mat_snow_steel','雪花钢','traditional','rare',{design:14,toughness:12,spirit:6},4,null,['折叠','冷加工'],['极限热锻'],'锻面如落雪，纹似冰花。','silver'),
M('mat_wrought_iron','镔铁','traditional','uncommon',{strength:14,toughness:10,craft:6},2,null,['折叠','手工'],['精密'],'千锤百炼的古法熟铁。','iron'),
M('mat_clad_steel','夹层钢','traditional','rare',{edge:16,toughness:12,craft:8},4,null,['折叠','差温'],['高温'],'三枚合结构，刚柔并济。','steel'),
// F 回收 ×9（必须带正面词条 + 一项负面属性）
M('mat_rail','旧铁轨','recycled','uncommon',{strength:25,craft:-8},5,'trait_veteran',['重锤','折叠'],['精密'],'历经数十年高负荷使用的钢材。','rust'),
M('mat_car_spring','汽车弹簧','recycled','uncommon',{toughness:24,design:-6},4,'trait_rebound',['差温','重锤'],['精密'],'从减震器里拆出来的好钢。','darksteel'),
M('mat_bearing_junk','轴承残件','recycled','common',{edge:16,craft:-6},4,'trait_veteran',['精密'],['手工'],'滚珠轴承的残骸，硬度犹在。','steel'),
M('mat_old_blank','废旧刀坯','recycled','common',{edge:12,design:-6},5,'trait_veteran',['热锻'],['冷加工'],'别人失败的作品，你的起点。','iron'),
M('mat_plate','工业钢板','recycled','common',{strength:18,design:-8},3,'trait_veteran',['重锤'],['精密'],'造船厂切下的厚重边角料。','iron'),
M('mat_machine_parts','老式机械零件','recycled','uncommon',{craft:16,spirit:-4},4,'trait_veteran',['精密'],['手工'],'齿轮与连杆，藏着旧时代的工艺。','rust'),
M('mat_saw_blade','报废锯片','recycled','common',{edge:18,toughness:-8},5,'trait_veteran',['冷加工'],['重锤'],'锯齿磨平了，钢还是好钢。','steel'),
M('mat_old_file','旧锉刀','recycled','uncommon',{edge:20,design:-6},5,'trait_veteran',['冷加工','精密'],['热锻'],'高碳钢的免费来源。','darksteel'),
M('mat_anchor_chain','废弃锚链','recycled','rare',{strength:26,spirit:-6},6,'trait_veteran',['重锤','高温'],['冷加工'],'海水中浸泡百年的巨链。','rust'),
// G 特殊 ×8（baseRisk ≥ 5，prefer/taboo 可空）
M('mat_meteor_iron','铁陨石','special','epic',{strength:15,spirit:8},5,'trait_meteor',['星尘'],[],'来自大气层之外的金属。','meteor'),
M('mat_pallasite','石铁陨石','special','epic',{spirit:16,design:10,strength:6},7,'trait_meteor',['星尘','冷加工'],['重锤'],'橄榄石与铁镍交织的宇宙切片。','meteor'),
M('mat_obsidian','黑曜石','special','rare',{edge:30,strength:-20},10,'trait_glass_edge',['冷加工'],['极限热锻','高温'],'火山玻璃的锋芒，脆弱而致命。','obsidian'),
M('mat_flame_crystal','赤焰晶','special','epic',{edge:14,spirit:18,toughness:-6},8,'trait_blaze',['高温','星尘'],['冷加工'],'握在掌心会微微发烫的晶体。','crystalR'),
M('mat_frost_crystal','寒霜晶','special','epic',{toughness:18,spirit:14,edge:-4},8,'trait_frost',['冷加工','星尘'],['高温'],'永不融化的深蓝结晶。','crystalB'),
M('mat_unknown','未知矿','special','mythic',{},15,null,[],[],'没人知道这是什么。','unknown'),
M('mat_moonrock','月岩','special','legendary',{spirit:22,design:12},9,'trait_moonlight',['星尘'],['重锤'],'静海盆地的灰色尘埃凝成的石。','unknown'),
M('mat_manganese_nodule','深海锰结核','special','rare',{toughness:16,spirit:10,strength:-6},6,'trait_deepsea',['冷加工'],['高温'],'四千米海底的金属果实。','darksteel'),
];
function T(id,name,trigger,effect,desc){return{id,name,trigger,effect,desc}}

const TRAITS=[
T('trait_veteran','老兵','match_test',{tests:{strength:1.10}},'强度检验 ×1.10。身经百战的钢材。'),
T('trait_glass_edge','玻璃锋','match_test',{tests:{sharpness:1.15,durability:0.90}},'锋利度检验 ×1.15，耐用度检验 ×0.90。'),
T('trait_meteor','陨星','forge_passive',{tag:'星尘',mult:1.25},'星尘标签卡收益 ×1.25。'),
T('trait_blaze','炽热','match_test',{tests:{sharpness:1.08}},'锋利度检验 ×1.08。刀身残留着灼热的温度。'),
T('trait_frost','寒锋','match_test',{tests:{durability:1.10}},'耐用度检验 ×1.10。寒气渗入钢骨。'),
T('trait_thousand_layers','千层纹','match_test',{tests:{finish:1.12},pattern:'layers'},'完成度检验 ×1.12。刀身显现叠层纹理。'),
T('trait_rebound_steel','回弹钢','match_test',{tests:{durability:1.15}},'耐用度检验 ×1.15。弯而不折。'),
T('trait_meteor_blade','陨星刃','match_special',{kind:'random_test',mult:1.2},'每场比赛随机一项检验 ×1.2。'),
T('trait_ancient','古法名刀','match_test',{tests:{finish:1.10}},'完成度检验 ×1.10。古法锻造的温度。'),
T('trait_stress','应力刀','match_special',{kind:'stress_break'},'每场比赛结束后 8% 概率直接断裂淘汰。'),
T('trait_bailian','百炼成钢','forge_passive',{stage:'forge',mult:1.15},'锻打卡收益 ×1.15。'),
T('trait_artisan','刀匠之手','match_test',{tests:{finish:1.08}},'完成度检验 ×1.08。手工的温度无法复制。'),
T('trait_magcore','磁心','forge_passive',{stage:'melt',mult:1.10},'熔炼卡收益 ×1.10。'),
T('trait_deepsea','深海记忆','forge_passive',{stage:'quench',mult:1.10},'淬火卡收益 ×1.10。'),
T('trait_jadesoul','玉魂','forge_passive',{stage:'handle',mult:1.15},'装配卡收益 ×1.15。'),
T('trait_carbonheart','碳心','forge_passive',{stage:'temper',mult:1.20},'回火卡收益 ×1.20。'),
T('trait_starmap','星图','forge_passive',{stage:'edge',mult:1.10},'开刃卡收益 ×1.10。以星辰为参照开刃。'),
T('trait_tungcore','钨芯','match_test',{tests:{strength:1.12}},'强度检验 ×1.12。沉重而坚硬的核心。'),
T('trait_silverscale','银鳞','match_test',{tests:{finish:1.08}},'完成度检验 ×1.08。银色鳞状光泽。'),
T('trait_moonlight','月华','match_test',{tests:{finish:1.10}},'完成度检验 ×1.10。刀身泛着月色微光。'),
T('trait_spring_core','弹簧芯','match_test',{tests:{durability:1.08}},'耐用度检验 ×1.08。减震器里拆出来的天赋。'),
T('trait_thunder','雷鸣','match_test',{tests:{strength:1.08}},'强度检验 ×1.08。敲击时声如闷雷。'),
T('trait_bloodgroove','血槽','match_test',{tests:{sharpness:1.10}},'锋利度检验 ×1.10。放血槽带来更狠的切割。'),
T('trait_frostedge','霜刃','match_test',{tests:{sharpness:1.06,durability:1.06}},'锋利度与耐用度检验 ×1.06。'),
T('trait_mountainsplit','断岳','match_test',{tests:{strength:1.12}},'强度检验 ×1.12。势大力沉，可断山岳。'),
T('trait_ghost','幽灵刃','match_special',{kind:'tiebreak',mult:1.05},'2:2 加赛总评 ×1.05。如影随形。'),
T('trait_clockwork','奇械之心','match_special',{kind:'first_round',mult:1.15},'每场比赛首回合检验 ×1.15。'),
T('trait_frostripe','霜纹','cosmetic',{pattern:'frost'},'刀身浮现霜花纹理。（外观）'),
T('trait_flamemark','焰纹','cosmetic',{pattern:'flame'},'刀身浮现火焰纹理。（外观）'),
T('trait_starfleck','星斑','cosmetic',{pattern:'stars'},'刀身散布星点斑纹。（外观）'),
];
const TRAIT_MAP=Object.fromEntries(TRAITS.map(t=>[t.id,t]));

const COMBOS=[
{id:'c_thousand',needs:[{material:'mat_damascus'},{cardTag:'折叠'}],grantsTrait:'trait_thousand_layers'},
{id:'c_rebound',needs:[{material:'mat_spring_steel'},{cardTag:'差温'}],grantsTrait:'trait_rebound_steel'},
{id:'c_meteorblade',needs:[{material:'mat_meteor_iron'},{cardTag:'星尘'}],grantsTrait:'trait_meteor_blade'},
{id:'c_glasscold',needs:[{material:'mat_obsidian'},{cardTag:'冷加工'}],grantsTrait:'trait_frostedge'},
{id:'c_ancient',needs:[{material:'mat_wootz'},{cardTag:'古法'}],grantsTrait:'trait_ancient'},
{id:'c_thunder',needs:[{material:'mat_beryllium_cu'},{cardTag:'重锤'}],grantsTrait:'trait_thunder'},
{id:'c_blood',needs:[{material:'mat_hss'},{cardTag:'差温'}],grantsTrait:'trait_bloodgroove'},
{id:'c_mountain',needs:[{material:'mat_tungsten_alloy'},{cardTag:'重锤'}],grantsTrait:'trait_mountainsplit'},
{id:'c_frostripe',needs:[{material:'mat_frost_crystal'},{cardTag:'冷加工'}],grantsTrait:'trait_frostripe'},
{id:'c_flame',needs:[{material:'mat_flame_crystal'},{cardTag:'高温'}],grantsTrait:'trait_flamemark'},
{id:'c_starfleck',needs:[{material:'mat_pallasite'},{cardTag:'星尘'}],grantsTrait:'trait_starfleck'},
{id:'c_pattern',needs:[{material:'mat_pattern_steel'},{cardTag:'折叠'}],grantsTrait:'trait_thousand_layers'},
{id:'c_clad',needs:[{material:'mat_clad_steel'},{cardTag:'差温'}],grantsTrait:'trait_rebound_steel'},
{id:'c_wrought',needs:[{material:'mat_wrought_iron'},{cardTag:'手工'}],grantsTrait:'trait_artisan'},
{id:'c_tamahagane',needs:[{material:'mat_tamahagane'},{cardTag:'手工'}],grantsTrait:'trait_ancient'},
{id:'c_moon',needs:[{material:'mat_moonrock'},{cardTag:'星尘'}],grantsTrait:'trait_starfleck'},
{id:'c_nodule',needs:[{material:'mat_manganese_nodule'},{cardTag:'冷加工'}],grantsTrait:'trait_frostripe'},
{id:'c_rail_heavy',needs:[{material:'mat_rail'},{cardTag:'重锤'}],grantsTrait:'trait_mountainsplit'},
{id:'c_spring_re',needs:[{material:'mat_car_spring'},{cardTag:'差温'}],grantsTrait:'trait_rebound_steel'},
{id:'c_file_cold',needs:[{material:'mat_old_file'},{cardTag:'冷加工'}],grantsTrait:'trait_frostedge'},
{id:'c_chain',needs:[{material:'mat_anchor_chain'},{cardTag:'高温'}],grantsTrait:'trait_thunder'},
{id:'c_saw',needs:[{material:'mat_saw_blade'},{cardTag:'锯齿'}],grantsTrait:'trait_bloodgroove'},
{id:'c_obsidian_hand',needs:[{material:'mat_obsidian'},{cardTag:'手工'}],grantsTrait:'trait_bloodgroove'},
{id:'c_ti',needs:[{material:'mat_titanium'},{cardTag:'精密'}],grantsTrait:'trait_silverscale'},
{id:'c_memory',needs:[{material:'mat_memory_alloy'},{cardTag:'冷加工'}],grantsTrait:'trait_rebound_steel'},
{id:'c_cobalt',needs:[{material:'mat_cobalt'},{cardTag:'高温'}],grantsTrait:'trait_flamemark'},
{id:'c_super',needs:[{material:'mat_super_alloy'},{cardTag:'星尘'}],grantsTrait:'trait_meteor_blade'},
{id:'c_nickel_fold',needs:[{material:'mat_nickel'},{cardTag:'折叠'}],grantsTrait:'trait_thousand_layers'},
{id:'c_damascus_star',needs:[{material:'mat_damascus'},{cardTag:'星尘'}],grantsTrait:'trait_starfleck'},
{id:'c_stibnite',needs:[{material:'mat_stibnite'},{cardTag:'冷加工'}],grantsTrait:'trait_frostedge'},
];
const STAT_SCALE=1.8;

const RISK_PATCH={melt_inject:{cardRisk:8},melt_crucible:{cardRisk:4},melt_filter:{riskMod:2},melt_em:{cardRisk:4},forge_press:{cardRisk:5},forge_steam:{cardRisk:5},forge_rhythm:{riskMod:3},forge_hydraulic:{cardRisk:4},fold_thin:{cardRisk:10},fold_machete:{riskMod:2},fold_pattern:{riskMod:3},fold_kris:{cardRisk:5},fold_multi:{riskMod:3},quench_polymer:{cardRisk:5},quench_spray:{cardRisk:8},quench_isothermal:{riskMod:3},edge_micro:{cardRisk:5},edge_compound:{cardRisk:5},edge_saw:{riskMod:5},edge_wave:{cardRisk:5},handle_ergo:{cardRisk:5},handle_inlay:{riskMod:3},handle_titanium:{cardRisk:4},handle_carbon:{cardRisk:4},tune_precise_bal:{cardRisk:5},tune_micron:{riskMod:4},tune_coating:{cardRisk:4},tune_reinforce:{cardRisk:4}};

function C(stage,id,name,rarity,icon,stats,extra,desc){const scaled=stats?Object.fromEntries(Object.entries(stats).map(([k,v])=>[k,Math.round(v*STAT_SCALE)])):null;const idFull=stage+'_'+id;return Object.assign({id:idFull,stage,name,rarity,icon,desc:desc||''},scaled?{stats:scaled}:{},extra||{},RISK_PATCH[idFull]||{});}

const CARDS=[
/* ② 熔炼 MELT */
C('melt','normal','普通熔炼','common','flame',{edge:2,strength:2,toughness:2,spirit:2,craft:2,design:2},0,'标准工艺熔炼，六维均衡提升。'),
C('melt','high_temp','高温熔炼','common','flame',{edge:12,strength:5},{riskMod:5,tags:['高温']},'提高炉温，换取更纯粹的钢水。'),
C('melt','low_refine','低温精炼','common','snow',{craft:12,toughness:8},{tags:['冷加工']},'低温慢炼，杂质自然析出。'),
C('melt','steady','恒温熔炼','common','scale',{craft:10,toughness:6},0,'保持恒温，结构均匀。'),
C('melt','slag','搅拌除渣','common','wind',{craft:8,design:6},0,'搅去渣滓，钢面更干净。'),
C('melt','batch','分批投料','common','anvil',{strength:8,toughness:8},0,'分批投料，受热更均匀。'),
C('melt','gentle','文火熔炼','common','hand',{spirit:8,craft:8},{tags:['手工']},'文火慢炖，钢水也有了脾气。'),
C('melt','blast','鼓风熔炼','common','wind',{edge:8,strength:8},{tags:['高温']},'鼓风助燃，火力更猛。'),
C('melt','multi_refine','多次精炼','uncommon','spiral',{craft:15},{riskMod:3},'反复精炼，纯度与隐患一同累积。'),
C('melt','em','电磁熔炼','uncommon','bolt',{craft:12,design:8},{tags:['精密']},'电磁悬浮熔炼，无接触无污染。'),
C('melt','crucible','坩埚精炼','uncommon','drop',{toughness:12,craft:8},0,'坩埚中静静析出杂质。'),
C('melt','inject','喷吹熔炼','uncommon','flame',{edge:14,strength:6},{riskMod:4,tags:['高温']},'高压喷吹，剧烈反应。'),
C('melt','filter','滤渣工艺','uncommon','eye',{craft:12,spirit:8},0,'过滤钢渣，只取精华。'),
C('melt','vacuum','真空熔炼','rare','gem',{craft:20},{riskMod:-5},'真空环境熔炼，净化钢水（累积风险 −5）。'),
C('melt','plasma','等离子熔炼','rare','bolt',{edge:18,craft:10},{cardRisk:8,tags:['高温']},'等离子弧温度极高，控制稍难。'),
C('melt','float','浮选提纯','rare','drop',{design:14,craft:12},0,'浮选法分离杂质。'),
C('melt','soul','灵魂熔炼','rare','moon',{spirit:24,craft:4},{tags:['星尘']},'向钢水中注入一缕星尘。'),
C('melt','extreme','极限熔炼','epic','flame',{edge:25},{cardRisk:20},'逼近材料熔点极限的豪赌。'),
C('melt','vortex','漩涡熔炼','epic','spiral',{strength:20,craft:14},{riskMod:6},'电磁漩涡搅拌均匀组织。'),
C('melt','sun','太阳熔炉','legendary','sun',{edge:22,strength:18},{cardRisk:15,tags:['高温','星尘']},'聚焦日光熔钢，传说级别的炉温。'),
/* ③ 锻打 FORGE */
C('forge','hand','手工锤打','common','hand',{craft:12},{tags:['手工','锻打']},'一锤一锤，打出刀的灵魂。'),
C('forge','heavy','重锤锻打','common','hammer',{strength:20,toughness:-5},{tags:['重锤','热锻','锻打']},'重锤出击，刚猛有余。'),
C('forge','fast','快速锻打','common','bolt',{edge:12},{tags:['热锻','锻打']},'趁热快打，锁住锋芒。'),
C('forge','light','轻锤整形','common','hand',{design:8,craft:6},{tags:['手工','锻打']},'轻锤慢敲，修整外形。'),
C('forge','anvil','砧上整形','common','anvil',{strength:8,craft:6},{tags:['锻打']},'在铁砧上校正规整。'),
C('forge','hot','趁热锻打','common','flame',{strength:12,edge:4},{tags:['热锻','锻打']},'趁红热状态快速成形。'),
C('forge','alternate','交替锤打','common','hammer',{toughness:8,strength:6},{tags:['锻打']},'两面交替，受力均匀。'),
C('forge','slow','慢速精锻','common','scale',{craft:10,toughness:4},{tags:['锻打']},'慢工出细活。'),
C('forge','precise','精密锻打','uncommon','needle',{craft:18},{tags:['精密','锻打']},'毫米级精度控制。'),
C('forge','steam','蒸汽锤','uncommon','hammer',{strength:25},{tags:['重锤','锻打']},'工业革命的力量。'),
C('forge','hydraulic','液压锻造','uncommon','anvil',{strength:18,craft:8},{tags:['锻打']},'液压机稳定施压。'),
C('forge','press','锻压一体','uncommon','shield',{strength:14,toughness:8},{tags:['重锤','锻打']},'锻压结合，致密结实。'),
C('forge','rhythm','节奏锤击','uncommon','hand',{craft:12,design:8},{tags:['手工','锻打']},'跟着节奏敲打，如奏乐一般。'),
C('forge','bailian','百炼','rare','spiral',{strength:10},{special:'bailian',tags:['锻打']},'本局每选过一次锻打系卡，强度额外 +4。'),
C('forge','ancient','古法锻打','rare','moon',{craft:22},{tags:['手工','古法','锻打']},'沿用千年前的锻打手法。'),
C('forge','twist','螺旋锻打','rare','spiral',{design:16,strength:10},{tags:['锻打']},'边旋边打，纹理如螺。'),
C('forge','ductile','韧性锻打','rare','shield',{toughness:20,strength:8},{riskMod:4,tags:['锻打']},'低温区反复锻打，提升韧性。'),
C('forge','extreme_hit','极限锤击','epic','hammer',{strength:35},{cardRisk:25,tags:['极限热锻','重锤','锻打']},'全力以赴的一锤，成则大成。'),
C('forge','hydra10k','万吨水压','epic','anvil',{strength:28,craft:10},{riskMod:8,tags:['锻打']},'万吨水压机缓缓压下。'),
C('forge','thor','雷神之锤','legendary','bolt',{strength:30,edge:12},{cardRisk:18,tags:['重锤','锻打']},'传说中的神锤，一击定形。'),
/* ④ 折叠加工 FOLD */
C('fold','normal','普通折叠','common','spiral',{craft:10},{tags:['折叠']},'对折再锻合，排出夹杂物。'),
C('fold','thick_spine','厚背加工','common','shield',{strength:18},0,'加厚刀背，稳字当头。'),
C('fold','fold_forge','折叠锻打','common','hammer',{craft:8,strength:6},{tags:['折叠','锻打']},'折叠后趁热锻合。'),
C('fold','trim','修边加工','common','blade',{design:10,edge:4},0,'修整边缘线条。'),
C('fold','tangdao','唐刀锻造','common','blade',{design:8,craft:6},{blade:'tangdao',tags:['刀型']},'锻为唐刀：直身切刃，气度雄浑。'),
C('fold','folding','折叠刀定型','common','blade',{edge:8,craft:6},{blade:'knife_folding',tags:['刀型']},'沿折叠刀的结构线定型，保留灵活的刀身比例。'),
C('fold','saber','弯刀定型','common','blade',{edge:8,design:6},{blade:'knife_saber',tags:['刀型']},'沿现有弯刀模型的弧线定型。'),
C('fold','wide','宽刃加工','common','shield',{strength:10,toughness:4},0,'加宽刀身，劈砍有力。'),
C('fold','multi','多层折叠','uncommon','spiral',{craft:15,design:8},{tags:['折叠']},'反复折叠，层数指数增长。'),
C('fold','cross','交叉折叠','uncommon','cross',{strength:12,toughness:8},{tags:['折叠']},'纵横交叉折叠，纹理如织。'),
C('fold','thin','薄刃加工','uncommon','blade',{edge:20,strength:-8},0,'刀身打薄，锋利但脆弱。'),
C('fold','machete','开山刀定型','uncommon','blade',{edge:12,design:8},{blade:'knife_machete',tags:['刀型']},'加宽刀身并强化前段刃线。'),
C('fold','gladius','短剑定型','uncommon','blade',{edge:14,craft:4},{blade:'knife_gladius',tags:['刀型']},'强化短剑的直线刃面与结构稳定性。'),
C('fold','twist','扭转锻造','rare','spiral',{design:20},{tags:['折叠']},'扭转钢坯，纹路旋如流水。'),
C('fold','local','局部强化','rare','needle',0,{special:'pickstat'},'指定一项属性 +15。'),
C('fold','pattern','花纹折叠','rare','wave',{design:16,craft:10},{tags:['折叠']},'刻意锻出花纹走向。'),
C('fold','kris','波形刀定型','rare','wave',{edge:22,design:6},{blade:'knife_kris',tags:['刀型']},'沿波形刀身定型，强化起伏刃线的视觉表现。'),
C('fold','exotic','异形加工','epic','eye',{design:25},{special:'exotic',tags:['异形']},'打破常规，刀型随机变为原创异形。'),
C('fold','karambit','爪刀锻造','rare','blade',{edge:16,design:8},{blade:'karambit',tags:['刀型']},'锻为爪刀：猛禽之爪，反握而生。'),
C('fold','bayonet','刺刀锻造','common','blade',{edge:10,strength:6},{blade:'bayonet',tags:['刀型']},'锻为刺刀：笔直、可靠、致命。'),
C('fold','butterfly','蝴蝶刀锻造','epic','blade',{edge:18,design:14},{blade:'butterfly',tags:['刀型']},'锻为蝴蝶刀：指间翻飞的芭蕾。'),
C('fold','survival','求生匕首定型','uncommon','blade',{strength:12,toughness:8},{blade:'knife_survival',tags:['刀型']},'强化求生匕首的厚实刀身与稳定结构。'),
C('fold','thousand','千层折叠','epic','spiral',{craft:26,design:10},{riskMod:8,tags:['折叠']},'折叠十余次，千层钢纹。'),
C('fold','hundred_pat','百炼钢纹','legendary','wave',{craft:20,design:22},{tags:['折叠','手工']},'手工折叠百次，纹如行云流水。'),
/* ⑤ 淬火 QUENCH */
C('quench','water','清水淬火','common','drop',{toughness:15},{quench:'water'},'清水淬火，温和稳定。'),
C('quench','oil','油淬','common','drop',{strength:12,toughness:8},{quench:'oil'},'油冷速度缓和，应力更小。'),
C('quench','warm','温水淬火','common','drop',{toughness:12,edge:4},{quench:'water'},'温水慢冷，刚柔并济。'),
C('quench','mist','雾气淬火','common','wind',{toughness:10,craft:6},0,'水雾弥散，冷却均匀。'),
C('quench','slow','缓慢淬火','common','snow',{toughness:14},{riskMod:-2},'缓慢冷却，释放应力。'),
C('quench','oil2','常规油淬','common','drop',{strength:10,toughness:6},{quench:'oil'},'标准油淬工艺。'),
C('quench','mist_mix','水雾混合','common','drop',{toughness:12,design:4},{quench:'water'},'水雾交替喷洒。'),
C('quench','stable','稳态淬火','common','scale',{craft:12,toughness:4},0,'控温稳冷，品质可控。'),
C('quench','brine','盐水淬火','uncommon','drop',{edge:12,toughness:12},{quench:'brine'},'盐水冷速更快，硬度更高。'),
C('quench','ice','冰水淬火','uncommon','snow',{edge:25},{cardRisk:15,tags:['冷加工'],quench:'ice'},'冰水急冷，硬度极高，开裂风险也大。'),
C('quench','hotoil','热油淬火','uncommon','flame',{strength:20},{cardRisk:10,tags:['高温'],quench:'hotoil'},'热油淬火，强劲但需控温。'),
C('quench','polymer','聚合物淬火','uncommon','drop',{toughness:16,craft:6},0,'高分子介质，冷速可控。'),
C('quench','spray','喷雾淬火','uncommon','wind',{edge:10,toughness:10},{riskMod:3},'细雾急喷，局部快冷。'),
C('quench','martemper','分级淬火','rare','scale',{toughness:20},{riskMod:-5,quench:'martemper'},'分级降温，应力尽释（累积风险 −5）。'),
C('quench','diff','差温淬火','rare','wave',{edge:15,toughness:15},{tags:['差温'],quench:'diff'},'刃硬背韧，烧刃纹浮现。'),
C('quench','isothermal','等温淬火','rare','scale',{toughness:22,strength:6},0,'等温转变，组织细密。'),
C('quench','cryo','深冷处理','rare','snow',{edge:18,toughness:8},{cardRisk:8,tags:['冷加工']},'零下百度的深冷，转化残余奥氏体。'),
C('quench','extreme','极限淬火','epic','bolt',{edge:35},{cardRisk:30,tags:['极限热锻'],quench:'extreme'},'极限冷速，要么妖刀，要么断刀。'),
C('quench','dual','双液淬火','epic','drop',{edge:22,toughness:14},{cardRisk:12},'先水后油，时机只在刹那。'),
C('quench','stardust','星尘淬火','legendary','star',{spirit:30},{cardRisk:35,tags:['星尘'],quench:'stardust'},'以星尘为介质，淬出通灵的刀。'),
/* ⑥ 回火 TEMPER */
C('temper','standard','标准回火','common','scale',0,{riskMod:-10},'标准回火，释放淬火应力（累积风险 −10）。'),
C('temper','low','低温回火','common','snow',{toughness:15},0,'低温回火，保持硬度提升韧性。'),
C('temper','high','高温回火','common','flame',{strength:12},{tags:['高温']},'高温回火，强韧平衡。'),
C('temper','mid','中温回火','common','scale',{toughness:10,strength:4},0,'中温区间回火。'),
C('temper','furnace','炉冷回火','common','wind',{craft:6},{riskMod:-6},'随炉缓冷（累积风险 −6）。'),
C('temper','aging','时效处理','common','moon',{toughness:8,craft:6},0,'长时间时效，性能沉淀。'),
C('temper','rest','静置回火','common','hand',{spirit:4},{riskMod:-8},'静置数日，应力自然消散。'),
C('temper','residual','余温回火','common','flame',{toughness:10},{riskMod:-3},'利用淬火余温自行回火。'),
C('temper','multi','多次回火','uncommon','spiral',0,{riskMod:-20},'反复回火，层层释压（累积风险 −20）。'),
C('temper','oil_bath','油浴回火','uncommon','drop',{toughness:12},{riskMod:-8},'油浴恒温回火。'),
C('temper','salt_bath','盐浴回火','uncommon','drop',{strength:10},{riskMod:-8},'盐浴传热均匀。'),
C('temper','induction','感应回火','uncommon','bolt',{craft:12},{riskMod:-6,tags:['精密']},'感应加热，精准控温。'),
C('temper','atmosphere','气氛回火','uncommon','wind',{design:10},{riskMod:-8},'保护气氛中回火，表面无损。'),
C('temper','extreme','极限回火','rare','bolt',{edge:-10},{riskMod:-30},'深度回火释尽隐患，锋芒稍损（累积风险 −30）。'),
C('temper','cryo','深冷回火','rare','snow',{toughness:16},{riskMod:-12,tags:['冷加工']},'深冷+回火循环。'),
C('temper','gradient','梯度回火','rare','wave',{toughness:14,edge:8},{riskMod:-6,tags:['差温']},'沿刀身梯度回火。'),
C('temper','vacuum','真空回火','rare','gem',{craft:14},{riskMod:-12},'真空环境回火，零氧化。'),
C('temper','destress','去应力退火','epic','shield',{strength:-8},{riskMod:-40},'彻底退火去应力（累积风险 −40）。'),
C('temper','iso_anneal','等温退火','epic','scale',{toughness:24},{riskMod:-10},'等温退火，组织重组。'),
C('temper','no_temper','不回火','legendary','flame',0,{statPct:{edge:10,strength:10},grants:['trait_stress']},'锋利/强度 +10%。获得词条「应力刀」：每场比赛结束 8% 概率断裂淘汰。'),
/* ⑦ 开刃 EDGE */
C('edge','hand','手工开刃','common','hand',{edge:10,craft:5},{es:'handmade',tags:['手工']},'手工水磨，刃口温润。'),
C('edge','machine','机器开刃','common','gear',{edge:14},{es:'machine',tags:['精密']},'机器开刃，角度精准。'),
C('edge','flat','平刃打磨','common','blade',{edge:12},{es:'flat'},'经典平刃，均衡耐用。'),
C('edge','thick','厚刃打磨','common','shield',{edge:8,strength:6},{es:'thick'},'厚刃口，耐冲击。'),
C('edge','rough','粗磨开刃','common','blade',{edge:14},{es:'flat',riskMod:2},'快速粗磨，省时但留隐患。'),
C('edge','convex','凸刃研磨','common','blade',{edge:12,toughness:4},{es:'convex'},'蛤刃，兼顾锋利与强度。'),
C('edge','concave','凹刃研磨','common','blade',{edge:16,strength:-4},{es:'concave'},'凹磨极薄，切割顺滑。'),
C('edge','standard','标准开刃','common','blade',{edge:10,design:4},{es:'flat'},'标准工艺开刃。'),
C('edge','mirror','镜面刃','uncommon','gem',{design:15,edge:8},{es:'mirror'},'镜面研磨，光可鉴人。'),
C('edge','micro','微刃处理','uncommon','needle',{edge:16,craft:6},{es:'micro'},'微观锯齿，切感细腻。'),
C('edge','compound','复合刃','uncommon','cross',{edge:12,toughness:8},{es:'compound'},'两段刃角，前锐后韧。'),
C('edge','wave','波刃研磨','uncommon','wave',{edge:16,design:8},{es:'wave'},'波浪刃口，切割带撕扯。'),
C('edge','saw','锯齿刃','uncommon','blade',{edge:18,toughness:-4},{es:'saw',tags:['锯齿']},'锯齿刃口，锯切两用。'),
C('edge','limit','极限开刃','rare','bolt',{edge:30,toughness:-10},{cardRisk:10,es:'limit'},'逼近物理极限的薄刃。'),
C('edge','reverse','反刃设计','rare','blade',{edge:20,design:8},{es:'reverse'},'反曲刃型，勾起切割。'),
C('edge','double','双刃开锋','rare','cross',{edge:24,strength:-6},{es:'double'},'双刃俱利，刀身受力更苛刻。'),
C('edge','fine','精研开刃','rare','hand',{edge:18,craft:10},{es:'handmade',tags:['手工']},'千目精研，刃如秋霜。'),
C('edge','molecular','分子级开刃','epic','needle',{edge:32},{cardRisk:15,es:'extreme',tags:['精密']},'在显微镜下修整刃口。'),
C('edge','alien_edge','异形开刃','epic','eye',{edge:24,design:12},{es:'alien'},'非常规刃线，难以捉摸。'),
C('edge','unknown_edge','未知刃','mythic','star',0,{special:'unknown_edge',es:'unknown'},'随机刃型 + 随机一项属性 ±(15–40) + 随机词条。'),
/* ⑧ 装配刀柄 HANDLE */
C('handle','walnut','胡桃木柄','common','hand',{design:8,toughness:4},{handle:'walnut'},'胡桃木温润趁手。'),
C('handle','bamboo','竹柄','common','leaf',{design:8,spirit:4},{handle:'bamboo'},'竹节清逸，握感轻盈。'),
C('handle','leather','皮革缠柄','common','hand',{toughness:10},{handle:'leather'},'皮革缠裹，防滑吸汗。'),
C('handle','rope','绳缠柄','common','spiral',{toughness:8,edge:4},{handle:'rope'},'绳缠柄卷，日式风味。'),
C('handle','aluminum','铝合金柄','common','gear',{strength:6,design:6},{handle:'aluminum'},'轻量金属柄。'),
C('handle','standard','标准装配','common','gear',{craft:12},{handle:'walnut'},'标准化装配流程。'),
C('handle','balance','重心调整','common','scale',{edge:6,strength:6},{handle:'titanium'},'调整重心，运刀更顺。'),
C('handle','pommel','尾锤配重','common','anvil',{strength:8,design:4},{handle:'brass'},'加重尾锤，平衡刀身。'),
C('handle','carbon','碳纤维柄','uncommon','gear',{toughness:5,edge:5},{handle:'carbon'},'碳纤维轻量化，操控与强度兼得。'),
C('handle','bone','骨柄','uncommon','gem',{design:12,spirit:6},{handle:'bone'},'兽骨为柄，古朴苍茫。'),
C('handle','brass','黄铜柄','uncommon','sun',{design:12,strength:6},{handle:'brass'},'黄铜护手与柄首，沉甸甸的质感。'),
C('handle','titanium','钛合金柄','uncommon','shield',{strength:10,toughness:8},{handle:'titanium'},'钛合金柄，轻而坚固。'),
C('handle','ebony','黑檀木柄','uncommon','leaf',{design:14,craft:4},{handle:'ebony'},'黑檀入鞘，沉稳内敛。'),
C('handle','jade','玉柄','rare','gem',{design:25,strength:-5},{handle:'jade'},'君子比德于玉。'),
C('handle','mech','机械柄','rare','gear',{craft:20},{handle:'mech'},'精密机械结构，工程美学。'),
C('handle','ergo','人体工学柄','rare','hand',{toughness:12,edge:10},{handle:'ergo'},'贴合掌型的曲线。'),
C('handle','inlay','嵌丝工艺','rare','star',{design:18,spirit:8},{handle:'inlay'},'金银嵌丝，流光暗涌。'),
C('handle','living','活体柄芯','epic','eye',{spirit:26},{cardRisk:10,tags:['星尘'],handle:'mech'},'柄芯中封入一缕活性星尘。'),
C('handle','levitate','悬浮配重','epic','bolt',{edge:18,design:14},{cardRisk:8,handle:'carbon'},'磁悬浮配重，重心随心而动。'),
C('handle','qixie','奇械柄','legendary','gear',0,{special:'qixie',handle:'mech'},'奇械机关，随机获得一种特殊效果。'),
/* ⑨ 最终调校 TUNE */
C('tune','polish','完美抛光','common','gem',{design:20},0,'镜面抛光，光可照人。'),
C('tune','final_edge','最终开锋','common','blade',{edge:20},0,'出厂前的最后一磨。'),
C('tune','balance','平衡调整','common','scale',{strength:8,toughness:8},0,'微调重心与配平。'),
C('tune','detail','细节修整','common','needle',{design:10,craft:6},0,'修整每一处细节。'),
C('tune','inspect','刃口复检','common','eye',{edge:12},{riskMod:-2},'复检刃口，排除隐患。'),
C('tune','reshape','整形锻打','common','hammer',{strength:8,design:6},{tags:['锻打']},'轻度整形，修正线条。'),
C('tune','passivate','表面钝化','common','shield',{toughness:12,design:4},0,'表面钝化处理，抗蚀耐久。'),
C('tune','clean','最终清洁','common','wind',{design:12,spirit:4},0,'拭去浮尘，静待鉴定。'),
C('tune','reinforce','结构加固','uncommon','shield',{strength:15,toughness:15},0,'结构加固，稳如磐石。'),
C('tune','mirror_polish','镜面抛光','uncommon','gem',{design:18,spirit:4},0,'抛至镜面，映出心绪。'),
C('tune','precise_bal','精准配平','uncommon','scale',{craft:14,edge:8},0,'毫克级配平。'),
C('tune','stress_relief','应力释放','uncommon','wind',{toughness:6},{riskMod:-12},'振动时效，释放残余应力。'),
C('tune','coating','涂层保护','uncommon','drop',{toughness:12,design:8},0,'陶瓷涂层，保护与质感兼得。'),
C('tune','spirit','灵性调校','rare','moon',{spirit:25},0,'以特殊频率激发刀的灵性。'),
C('tune','resonance','共振调校','rare','wave',{spirit:14,craft:12},0,'找到刀身的共振频率。'),
C('tune','micron','微米级调校','rare','needle',{craft:20,edge:8},{tags:['精密']},'微米级精度终调。'),
C('tune','hand_finish','手工终饰','rare','hand',{design:16,craft:10},{tags:['手工']},'匠人手工收尾。'),
C('tune','extreme_tune','极限调校','epic','star',{edge:10,strength:10,toughness:10,spirit:10,craft:10,design:10},{cardRisk:20},'六维全面提升的极限调校，风险自负。'),
C('tune','master_eye','大师之眼','epic','eye',{craft:24,design:12},{riskMod:6},'大师亲自过眼，吹毛求疵。'),
C('tune','divine','神锻','mythic','sun',{edge:15,strength:15,toughness:15,spirit:15,craft:15,design:15},{cardRisk:25,tags:['星尘']},'如有神助的一次调校。'),
];
function BT(id,name,region,family,p){return Object.assign({id,name,region,family,len:.82,wid:34,curve:0,tip:'point'},p)}
const HANDLES={
  ebony:{name:'黑檀木',c1:'#2a1f16',c2:'#54402c',tex:'wood',shape:'straight'},
  walnut:{name:'胡桃木',c1:'#5a3d26',c2:'#8a6038',tex:'wood',shape:'waist'},
  bamboo:{name:'竹',c1:'#9a8a50',c2:'#c8b87e',tex:'bamboo',shape:'seg'},
  leather:{name:'皮革',c1:'#6b4226',c2:'#96603a',tex:'wrap',shape:'straight'},
  rope:{name:'绳缠',c1:'#7e7252',c2:'#ab9c72',tex:'wrap',shape:'waist'},
  bone:{name:'骨',c1:'#c8c2b2',c2:'#eee9dc',tex:'bone',shape:'taper'},
  jade:{name:'玉石',c1:'#3e6b58',c2:'#7ec0a2',tex:'jade',shape:'oval'},
  brass:{name:'黄铜',c1:'#9a7a36',c2:'#dcbc6a',tex:'metal',shape:'flat'},
  aluminum:{name:'铝合金',c1:'#828a94',c2:'#c2cad2',tex:'metal',shape:'flat'},
  titanium:{name:'钛合金',c1:'#5e6a7a',c2:'#96a4b6',tex:'metal',shape:'waist'},
  carbon:{name:'碳纤维',c1:'#22262d',c2:'#3e4650',tex:'carbon',shape:'flat'},
  mech:{name:'机械结构',c1:'#3a4a5a',c2:'#6a8aa8',tex:'mech',shape:'seg'},
  unknown_h:{name:'未知材料',c1:'#3a3455',c2:'#6a5f9a',tex:'jade',shape:'oval'},
  ergo:{name:'人体工学柄',c1:'#383d46',c2:'#5a616c',tex:'ergo',shape:'ergo'},
  inlay:{name:'嵌丝柄',c1:'#261b12',c2:'#4e3a28',tex:'inlay',shape:'waist'},
};
const QUENCH_MEDIA={
  water:{name:'清水',edge:'#e8eef4',temper:['#e8eef4','#ccd6e2']},
  oil:{name:'油',edge:'#e8c98a',temper:['#e8c98a','#c89a5a'],glow:'rgba(232,201,138,.25)'},
  brine:{name:'盐水',edge:'#d4e2ec',temper:['#d4e2ec','#b4c8d8']},
  ice:{name:'冰水',edge:'#a8dcf8',temper:['#bfe4fa','#8ec8ee'],glow:'rgba(79,195,247,.4)'},
  hotoil:{name:'热油',edge:'#ffab5e',temper:['#ffbf80','#e89040'],glow:'rgba(255,122,41,.3)'},
  martemper:{name:'分级',edge:'#bcc8ea',temper:['#c4ceec','#8a9ad0']},
  diff:{name:'差温',edge:'#f5f8fb',temper:['#f2f5f9','#dde4ec'],hamon:1},
  stardust:{name:'星尘',edge:'#d0c2ff',temper:['#d8ccff','#a894e8'],glow:'rgba(168,159,216,.5)',stars:1},
  extreme:{name:'极限',edge:'#ffffff',temper:['#ffffff','#e8ecf2'],glow:'rgba(255,255,255,.35)'},
};
const EDGE_STYLES={
  flat:{name:'平刃',mode:'flat'},convex:{name:'凸刃',mode:'convex'},concave:{name:'凹刃',mode:'concave'},
  compound:{name:'复合刃',mode:'compound'},double:{name:'双刃',mode:'double'},wave:{name:'波刃',mode:'wave'},
  saw:{name:'锯齿刃',mode:'saw'},reverse:{name:'反刃',mode:'reverse'},mirror:{name:'镜面刃',mode:'mirror'},
  micro:{name:'微刃',mode:'micro'},thick:{name:'厚刃',mode:'thick'},extreme:{name:'极锋',mode:'extreme'},
  handmade:{name:'手工开刃',mode:'flat'},machine:{name:'机器开刃',mode:'flat'},limit:{name:'极限开刃',mode:'extreme'},
  alien:{name:'异形刃',mode:'alien'},fork:{name:'分叉刃',mode:'fork'},ring:{name:'环形刃',mode:'ring'},
  unknown:{name:'未知刃',mode:'unknown'},
};

const BLADE_TYPES_3D = [
  {id:'knife_balisong', name:'蝴蝶刀', en:'BUTTERFLY', source:'knife_balisong.glb', family:'dagger'},
  {id:'knife_bayonet', name:'刺刀', en:'BAYONET', source:'knife_bayonet.glb', family:'straight'},
  {id:'knife_folding', name:'折叠刀', en:'FOLDING', source:'knife_folding.glb', family:'straight'},
  {id:'knife_gladius', name:'短剑', en:'GLADIUS', source:'knife_gladius.glb', family:'straight'},
  {id:'knife_karambit', name:'爪子刀', en:'KARAMBIT', source:'knife_karambit.glb', family:'curve'},
  {id:'knife_kris', name:'马来剑', en:'KRIS', source:'knife_kris.glb', family:'wave'},
  {id:'knife_machete', name:'开山刀', en:'MACHETE', source:'knife_machete.glb', family:'straight'},
  {id:'knife_saber', name:'弯刀', en:'SABER', source:'knife_saber.glb', family:'curve'},
  {id:'knife_skull', name:'骷髅匕首', en:'SKULL', source:'knife_skull.glb', family:'dagger'},
  {id:'knife_straight', name:'直刀', en:'STRAIGHT', source:'knife_straight.glb', family:'straight'},
  {id:'knife_survival', name:'求生匕首', en:'SURVIVAL', source:'knife_survival.glb', family:'dagger'},
  {id:'knife_tangdao', name:'唐刀', en:'TANGDAO', source:'knife_tangdao.glb', family:'straight'},
];
const BLADE3D_MAP = Object.fromEntries(BLADE_TYPES_3D.map(x=>[x.id,x]));

const FORGE_TEX_HINTS = [
  {tags:['折叠'], ids:['T07','T08','T09']},
  {tags:['手工'], ids:['T03','T05','T10']},
  {tags:['重锤'], ids:['T06','T11']},
  {tags:['精密'], ids:['T04','T12']},
  {tags:['热锻'], ids:['T02','T06']},
  {tags:['古法'], ids:['T08','T09']},
  {tags:['星尘'], ids:['T10','T12']},
];
const QUENCH_FINISH_MAP = {
  water:'F03', oil:'F05', brine:'F07', ice:'F09', hotoil:'F08', martemper:'F04', diff:'F10',
  stardust:'F12', extreme:'F11', default:'F02'
};
const HANDLE_TO_SKIN = {
  ebony:'wood',walnut:'wood',bamboo:'bamboo',leather:'leather',rope:'leather',bone:'ceramic',jade:'jade',
  brass:'machined',aluminum:'machined',titanium:'machined',carbon:'carbon',mech:'machined',unknown_h:'jade',ergo:'polymer',inlay:'wood'
};

const MATERIAL_SKIN_HINT = {
  iron:'M02',steel:'M01',darksteel:'M06',copper:'M13',gold:'M14',silver:'M03',rust:'M07',obsidian:'M06',
  meteor:'M22',crystalR:'M18',crystalB:'M15',jade:'M17',damascus:'M19',wootz:'M20',tamahagane:'M01',unknown:'M24'
};

function materialToSkinMaterialId(m){return MATERIAL_SKIN_HINT[m?.palette] || 'M01';}
function pickTextureForCards(cards){
  const tags = new Set(cards.flatMap(c=>c.tags||[]));
  for (const h of FORGE_TEX_HINTS) if (h.tags.some(t=>tags.has(t))) return h.ids[Math.floor(Math.random()*h.ids.length)];
  return 'T04';
}

const FORGE_TRAIT_DEFS = [
  {id:'forge_thousand_strikes',name:'千锤',rarity:'rare',trigger:'forge_route',stage:'forge',effect:{type:'forge_route',tag:'锻打',stat:'strength',gain:0.055,threshold:2,penalty:'toughness',penaltyGain:0.025},description:'锻打路线累计越深，Strength 收益越高；贪多会牺牲部分韧性。'},
  {id:'forge_quench_window',name:'淬火窗口',rarity:'rare',trigger:'quench_perfect',stage:'quench',effect:{type:'quench_perfect',stats:{toughness:7,edge:5},risk:-5},description:'完美控温会额外淬出韧性与锋利，并降低风险。'},
  {id:'forge_folded_vein',name:'折纹',rarity:'rare',trigger:'fold_route',stage:'fold',effect:{type:'tag_streak',tag:'折叠',stats:{craft:3,design:2},threshold:2},description:'持续选择折叠路线会让纹理与完成度逐步增强。'},
  {id:'forge_overheat',name:'过热钢',rarity:'epic',trigger:'high_heat',stage:'melt',effect:{type:'risk_gain',tags:['高温'],strength:8,risk:4},description:'高温路线强化后续锻打爆发，但会把风险一起烧高。'},
  {id:'forge_master_hand',name:'匠人之手',rarity:'epic',trigger:'minigame_mastery',stage:'tune',effect:{type:'quality_chain',bonus:6},description:'关键小游戏表现越稳定，最终 Craft 越高。'},
  {id:'forge_broken_edge',name:'破而后立',rarity:'legendary',trigger:'survive_failure',stage:'any',effect:{type:'after_failure',stats:{edge:9},riskCap:-3},description:'曾在高风险中失手却继续完成锻造，锋利会出现额外回升。'},
  {id:'forge_clean_forge',name:'净锻',rarity:'rare',trigger:'high_purity',stage:'melt',effect:{type:'purity',stats:{craft:4}},description:'高纯度材料在后续加工中保持更稳定的表面完成度。'},
  {id:'forge_precise_edge',name:'精密刃口',rarity:'rare',trigger:'clean_edge',stage:'edge',effect:{type:'edge',stats:{sharpness:5,craft:2}},description:'高刃口完整度且磨损较低，形成清晰稳定的刃线。'},
  {id:'forge_heat_control',name:'热处理掌控',rarity:'epic',trigger:'heat_control',stage:'temper',effect:{type:'temper',stats:{toughness:4,craft:3}},description:'回火状态稳定且敢于承受较高风险，热处理层次更加完整。'},
];
const MATCH_TRAITS = [
  {id:'overdrive',name:'超载',rarity:'rare',effect:{POWER:1.15,CONTROL:0.95},description:'POWER +15%，CONTROL -5%。'},
  {id:'steady_hand',name:'稳手',rarity:'common',effect:{CONTROL:1.15},description:'CONTROL +15%。'},
  {id:'showtime',name:'登场时刻',rarity:'common',effect:{ART:1.15},description:'ART +15%。'},
  {id:'last_stand',name:'背水一战',rarity:'epic',effect:{round3:1.25,early:0.95},description:'第三回合 +25%，前两回合略有削弱。'},
  {id:'risk_taker',name:'赌徒',rarity:'rare',effect:{riskPower:0.003},description:'当前 Risk 越高，POWER 额外收益越高。'},
];

const SCHOOL_MODES = [
 {id:'ironclad',name:'IRONCLAD',cn:'钢铁流派',desc:'Strength / Toughness 优势，偏 POWER / CONTROL',focus:['POWER','CONTROL']},
 {id:'frostedge',name:'FROSTEDGE',cn:'霜刃流派',desc:'Sharpness / Quench 路线，偏 POWER',focus:['POWER']},
 {id:'damascus',name:'DAMASCUS',cn:'大马士革',desc:'折叠 / 纹理 / 工艺，偏 CONTROL / ART',focus:['CONTROL','ART']},
 {id:'precision',name:'PRECISION',cn:'精密流派',desc:'Craft / 完成度，偏 CONTROL',focus:['CONTROL']},
 {id:'edgefall',name:'EDGEFALL',cn:'坠锋流派',desc:'高风险 / 高爆发，偏 POWER',focus:['POWER']},
 {id:'starforged',name:'STARFORGED',cn:'星铸流派',desc:'Spirit / 特殊效果，偏 ART',focus:['ART']},
];
const GLOBAL_RULES = [
 {id:'power_up',name:'POWER 权重上升',metric:'POWER',factor:1.18},
 {id:'control_up',name:'CONTROL 权重上升',metric:'CONTROL',factor:1.18},
 {id:'art_up',name:'ART 权重上升',metric:'ART',factor:1.18},
 {id:'power_down',name:'POWER 收益下降',metric:'POWER',factor:0.86},
 {id:'random_order',name:'随机判定顺序',metric:'RANDOM',factor:1},
 {id:'trait_pressure',name:'特性压制',metric:'TRAIT',factor:0.92},
];

window.FORGE_DATA={STAT_KEYS,STAT_CN,BASE_STATS,RARITY,RARITY_ORDER,QUALITY,TIERS,TESTS,REFRESH_COSTS,MATERIALS,TRAITS,TRAIT_MAP,COMBOS,CARDS,BLADE_TYPES_3D,BLADE3D_MAP,HANDLES,QUENCH_MEDIA,EDGE_STYLES,FORGE_TRAIT_DEFS,MATCH_TRAITS,SCHOOL_MODES,GLOBAL_RULES,MATERIAL_SKIN_HINT,QUENCH_FINISH_MAP,materialToSkinMaterialId};
