/**
 * 《锻刀大赛 BladeSkin》P0 —— 12 种刀身纹理（技术方案 §5 / §6 / §7）
 *
 * 纹理层只回答一件事：**刀身表面有什么图案和微观结构**（不决定基础金属是谁）。
 *
 * 三条硬规则（文档 §6）：
 *   ① 每种纹理必须**可随机化**：seed + scale + rotation + offset + warp 缺一不可
 *      —— 禁止「T09 = 一张固定的烟雾图」
 *   ② 相同 seed 永远生成同样花纹；不同 seed 同一个 T09 也要明显不同
 *   ③ 每种纹理要同时给出 pattern / roughness / height(normal) 三个通道
 *
 * 资源策略（按用户决定）：
 *   **程序化为主 + 可替换本地 WebP**。默认全部由 shader 生成；
 *   若 assets/blade-skins/textures/<id>/ 下存在对应 webp，则作为**基础纹理**叠加/替换，
 *   WebP 只承担基础底纹，随机花纹 / 雾状 / 多普勒色彩变化仍由 shader 程序化生成。
 *   所有资源本地打包，完全离线，不使用 CDN。
 */
'use strict';

(function attach(K3D) {
  /** 每种纹理可有的资源槽（文档 §7 的标准目录） */
  const ASSET_SLOTS = ['pattern', 'roughness', 'normal', 'flow', 'mask'];
  const ASSET_BASE = 'assets/blade-skins/textures/';

  /**
   * 参数表说明：
   *   defaults  该纹理的默认参数值（UI 滑块初值）
   *   schema    UI 参数定义 [key, label, min, max, step]
   *   channels  该纹理实际输出的通道（pattern/roughness/height 必有）
   *   procedural 是否默认用 shader 程序化生成（true = 无资源也能出效果）
   */
  const TEXTURES = [
    {
      id: 'T01', name: '素面', nameEn: 'Plain', group: '基础',
      desc: '纯净基础表面：纯色金属、高级简约、测材质用',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0, contrast: 0.15, roughnessStrength: 0.25 },
      schema: [['contrast', '对比', 0, 1, 0.01], ['roughnessStrength', '粗糙调制', 0, 1, 0.01]],
      channels: ['pattern', 'roughness', 'height'], procedural: true,
    },
    {
      id: 'T02', name: '拉丝', nameEn: 'Brushed', group: '基础',
      desc: '纵向/横向/环向细密拉丝，方向性高光的来源',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0.05,
        density: 180, direction: 0, anisotropy: 0.7, contrast: 0.5, roughnessStrength: 0.55 },
      schema: [['density', '密度', 20, 600, 1], ['direction', '方向(度)', 0, 180, 1],
        ['anisotropy', '各向异性', 0, 1, 0.01], ['contrast', '对比', 0, 1, 0.01]],
      channels: ['pattern', 'roughness', 'height'], procedural: true,
    },
    {
      id: 'T03', name: '锻打纹', nameEn: 'Forged', group: '锻造',
      desc: '不规则锻打面：低频噪声 + 中频噪声 + 法线 + 粗糙度变化',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0.35,
        lowFreq: 0.35, midFreq: 0.55, hammerDensity: 14, contrast: 0.6, roughnessStrength: 0.6 },
      schema: [['hammerDensity', '锤点密度', 4, 40, 0.5], ['lowFreq', '低频', 0, 1, 0.01],
        ['midFreq', '中频', 0, 1, 0.01], ['roughnessStrength', '粗糙调制', 0, 1, 0.01]],
      channels: ['pattern', 'roughness', 'height'], procedural: true,
    },
    {
      id: 'T04', name: '大马士革', nameEn: 'Damascus', group: '锻造',
      desc: '★ 核心纹理：多层 fbm 流纹 + domain warp，模拟真实大马士革钢的暗/亮层交错',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0.55,
        contrast: 0.7, roughnessStrength: 0.5 },
      schema: [['warp', '扭曲强度', 0, 1.2, 0.01], ['contrast', '对比', 0, 1, 0.01],
        ['roughnessStrength', '粗糙调制', 0, 1, 0.01]],
      channels: ['pattern', 'roughness', 'height', 'flow'], procedural: true,
    },
    {
      id: 'T05', name: '水波纹', nameEn: 'Ripple', group: '锻造',
      desc: '连续柔和波纹，适合折叠钢 / 流线型刀 / 高级金属',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0.25,
        frequency: 10, amplitude: 0.55, contrast: 0.55, roughnessStrength: 0.45 },
      schema: [['frequency', '频率', 2, 30, 0.1], ['amplitude', '幅度', 0, 1, 0.01],
        ['contrast', '对比', 0, 1, 0.01]],
      channels: ['pattern', 'roughness', 'height'], procedural: true,
    },
    {
      id: 'T06', name: '大理石纹', nameEn: 'Marble', group: '自然',
      desc: 'Voronoi + Noise + Domain Warp（不要做成固定几根线）',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0.5,
        cellScale: 3.2, veinWidth: 0.12, contrast: 0.72, roughnessStrength: 0.4 },
      schema: [['cellScale', '晶格尺度', 0.5, 12, 0.1], ['veinWidth', '纹路宽度', 0.01, 0.4, 0.01],
        ['contrast', '对比', 0, 1, 0.01], ['warp', '扭曲', 0, 1.2, 0.01]],
      channels: ['pattern', 'roughness', 'height'], procedural: true,
    },
    {
      id: 'T07', name: '几何纹', nameEn: 'Geometric', group: '工业',
      desc: '六边形 / 三角 / 菱形 / 工业网格，由 seed 随机 rotation/scale/offset/phase',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0.05,
        tile: 1, gridScale: 10, grooveWidth: 0.12, contrast: 0.65, roughnessStrength: 0.55 },
      schema: [['tile', '图案(0六边/1三角/2菱/3网格)', 0, 3, 1], ['gridScale', '网格密度', 2, 40, 0.5],
        ['grooveWidth', '沟槽宽度', 0.02, 0.4, 0.01]],
      channels: ['pattern', 'roughness', 'height'], procedural: true,
    },
    {
      id: 'T08', name: '火焰纹', nameEn: 'Flame', group: '自然',
      desc: '模拟火焰/熔流：Directional Noise + Warp + Gradient',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0.6,
        flowDir: 0.25, stretch: 2.5, contrast: 0.72, roughnessStrength: 0.5 },
      schema: [['flowDir', '流向', 0, 1, 0.01], ['stretch', '拉长', 0.5, 6, 0.1],
        ['contrast', '对比', 0, 1, 0.01], ['warp', '扭曲', 0, 1.2, 0.01]],
      channels: ['pattern', 'roughness', 'height'], procedural: true,
    },
    {
      id: 'T09', name: '雾状流体', nameEn: 'Doppler Mist', group: '幻彩', star: true,
      desc: '★★ 多普勒的形状来源：大块雾团 + 柔和边界 + 多尺度噪声 + 不规则流向（由 seed 随机）',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0.55,
        mistLarge: 0.75, mistSmall: 0.35, softness: 0.50, contrast: 0.65, roughnessStrength: 0.35 },
      schema: [['mistLarge', '大雾团', 0, 1, 0.01], ['mistSmall', '小雾团', 0, 1, 0.01],
        ['softness', '边缘柔化', 0, 1, 0.01], ['warp', '扭曲', 0, 1.2, 0.01], ['contrast', '对比', 0, 1, 0.01]],
      channels: ['pattern', 'roughness', 'height', 'mask'], procedural: true,
    },
    {
      id: 'T10', name: '彩色云纹', nameEn: 'Iridescent Cloud', group: '幻彩',
      desc: '比 T09 更明显的云状彩纹：彩虹云 / 油膜 / 幻彩钢',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0.6,
        cloudScale: 2.0, colorSpread: 0.75, softness: 0.45, contrast: 0.65 },
      schema: [['cloudScale', '云尺度', 0.5, 6, 0.05], ['colorSpread', '色彩跨度', 0, 1, 0.01],
        ['softness', '边缘柔化', 0, 1, 0.01]],
      channels: ['pattern', 'roughness', 'height', 'mask'], procedural: true,
    },
    {
      id: 'T11', name: '蚀刻纹', nameEn: 'Etched', group: '工业',
      desc: '激光/化学蚀刻、微刻线：主要走 normal + roughness + height',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0.1,
        lineDensity: 60, lineWidth: 0.06, depth: 0.65, roughnessStrength: 0.75 },
      schema: [['lineDensity', '刻线密度', 10, 200, 1], ['lineWidth', '线宽', 0.01, 0.3, 0.005],
        ['depth', '深度', 0, 1, 0.01]],
      channels: ['pattern', 'roughness', 'height'], procedural: true,
    },
    {
      id: 'T12', name: '碎片纹', nameEn: 'Shard', group: '工业',
      desc: '随机块状区域：淬火残色 / 特殊钢 / Case Hardened 风格 / 矿石感',
      defaults: { scale: 1.0, rotation: 0, offsetX: 0, offsetY: 0, warp: 0.3,
        shardScale: 5, shardContrast: 0.78, plateThickness: 0.25, roughnessStrength: 0.6 },
      schema: [['shardScale', '碎块密度', 1, 20, 0.5], ['shardContrast', '碎块对比', 0, 1, 0.01],
        ['plateThickness', '块面厚度', 0, 1, 0.01]],
      channels: ['pattern', 'roughness', 'height'], procedural: true,
    },
  ];

  /** 纹理全局默认（文档 §6 的随机化参数，所有纹理共有） */
  const TEXTURE_COMMON = Object.freeze({
    seed: 381729,
    scale: 1.0,
    rotation: 0,
    offset: { x: 0, y: 0 },
    warpStrength: 0.4,
    contrast: 0.5,
    strength: 1.0,
  });

  // ⚠ 先建 LIST，再由 LIST 建索引：get() 必须返回**同一个对象**，
  //   否则 list().indexOf(get(id)) 会落空（曾导致 uTexId=0 → 纹理全走 T01）
  const LIST = TEXTURES.map((t) => Object.freeze({ ...t, defaults: Object.freeze({ ...t.defaults }) }));
  const INDEX = new Map(LIST.map((t) => [t.id, t]));

  K3D.textures12 = {
    TEXTURES: LIST,
    TEXTURE_COMMON,
    ASSET_SLOTS,
    ASSET_BASE,
    /** 该纹理的本地资源目录（可替换 WebP 放这里；不存在则纯程序化） */
    assetDir: (id) => ASSET_BASE + id + '/',
    list: () => LIST.slice(),
    get(id) { return INDEX.get(id) || LIST[0]; },
    /** 1-based 序号（shader 里用 int 分支识别纹理） */
    indexOf(id) { return LIST.findIndex((t) => t.id === id) + 1; },
    byGroup: (g) => LIST.filter((t) => t.group === g),
  };
}(window.K3D = window.K3D || {}));
