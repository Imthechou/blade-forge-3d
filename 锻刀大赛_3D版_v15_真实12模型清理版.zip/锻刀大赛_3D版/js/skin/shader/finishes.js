/**
 * 《锻刀大赛 BladeSkin》P1 —— 12 种工艺特效的 GLSL（文档 §8 / §9 / §10）
 *
 * 统一入口：
 *     k3dApplyFinish( finId, local, tAxis, pat(纹理输出), 参数包…, fresnel,
 *                     inout color, inout rough, inout metal, inout glow )
 *   color  刀身基色（进来是「材质色 × 纹理」，出去是「工艺处理后的颜色」）
 *   rough  粗糙度（0~1）
 *   metal  金属度（0~1）
 *   glow   自发光/边缘光累加项（在 mapFragment 末尾按需叠加）
 *
 * 三条硬约束：
 *   ① 工艺**不能改变基础金属"是谁"**（文档 §2.3）：F04/F11 这类可以改 roughness/baseColor，
 *      但不能把金属改成非金属（metal 最多轻微下调）
 *   ② 多普勒按文档 §9.5 合成：
 *        mixed = mix( base, dopplerColor, mask * strength )      ← 天然保留原材质
 *        mixed += dopplerColor * fresnel * fresnelIntensity      ← 视角相关虹彩
 *      并且 preserveRatio / strength 由 CPU 侧按 §9.10 随 wear 衰减后传入
 *   ③ 完全确定性：只用 seed 驱动的空间噪声，不用时间（F12 的"流动"也是空间流动，
 *      保证同 state 截图逐像素一致；需要真动画再另开 uniform）
 */
'use strict';

(function attach(K3D) {
  const funcs = `
// ── F01 精抛光：降低 roughness、增强反射（不改色相）
// ── F02 镜面抛光：roughness 压到很低
// ── F03 拉丝处理：按纹理的方向性调制 roughness（各向异性本体在 CPU 侧设置）
// ── F04 发黑氧化：压暗 + 抬粗糙
// ── F05 蓝化：蓝灰氧化层（沿花纹 Mask）
// ── F06 表面淬火：金→紫→蓝 热色带
// ── F07 回火彩：黄→紫→蓝（温度决定偏移）
// ── F08 阳极氧化：彩色 + 虹彩
// ── F09 PVD 镀层：高光洁度薄层 + 轻微色偏
// ── F10 彩色油膜 / 多普勒
// ── F11 喷砂磨砂：粗糙度提升
// ── F12 动态边缘光：Fresnel 边缘光 + 空间流动
void k3dApplyFinish(
  int finId,
  vec3 local, float tAxis, vec3 pat,
  vec4 f0, vec4 f1, vec4 f2, vec4 f3, vec3 fColor,
  vec3 pal0, vec3 pal1, vec3 pal2, vec3 pal3,
  vec4 dopMeta, vec4 seeds, float fresnel,
  inout vec3 color, inout float rough, inout float metal, inout float glow )
{
  float amount = f0.x;
  float pattern = pat.x;
  float height = pat.z;

  if ( finId <= 1 ) {
    // F01 精抛光
    rough = mix( rough, rough * 0.32, amount );
    color = color * ( 1.0 + 0.06 * amount );
  } else if ( finId == 2 ) {
    // F02 镜面抛光
    rough = mix( rough, 0.045, amount );
    color = color * ( 1.0 + 0.10 * amount );
  } else if ( finId == 3 ) {
    // F03 拉丝处理：沟槽更糙、丝面更光（方向来自纹理自身）
    float dir = pat.y;                                   // roughDelta 已带方向性
    rough = mix( rough, clamp( rough + dir * 0.35, 0.02, 1.0 ), amount );
  } else if ( finId == 4 ) {
    // F04 发黑氧化
    float dk = clamp( f0.y, 0.0, 1.0 );
    color = mix( color, color * ( 1.0 - 0.82 * dk ), amount );
    rough = mix( rough, clamp( rough + 0.28 * dk, 0.0, 1.0 ), amount );
  } else if ( finId == 5 ) {
    // F05 蓝化：蓝灰氧化层沿花纹铺（gradient 决定渐变跨度）
    vec3 tint = fColor;
    float g = clamp( pattern * ( 0.55 + f0.z ) + tAxis * 0.25, 0.0, 1.0 );
    vec3 oxidized = mix( color * 0.35, tint, g );
    color = mix( color, oxidized, amount * 0.9 );
    rough = mix( rough, clamp( rough + 0.16, 0.0, 1.0 ), amount );
  } else if ( finId == 6 ) {
    // F06 表面淬火 ★：金 → 紫 → 蓝 的明显热色带
    float spread = clamp( f0.w, 0.0, 1.0 );
    float phase = f1.x;
    float band = fract( pattern * spread + phase + tAxis * 0.35 + seeds.x * 0.13 );
    vec3 heat = k3dPalette4( vec3( 0.92, 0.72, 0.28 ), vec3( 0.72, 0.36, 0.16 ),
                             vec3( 0.42, 0.22, 0.62 ), vec3( 0.22, 0.42, 0.86 ), band );
    // 色带只落在花纹区内（块状淬火），未覆盖处保留原材质
    float cover = amount * mix( 0.55, 1.0, smoothstep( 0.25, 0.75, pattern ) );
    color = mix( color, heat, cover );
    rough = mix( rough, clamp( rough + 0.10, 0.0, 1.0 ), cover );
  } else if ( finId == 7 ) {
    // F07 回火彩：黄 → 紫 → 蓝（temperature 越低越黄）
    float temp = clamp( f1.y, 0.0, 1.0 );
    float tt = clamp( temp * 0.6 + pattern * 0.4 + tAxis * 0.2, 0.0, 1.0 );
    vec3 temper = k3dPalette4( vec3( 0.95, 0.84, 0.42 ), vec3( 0.86, 0.56, 0.22 ),
                               vec3( 0.52, 0.28, 0.66 ), vec3( 0.26, 0.44, 0.88 ), tt );
    color = mix( color, temper, amount * 0.85 );
  } else if ( finId == 8 ) {
    // F08 阳极氧化 ★：彩色氧化层 + 虹彩（颜色由材质色相偏移得到）
    float hueShiftAmt = f1.z;
    vec3 tinted = k3dHueShift( color, hueShiftAmt + 0.05 * sin( pattern * 6.2831853 ) );
    tinted = k3dSatVal( tinted, 1.0 + 0.35 * amount, 1.0 + 0.08 * amount );
    float cover = amount * mix( 0.6, 1.0, pattern );
    color = mix( color, tinted, cover );
    rough = mix( rough, rough * 0.7, amount );
  } else if ( finId == 9 ) {
    // F09 PVD 镀层：薄层色偏 + 更光洁（不盖掉金属反射）
    vec3 coatTint = mix( color, fColor, 0.55 );
    float cover = amount * mix( 0.35, 0.75, pattern );
    color = mix( color, coatTint, cover );
    rough = mix( rough, rough * ( 1.0 - 0.45 * clamp( f1.w, 0.0, 1.0 ) ), amount );
  } else if ( finId == 10 ) {
    // F10 彩色油膜 / 多普勒 ★★（文档 §9.5）
    float strength = clamp( f2.x, 0.0, 1.0 );            // 已按 wear 衰减
    float preserve = clamp( f2.y, 0.0, 1.0 );            // 原材质保留
    float fresPow = max( 0.2, f2.z );
    float fresInt = f2.w;
    float colorPhase = f3.x + dopMeta.w;                 // 材质锚点色相 + 用户相位
    // ① 形状：T09/T10 的雾团就是 mask；其它纹理则用花纹强度当 mask
    float mask = clamp( mix( pattern, height, 0.35 ), 0.0, 1.0 );
    // ② 颜色：沿调色板取色（雾团 + 相位 + 视角共同推动）
    float ramp = clamp( mask * 1.15 + colorPhase + fresnel * 0.35, 0.0, 1.0 );
    vec3 dopColor = k3dPalette4( pal0, pal1, pal2, pal3, ramp );
    dopColor = k3dSatVal( dopColor, dopMeta.y, dopMeta.z );
    // ③ 合成：先保留一部分原材质，再叠多普勒（天然不会"覆盖掉材质"）
    vec3 kept = color * mix( 1.0, 1.0, preserve );
    color = mix( kept, dopColor, mask * strength );
    // ④ 视角相关虹彩（正面/斜看不同）
    float f = pow( clamp( fresnel, 0.0, 1.0 ), fresPow );
    color += dopColor * f * fresInt;
    // ⑤ 多普勒区更光洁一点（雾团处像油膜）
    rough = mix( rough, rough * 0.72, mask * strength );
  } else if ( finId == 11 ) {
    // F11 喷砂磨砂
    rough = mix( rough, clamp( rough + 0.55, 0.0, 1.0 ), amount );
    color = color * ( 1.0 - 0.05 * amount );
  } else {
    // F12 动态边缘光：Fresnel 边缘 + 空间流动，只在边缘出现
    float fresPow = max( 0.2, f2.z );
    float f = pow( clamp( fresnel, 0.0, 1.0 ), fresPow );
    float flowSpeed = max( 0.0, f3.y );
    float flow = k3dFbm2( vec2( local.x * 3.4 - local.y * 1.2, local.y * 2.6 ) + seeds.z * 9.0 );
    float gate = f * amount * ( 0.65 + 0.35 * flow ) * mix( 0.5, 1.0, flowSpeed + 0.5 );
    glow += length( fColor ) * gate * 0.9;
    color += fColor * gate * 0.35;
  }
}
`;

  K3D.shaderFinishes = { common: funcs };
}(window.K3D = window.K3D || {}));
