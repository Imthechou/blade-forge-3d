/**
 * 《锻刀大赛 BladeSkin》P1 —— 刀身皮肤着色注入（Material × Texture × Finish × Wear × Seed）
 *
 * 这一层是「数据决定结果，Viewer 只负责呈现」的最后一环：把 composeBladeSkin() 产出的
 * uniform 包挂到材质的 shader 上，**只作用于刀身区域（wB）**，护手/刀柄通道一概不碰。
 *
 * 注入点（都用 js/material.js 的 hook 管理器，多 hook 共存不互相覆盖）：
 *   common          着色器函数库（noise + patterns + finishes + 本文件）与 uniform 声明
 *   vertexCommon    varying 声明
 *   vertexBody      由 uBladeBasis/uBladeOrigin/uBladeSpan 算出刀身局部坐标 vBladeLocal
 *   mapFragment     刀身基色 = 材质色 × 纹理 → 工艺 → Wear
 *   roughnessFragment  法线/粗糙度：花纹调制 + 材质 roughnessVariation + Wear
 *   metalnessFragment  金属度（保持材质的金属身份，工艺只做轻微下调）
 *
 * ⚠ 与旧皮肤系统的关系：旧系统（skins.js/atlas 烘焙）负责护手与刀柄的观感，保持原样；
 *   本模块只接管**刀身**颜色，二者区域互斥（wB vs wG/wH），不会互相覆盖。
 */
'use strict';

(function attach(K3D) {
  const UNIFORM_DECLS = `
// ── BladeSkin uniforms ────────────────────────────────────────────
uniform sampler2D uSkinBaseMap;        // 模型自带基础色贴图（Wear 露底材用；独立于旧系统的 uBladeOrigMap）
uniform vec3  uBladeBaseColor;         // 材质基色（线性）
uniform float uBladeMetalness;
uniform float uBladeRoughness;
uniform float uBladeRoughVar;
uniform float uBladeSpecular;
uniform vec3  uBladeEmission;
uniform float uBladeEmissionInt;
uniform float uSkinTexStrength;        // 花纹强度（Texture.strength）

uniform int   uTexId;
uniform vec4  uTexParam0;              // scale, rotation(rad), offsetX, offsetY
uniform vec4  uTexParam1;              // warp, contrast, density, direction
uniform vec4  uTexParam2;              // flowScale, warpStrength, layerCount, roughnessStrength
uniform vec4  uTexParam3;              // mistLarge, mistSmall, softness, cellScale
uniform vec4  uTexParam4;              // gridScale, grooveWidth, lineDensity, lineWidth
uniform vec4  uTexParam5;              // shardScale, shardContrast, plateThickness, frequency
uniform vec4  uTexParam6;              // tile, flowDir, stretch, anisotropy

uniform int   uFinId;
uniform vec4  uFinParam0;              // amount, darkness, gradient, heatSpread
uniform vec4  uFinParam1;              // phase, temperature, hueShift, coat
uniform vec4  uFinParam2;              // dopplerStrength, preserveRatio, fresnelPower, fresnelIntensity
uniform vec4  uFinParam3;              // colorPhase, flowSpeed, iridescence, colorSpread
uniform vec3  uFinColor;

uniform vec3  uDopPal0;
uniform vec3  uDopPal1;
uniform vec3  uDopPal2;
uniform vec3  uDopPal3;
uniform vec4  uDopMeta;                // hueShift, satBoost, valBoost, anchorHue

uniform vec4  uSeeds;                  // patternSeed, warpSeed, colorPhaseSeed, fresnelSeed
uniform vec4  uWearLevels;             // edge, surface, pattern, scratch
uniform float uWearRough;
uniform float uWear01;                 // 总磨损 0~1

uniform mat3  uBladeBasis;             // 刀身局部基（列 = 长轴/次长轴/第三轴，物体空间）
uniform vec3  uBladeOrigin;
uniform vec3  uBladeSpan;

varying vec3 vBladeLocal;              // (t 沿长轴 0~1, 横向, 厚度)
// 注：fresnel（F10 彩色油膜 / F12 边缘光用）不能在这里写成函数——
//     three 的 vNormal 是在 <common> 之后（normal_pars_fragment）才声明的，
//     本段注入在 <common> 之后紧接着的位置，函数体引用 vNormal 会编译失败。
//     所以 fresnel 在 mapFragment 注入块里就地计算。
`;

  const VERTEX_COMMON = `
varying vec3 vBladeLocal;
uniform mat3 uBladeBasis;
uniform vec3 uBladeOrigin;
uniform vec3 uBladeSpan;
// ⚠ aBladeT / aRegion / aEdge 的声明统一在 material.js 的 'bladeAttrs' hook
//   （engine.applyBladeSkin 会先调 setBladeAttrs）。这里**绝不能再写
//   attribute 声明**：两个 hook 各声明一份 → "aBladeT: redefinition" 编译失败
//   （本模块早期版本踩过：bladeMask hook 缺席时 undeclared，两者都在时 redefinition）。
`;

  const VERTEX_BODY = `
{
  vec3 k3dLocalRaw = uBladeBasis * ( position - uBladeOrigin );
  // x 直接用 aBladeT（与 regions.js 的 bladeStart 同一个 t，保证图案与区域边界一致）
  vBladeLocal = vec3( aBladeT,
                      k3dLocalRaw.y / max( uBladeSpan.y, 1.0e-5 ),
                      k3dLocalRaw.z / max( uBladeSpan.z, 1.0e-5 ) );
}
`;

  /** 刀身颜色：材质 × 纹理 → 工艺 → Wear（只写 wB 区域） */
  const MAP_FRAGMENT = `
{
  float wB, wG, wH; k3dRegionW( wB, wG, wH );
  if ( wB > 0.002 ) {
    vec3 L = vBladeLocal;
    // ① 纹理层
    vec3 pat = k3dPattern( uTexId, L, uTexParam0, uTexParam1, uTexParam2,
                           uTexParam3, uTexParam4, uTexParam5, uTexParam6, uSeeds );
    float p = clamp( pat.x, 0.0, 1.0 );
    // ② 材质层：基色 + 花纹明暗调制（花纹只调制，不决定基色是谁）
    vec3 base = uBladeBaseColor;
    float shade = mix( 0.62, 1.32, p );
    vec3 col = base * mix( 1.0, shade, clamp( uSkinTexStrength, 0.0, 2.0 ) );
    // ③ 工艺层（fresnel 就地算：此处已在 normal_pars_fragment 之后，vNormal 可见）
    float k3dFres = 0.35;
    #ifndef FLAT_SHADED
      k3dFres = pow( 1.0 - clamp( dot( normalize( vNormal ), normalize( vViewPosition ) ), 0.0, 1.0 ), 1.0 );
    #endif
    float rough = uBladeRoughness;
    float metal = uBladeMetalness;
    float glow = 0.0;
    k3dApplyFinish( uFinId, L, vBladeT, pat,
                    uFinParam0, uFinParam1, uFinParam2, uFinParam3, uFinColor,
                    uDopPal0, uDopPal1, uDopPal2, uDopPal3, uDopMeta, uSeeds,
                    k3dFres, col, rough, metal, glow );
    // ④ 粗糙度：花纹调制（纹理的 roughnessStrength）+ 材质自带的 roughnessVariation
    rough = clamp( rough + pat.y * 0.55 * uTexParam2.w + uBladeRoughVar * ( p - 0.5 ) * 2.0, 0.02, 1.0 );
    // ⑤ Wear（文档 §12）：边缘先磨、表面失去花纹、粗糙度上升、划痕、露底材
    vec3 baseTex = diffuse * texture2D( uSkinBaseMap, vMapUv ).rgb;
    float hl = dot( baseTex, vec3( 0.2126, 0.7152, 0.0722 ) );
    vec3 substrate = baseTex * clamp( 0.55 / max( hl, 0.05 ), 1.0, 2.0 );   // 露出的底材（提亮到可见）
    float edge = clamp( vEdge, 0.0, 1.0 );
    // 边缘权重做锐化：只有真正凸起的棱才算"边缘"，避免整刀都被当成边缘磨
    float edgeGate = smoothstep( 0.55, 0.95, edge );
    float eW = uWearLevels.x * mix( 0.10, 1.0, edgeGate );
    float sW = uWearLevels.y;
    float pW = uWearLevels.z;
    float cW = uWearLevels.w;                       // scratchWear
    // a) 花纹衰减：花纹越磨越淡，颜色向"纯材质色"回归（§9.10 patternContrast ↓）
    col = mix( col, base * 1.06, pW * 0.80 );
    // b) 表面磨损：向底材靠 + 整体压暗压哑（磨损的金属本来就发暗，只做去饱和看不出来）
    col = mix( col, substrate, sW * 0.55 );
    col *= mix( 1.0, 0.60, sW * 0.85 );
    // c) 划痕：沿刀身方向的细密划纹，高磨损时明显（§12 scratchWear）
    float scratch = k3dFbm2( vec2( vBladeLocal.x * 5.0, vBladeLocal.y * 190.0 ) + uSeeds.w * 17.0 );
    scratch = smoothstep( 0.62, 0.92, scratch ) * cW;
    col = mix( col, col * ( 1.25 + 0.5 * scratch ), scratch * 0.85 );
    rough = clamp( rough + scratch * 0.35, 0.02, 1.0 );
    // d) 边缘磨损：明显金属裸露（露底材 + 更亮）
    col = mix( col, substrate * ( 1.05 + 0.35 * edgeGate ), eW * 0.85 );
    rough = clamp( rough + uWearRough * 0.50 * ( 0.35 + 0.65 * edgeGate ), 0.02, 1.0 );
    // e) 磨损同时让多普勒/虹彩整体减弱（§9.10 已在 CPU 侧衰减，这里再压一层感知）
    col = mix( col, vec3( dot( col, vec3( 0.2126, 0.7152, 0.0722 ) ) ), uWear01 * 0.18 );
    // ⑥ 自发光：F12 边缘光 + 材质自带微弱发光（星尘/月蚀）
    col += vec3( glow ) + uBladeEmission * uBladeEmissionInt;
    // ⑦ 提亮整体刀身颜色（补偿环境光不足）
    col = col * 1.30;
    // ⑧ 写回（只作用刀身权重）
    diffuseColor.rgb = mix( diffuseColor.rgb, col, wB );
  }
}
`;

  /** 刀身粗糙度：材质 base roughness + 花纹 + Wear（护手/刀柄仍由旧 hook 控制） */
  const ROUGHNESS_FRAGMENT = `
{
  float wB, wG, wH; k3dRegionW( wB, wG, wH );
  if ( wB > 0.002 ) {
    vec3 pat = k3dPattern( uTexId, vBladeLocal, uTexParam0, uTexParam1, uTexParam2,
                           uTexParam3, uTexParam4, uTexParam5, uTexParam6, uSeeds );
    float bladeRough = clamp( uBladeRoughness
                              + pat.y * 0.55 * uTexParam2.w
                              + uBladeRoughVar * ( pat.x - 0.5 ) * 2.0
                              + uWearRough * 0.45, 0.02, 1.0 );
    roughnessFactor = mix( roughnessFactor, bladeRough, wB );
  }
}
`;

  /** 刀身金属度：保持材质身份（工艺只做轻微下调），不再让旧系统的中间值污染刀身 */
  const METALNESS_FRAGMENT = `
{
  float wB, wG, wH; k3dRegionW( wB, wG, wH );
  if ( wB > 0.002 ) {
    float metal = clamp( uBladeMetalness + uBladeRoughVar * 0.05, 0.0, 1.0 );
    metalnessFactor = mix( metalnessFactor, metal, wB );
  }
}
`;

  /** 组装 hook（signature 变化才重编译，否则只刷 uniform 值） */
  function buildHook(pack, frame, opts = {}) {
    const u = pack.uniforms;
    const colorOf = (spec, fb) => (K3D.material.colorFromSpec ? K3D.material.colorFromSpec(spec, fb)
      : new THREE.Color(fb || '#ffffff'));
    const V3 = (a) => new THREE.Vector3(a[0], a[1], a[2]);
    const V4 = (a) => new THREE.Vector4(a[0], a[1], a[2], a[3]);
    const uniforms = {
      uSkinBaseMap: { value: opts.baseMap || null },
      uBladeBaseColor: { value: colorOf(u.uBladeBaseColor, '#9aa2ac') },
      uBladeMetalness: { value: u.uBladeMetalness },
      uBladeRoughness: { value: u.uBladeRoughness },
      uBladeRoughVar: { value: u.uBladeRoughVar },
      uBladeSpecular: { value: u.uBladeSpecular },
      uBladeEmission: { value: colorOf(u.uBladeEmission, '#000000') },
      uBladeEmissionInt: { value: u.uBladeEmissionInt },
      uSkinTexStrength: { value: opts.texStrength != null ? opts.texStrength : 1.0 },
      uTexId: { value: u.uTexId },
      uTexParam0: { value: V4(u.uTexParam0) },
      uTexParam1: { value: V4(u.uTexParam1) },
      uTexParam2: { value: V4(u.uTexParam2) },
      uTexParam3: { value: V4(u.uTexParam3) },
      uTexParam4: { value: V4(u.uTexParam4) },
      uTexParam5: { value: V4(u.uTexParam5) },
      uTexParam6: { value: V4(u.uTexParam6) },
      uFinId: { value: u.uFinId },
      uFinParam0: { value: V4(u.uFinParam0) },
      uFinParam1: { value: V4(u.uFinParam1) },
      uFinParam2: { value: V4(u.uFinParam2) },
      uFinParam3: { value: V4(u.uFinParam3) },
      uFinColor: { value: colorOf(u.uFinColor, '#ffffff') },
      uDopPal0: { value: V3(u.uDopPal0) },
      uDopPal1: { value: V3(u.uDopPal1) },
      uDopPal2: { value: V3(u.uDopPal2) },
      uDopPal3: { value: V3(u.uDopPal3) },
      uDopMeta: { value: V4(u.uDopMeta) },
      uSeeds: { value: V4(u.uSeeds) },
      uWearLevels: { value: V4(u.uWearLevels) },
      uWearRough: { value: u.uWearRough },
      uWear01: { value: u.uWear01 },
      uBladeBasis: { value: frame ? frame.basis : new THREE.Matrix3() },
      uBladeOrigin: { value: frame ? frame.origin : new THREE.Vector3() },
      uBladeSpan: { value: frame ? frame.span : new THREE.Vector3(1, 1, 1) },
    };
    return {
      // signature：只包含**影响 shader 结构**的东西（纹理/工艺 id + 是否有多普勒）
      signature: 'bladeSkin:' + u.uTexId + ':' + u.uFinId,
      uniforms,
      common: UNIFORM_DECLS + K3D.shaderNoise.common + K3D.shaderPatterns.common + K3D.shaderFinishes.common,
      vertexCommon: VERTEX_COMMON,
      vertexBody: VERTEX_BODY,
      mapFragment: MAP_FRAGMENT,
      roughnessFragment: ROUGHNESS_FRAGMENT,
      metalnessFragment: METALNESS_FRAGMENT,
    };
  }

  /** 挂到材质上（同 signature 时只更新 uniform 值，不触发重编译） */
  function apply(material, pack, frame, opts) {
    const spec = buildHook(pack, frame, opts);
    K3D.material.upsertHook(material, 'bladeSkin', spec);
    return spec;
  }

  function detach(material) {
    K3D.material.removeHook(material, 'bladeSkin');
  }

  K3D.bladeSkinShader = { buildHook, apply, detach, UNIFORM_DECLS };
}(window.K3D = window.K3D || {}));
