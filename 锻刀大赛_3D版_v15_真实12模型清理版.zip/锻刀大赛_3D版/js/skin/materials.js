/**
 * 《锻刀大赛 BladeSkin》P0 —— 24 种刀身材质（技术方案 §3 / §4）
 *
 * 材质层只回答一件事：**刀身本身是什么材料**（BaseColor / Metalness / Roughness /
 * Clearcoat / Iridescence / Transmission …），**不负责花纹**（花纹是纹理层 T01~T12 的事）。
 *
 * 参数范围依据文档 §3 的分组建议：
 *   M01-M08 钢铁基础   metalness 0.92~1.00  roughness 0.12~0.42  specular 0.6~1.0
 *   M09-M14 彩色金属   baseColor 有色 + clearcoat + 轻微 iridescence（不要单色填充）
 *   M15-M18 宝石珠光   metalness 0.65~0.95  clearcoat 0.35~0.75  roughness 0.10~0.28
 *                      transmission 0.05~0.18（只做轻微通透，避免"玻璃刀"）IOR 1.35~1.55
 *   M19-M21 珠光/液态  metalness + clearcoat + fresnel + 轻微 iridescence
 *   M22-M24 特殊视觉   星空/月蚀/极光，做高级稀有材质
 *
 * ⚠ 每个材质还带一份 **DopplerMaterialProfile**（文档 §9.2/§9.3）：
 *    多普勒颜色必须从该材质的基础色派生，而不是给所有刀套同一套"蓝→紫→粉"。
 *    这里用 makeDopplerProfile(baseColor, style, overrides) 从 baseColor 的色相自动派生
 *    palette，个别材质再用 overrides 精调（例如黄金要"金→橙→紫→蓝"）。
 *
 * ⚠ 渲染落地取舍（为了"护手/刀柄零改动"这条硬要求）：
 *    本查看器只把**能被区域遮罩住**的材质属性交给 three 原生通道
 *    （metalness / roughness / clearcoat / iridescence）；
 *    而 transmission / ior / envIntensity / emissionColor 这几项是**材质级**的
 *    （会作用到整把刀，包括护手与刀柄），所以：
 *      · M15-M18 的"宝石通透感"改由 clearcoat + iridescence 表达（文档本身也要求
 *        "通透是清澈反射/彩釉感，不要做成玻璃刀"）
 *      · M22-M24 的微弱发光由刀身 shader 侧只对刀身叠加（emissionIntensity 仍在用）
 *      · envIntensity 暂未接入（保持护手/刀柄的环境反射与基线完全一致）
 *    数据字段保留完整，等哪天允许"整刀材质级变化"时可直接启用。
 */
'use strict';

(function attach(K3D) {
  /** 4 种多普勒 Style = 4 套**色彩生成规则**（文档 §9.6，不是 4 个固定皮肤）
   *
   * 每条风格由「锚点色相 anchor + 色相增量 deltas + 饱和/亮度」定义：
   *   - 灰系材质（饱和度 < 0.20，色相无意义）→ 直接用风格的**绝对色相**，得到经典配色
   *     （例如银灰钢 D02 = 蓝→紫→粉→蓝；若无此规则，灰色派生的色相是随机的）
   *   - 彩色材质（饱和度 ≥ 0.20）→ 把同一套 deltas **锚到该材质自己的色相**上，
   *     于是「同一个 T09 + F10，换材质就得到不同风格的多普勒」（文档 §9.2）
   */
  const DOPPLER_STYLES = {
    // D01 冷色多普勒：蓝 → 紫 → 品红 → 青（偏冷、科技）
    D01: {
      name: '冷色多普勒', anchor: 0.60,
      deltas: [0.00, 0.11, 0.19, -0.10],
      sats: [0.62, 0.74, 0.62, 0.55], vals: [0.44, 0.54, 0.46, 0.40],
    },
    // D02 经典幻彩：蓝 → 紫 → 粉 → 蓝（最接近经典多普勒观感）
    D02: {
      name: '经典幻彩', anchor: 0.62,
      deltas: [0.00, 0.13, 0.22, 0.00],
      sats: [0.64, 0.80, 0.72, 0.58], vals: [0.46, 0.58, 0.52, 0.42],
    },
    // D03 暖冷交替：金 → 橙 → 紫 → 蓝（适合金 / 铜色材质）
    D03: {
      name: '暖冷交替', anchor: 0.09,
      deltas: [0.00, -0.03, 0.66, 0.51],
      sats: [0.66, 0.82, 0.68, 0.56], vals: [0.58, 0.60, 0.46, 0.42],
    },
    // D04 极光多普勒：青 → 绿 → 蓝 → 紫（适合冰蓝钛 / 极光银）
    D04: {
      name: '极光多普勒', anchor: 0.50,
      deltas: [0.00, -0.06, 0.09, 0.24],
      sats: [0.56, 0.64, 0.68, 0.60], vals: [0.48, 0.54, 0.50, 0.44],
    },
  };

  // ── 颜色工具（只在本模块内部用，避免和 shader 侧混） ──────────────
  function hexToRgb(hex) {
    return [
      parseInt(hex.slice(1, 3), 16) / 255,
      parseInt(hex.slice(3, 5), 16) / 255,
      parseInt(hex.slice(5, 7), 16) / 255,
    ];
  }
  function rgbToHsv([r, g, b]) {
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d > 0) {
      if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
      h /= 6; if (h < 0) h += 1;
    }
    return [h, mx === 0 ? 0 : d / mx, mx];
  }
  function hsvToRgb(h, s, v) {
    h = ((h % 1) + 1) % 1;
    const i = Math.floor(h * 6), f = h * 6 - i;
    const p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
    return [[v, t, p], [q, v, p], [p, v, t], [p, q, v], [t, p, v], [v, p, q]][i % 6];
  }
  const r3 = (a) => a.map((x) => Math.round(x * 1000) / 1000);

  /**
   * 从材质基础色派生多普勒 profile（文档 §9.2「多普勒颜色应该从原材质派生」）。
   *   - 灰系材质（s < GREY_S）：色相不可信 → 用风格的绝对色相（经典配色）
   *   - 彩色材质：色相 = 材质色相 + 风格 deltas（同风格换材质 → 不同基调）
   * @param {string} baseHex 材质基础色（如 '#8b5cf6'）
   * @param {string} style   D01~D04
   * @param {object} ov      精调项（覆盖派生结果）
   */
  const GREY_S = 0.20;
  function makeDopplerProfile(baseHex, style, ov = {}) {
    const st = DOPPLER_STYLES[style] || DOPPLER_STYLES.D02;
    const [h0, s0] = rgbToHsv(hexToRgb(baseHex));
    const anchorHue = s0 < GREY_S ? st.anchor : h0;   // 灰系用风格锚点，彩色用自己的色相
    const pal = st.deltas.map((d, i) => {
      // 饱和度：取「风格目标」与「材质本身饱和度」的折中，避免彩色材质派生出脏色
      const satMult = s0 < GREY_S ? 1 : Math.min(1, 0.55 + s0 * 0.6);
      return r3(hsvToRgb(anchorHue + d, st.sats[i] * satMult, st.vals[i]));
    });
    return {
      style,
      styleName: st.name,
      anchorHue: +anchorHue.toFixed(4),
      // 保留多少原材质颜色（文档 §9.1：MaterialKeep 0.25~0.65，禁止默认 1.0 全覆盖）
      preserveRatio: ov.preserveRatio ?? 0.42,
      // 多普勒整体强度（文档 §9.1：0.35~0.85，不要默认 1.0）
      strength: ov.strength ?? 0.62,
      hueShift: ov.hueShift ?? 0.0,
      saturationBoost: ov.saturationBoost ?? 1.0,
      brightnessBoost: ov.brightnessBoost ?? 1.0,
      colorBias: ov.colorBias ?? r3([0, 0, 0]),
      paletteStart: ov.paletteStart ?? pal[0],
      paletteMid: ov.paletteMid ?? pal[1],
      paletteEnd: ov.paletteEnd ?? pal[3],
      paletteAlt: ov.paletteAlt ?? pal[2],
    };
  }

  /**
   * 24 种刀身材质。
   * 字段与文档 §4 的 BladeMaterialConfig 一一对应（baseColor 用 hex，交给渲染层转线性）。
   */
  const RAW = [
    // ── M01-M08 钢铁基础系（metalness 0.92~1.00 / roughness 0.35~0.50 / specular 0.6~1.0）──
    { id: 'M01', name: '银灰碳钢', nameEn: 'Silver Carbon', group: '钢铁基础', baseColor: '#9aa2ac',
      metalness: 0.95, roughness: 0.45, roughnessVariation: 0.10, specularIntensity: 0.70, envIntensity: 1.00,
      dopplerStyle: 'D02' },
    { id: 'M02', name: '高碳钢', nameEn: 'High Carbon', group: '钢铁基础', baseColor: '#7d858f',
      metalness: 0.98, roughness: 0.40, roughnessVariation: 0.14, specularIntensity: 0.80, envIntensity: 1.05,
      dopplerStyle: 'D01' },
    { id: 'M03', name: '冷白不锈钢', nameEn: 'Cold White Steel', group: '钢铁基础', baseColor: '#d8dde4',
      metalness: 0.94, roughness: 0.38, roughnessVariation: 0.08, specularIntensity: 0.90, envIntensity: 1.10,
      dopplerStyle: 'D04' },
    { id: 'M04', name: '铬镜钢', nameEn: 'Chrome Mirror', group: '钢铁基础', baseColor: '#c8ced6',
      metalness: 1.00, roughness: 0.30, roughnessVariation: 0.05, specularIntensity: 1.00, envIntensity: 1.25,
      dopplerStyle: 'D01' },
    { id: 'M05', name: '枪灰钢', nameEn: 'Gunmetal Grey', group: '钢铁基础', baseColor: '#6b7480',
      metalness: 0.96, roughness: 0.48, roughnessVariation: 0.12, specularIntensity: 0.70, envIntensity: 1.00,
      dopplerStyle: 'D01' },
    { id: 'M06', name: '黑曜钢', nameEn: 'Obsidian Steel', group: '钢铁基础', baseColor: '#2c3037',
      metalness: 0.98, roughness: 0.42, roughnessVariation: 0.10, specularIntensity: 0.85, envIntensity: 1.15,
      dopplerStyle: 'D02' },
    { id: 'M07', name: '烟墨钢', nameEn: 'Smoke Ink Steel', group: '钢铁基础', baseColor: '#4a5058',
      metalness: 0.93, roughness: 0.50, roughnessVariation: 0.18, specularIntensity: 0.78, envIntensity: 1.08,
      clearcoat: 0.10, dopplerStyle: 'D02' },
    { id: 'M08', name: '锻黑钢', nameEn: 'Forged Black', group: '钢铁基础', baseColor: '#3a3e44',
      metalness: 0.92, roughness: 0.52, roughnessVariation: 0.30, specularIntensity: 0.62, envIntensity: 0.95,
      dopplerStyle: 'D02' },

    // ── M09-M14 彩色金属系（有色 + clearcoat + 轻微虹彩，不要单色填充）
    { id: 'M09', name: '冰蓝钛', nameEn: 'Ice Blue Titanium', group: '彩色金属', baseColor: '#8fc4de',
      metalness: 0.96, roughness: 0.18, roughnessVariation: 0.10, specularIntensity: 0.88, envIntensity: 1.15,
      clearcoat: 0.22, clearcoatRoughness: 0.14, iridescence: 0.10, iridescenceIOR: 1.35, iridescenceThickness: [120, 380],
      dopplerStyle: 'D04' },
    { id: 'M10', name: '深海钛', nameEn: 'Deep Sea Titanium', group: '彩色金属', baseColor: '#2f5f86',
      metalness: 0.97, roughness: 0.20, roughnessVariation: 0.10, specularIntensity: 0.86, envIntensity: 1.12,
      clearcoat: 0.20, clearcoatRoughness: 0.16, iridescence: 0.08, iridescenceIOR: 1.35, iridescenceThickness: [120, 360],
      dopplerStyle: 'D01' },
    { id: 'M11', name: '极光钛', nameEn: 'Aurora Titanium', group: '彩色金属', baseColor: '#5fbfa8',
      metalness: 0.95, roughness: 0.20, roughnessVariation: 0.12, specularIntensity: 0.86, envIntensity: 1.15,
      clearcoat: 0.24, clearcoatRoughness: 0.14, iridescence: 0.16, iridescenceIOR: 1.40, iridescenceThickness: [140, 420],
      dopplerStyle: 'D04' },
    { id: 'M12', name: '紫晶钛', nameEn: 'Amethyst Titanium', group: '彩色金属', baseColor: '#8b5cf6',
      metalness: 0.96, roughness: 0.22, roughnessVariation: 0.12, specularIntensity: 0.86, envIntensity: 1.12,
      clearcoat: 0.22, clearcoatRoughness: 0.14, iridescence: 0.14, iridescenceIOR: 1.38, iridescenceThickness: [130, 400],
      dopplerStyle: 'D02' },
    { id: 'M13', name: '赤焰钛', nameEn: 'Blaze Titanium', group: '彩色金属', baseColor: '#c0402a',
      metalness: 0.96, roughness: 0.24, roughnessVariation: 0.14, specularIntensity: 0.84, envIntensity: 1.10,
      clearcoat: 0.20, clearcoatRoughness: 0.16, iridescence: 0.10, iridescenceIOR: 1.36, iridescenceThickness: [140, 420],
      dopplerStyle: 'D03' },
    { id: 'M14', name: '黄金钛', nameEn: 'Gold Titanium', group: '彩色金属', baseColor: '#d9a84e',
      metalness: 0.98, roughness: 0.18, roughnessVariation: 0.10, specularIntensity: 0.92, envIntensity: 1.20,
      clearcoat: 0.26, clearcoatRoughness: 0.12, iridescence: 0.06, iridescenceIOR: 1.34, iridescenceThickness: [120, 360],
      dopplerStyle: 'D03',
      // 黄金要"金 → 橙 → 紫 → 蓝"（文档 §9.2 黄金钛示例），派生结果再压一点暖
      dopplerOverride: { preserveRatio: 0.50, strength: 0.55,
        paletteStart: [0.82, 0.60, 0.16], paletteMid: [0.90, 0.44, 0.10], paletteEnd: [0.16, 0.22, 0.86], paletteAlt: [0.48, 0.14, 0.62] } },

    // ── M15-M18 宝石 / 珠光视觉（metalness 0.65~0.95 / clearcoat 0.35~0.75 / roughness 0.10~0.28）
    { id: 'M15', name: '蓝晶金属', nameEn: 'Sapphire Metal', group: '宝石珠光', baseColor: '#3f7fd0',
      metalness: 0.80, roughness: 0.16, roughnessVariation: 0.08, specularIntensity: 0.95, envIntensity: 1.25,
      clearcoat: 0.55, clearcoatRoughness: 0.08, transmission: 0.12, ior: 1.50,
      iridescence: 0.12, iridescenceIOR: 1.40, iridescenceThickness: [150, 460],
      dopplerStyle: 'D01' },
    { id: 'M16', name: '紫晶金属', nameEn: 'Amethyst Metal', group: '宝石珠光', baseColor: '#9d6cd8',
      metalness: 0.78, roughness: 0.18, roughnessVariation: 0.08, specularIntensity: 0.95, envIntensity: 1.25,
      clearcoat: 0.58, clearcoatRoughness: 0.08, transmission: 0.12, ior: 1.50,
      iridescence: 0.18, iridescenceIOR: 1.42, iridescenceThickness: [160, 480],
      dopplerStyle: 'D02' },
    { id: 'M17', name: '翡翠金属', nameEn: 'Jade Metal', group: '宝石珠光', baseColor: '#3fae84',
      metalness: 0.74, roughness: 0.20, roughnessVariation: 0.10, specularIntensity: 0.92, envIntensity: 1.20,
      clearcoat: 0.62, clearcoatRoughness: 0.10, transmission: 0.15, ior: 1.48,
      iridescence: 0.10, iridescenceIOR: 1.40, iridescenceThickness: [150, 440],
      dopplerStyle: 'D04' },
    { id: 'M18', name: '琥珀金属', nameEn: 'Amber Metal', group: '宝石珠光', baseColor: '#d98324',
      metalness: 0.72, roughness: 0.22, roughnessVariation: 0.10, specularIntensity: 0.92, envIntensity: 1.22,
      clearcoat: 0.66, clearcoatRoughness: 0.10, transmission: 0.18, ior: 1.46,
      iridescence: 0.10, iridescenceIOR: 1.38, iridescenceThickness: [160, 480],
      dopplerStyle: 'D03' },

    // ── M19-M21 珠光 / 液态金属（金属度 + clearcoat + fresnel + 轻微虹彩）
    { id: 'M19', name: '珠光白金', nameEn: 'Pearl Platinum', group: '珠光液态', baseColor: '#e3e6ea',
      metalness: 0.94, roughness: 0.16, roughnessVariation: 0.08, specularIntensity: 0.96, envIntensity: 1.25,
      clearcoat: 0.40, clearcoatRoughness: 0.08, iridescence: 0.34, iridescenceIOR: 1.42, iridescenceThickness: [140, 460],
      dopplerStyle: 'D04' },
    { id: 'M20', name: '液态银', nameEn: 'Liquid Silver', group: '珠光液态', baseColor: '#cfd6de',
      metalness: 1.00, roughness: 0.10, roughnessVariation: 0.06, specularIntensity: 1.00, envIntensity: 1.35,
      clearcoat: 0.30, clearcoatRoughness: 0.06, iridescence: 0.10, iridescenceIOR: 1.38, iridescenceThickness: [120, 380],
      dopplerStyle: 'D01' },
    { id: 'M21', name: '液态黑', nameEn: 'Liquid Black', group: '珠光液态', baseColor: '#24272c',
      metalness: 0.99, roughness: 0.13, roughnessVariation: 0.08, specularIntensity: 0.95, envIntensity: 1.30,
      clearcoat: 0.45, clearcoatRoughness: 0.06, iridescence: 0.16, iridescenceIOR: 1.40, iridescenceThickness: [140, 440],
      dopplerStyle: 'D02' },

    // ── M22-M24 特殊视觉（高级稀有）
    { id: 'M22', name: '星空黑', nameEn: 'Starfield Black', group: '特殊视觉', baseColor: '#1a1c22',
      metalness: 0.97, roughness: 0.20, roughnessVariation: 0.22, specularIntensity: 0.88, envIntensity: 1.15,
      clearcoat: 0.30, clearcoatRoughness: 0.10, iridescence: 0.20, iridescenceIOR: 1.42, iridescenceThickness: [150, 480],
      dopplerStyle: 'D01',
      // 微弱星尘：极低强度的点状自发光（由纹理/工艺侧的噪声调制，不写死在材质里）
      emissionColor: '#9fb6ff', emissionIntensity: 0.03 },
    { id: 'M23', name: '月蚀紫', nameEn: 'Eclipse Purple', group: '特殊视觉', baseColor: '#4a2f6b',
      metalness: 0.96, roughness: 0.18, roughnessVariation: 0.12, specularIntensity: 0.90, envIntensity: 1.18,
      clearcoat: 0.35, clearcoatRoughness: 0.10, iridescence: 0.24, iridescenceIOR: 1.44, iridescenceThickness: [150, 500],
      dopplerStyle: 'D02',
      emissionColor: '#6f5bff', emissionIntensity: 0.02 },
    { id: 'M24', name: '极光银', nameEn: 'Aurora Silver', group: '特殊视觉', baseColor: '#c9d6e2',
      metalness: 0.95, roughness: 0.15, roughnessVariation: 0.10, specularIntensity: 0.94, envIntensity: 1.28,
      clearcoat: 0.42, clearcoatRoughness: 0.08, iridescence: 0.38, iridescenceIOR: 1.46, iridescenceThickness: [160, 520],
      dopplerStyle: 'D04',
      emissionColor: '#7fe3d0', emissionIntensity: 0.015 },
  ];

  const MATERIAL_DEFAULTS = Object.freeze({
    metalness: 0.95, roughness: 0.30, roughnessVariation: 0.10, specularIntensity: 0.8,
    clearcoat: 0.0, clearcoatRoughness: 0.10, anisotropy: 0.0, anisotropyRotation: 0.0,
    transmission: 0.0, ior: 1.45, iridescence: 0.0, iridescenceIOR: 1.35,
    iridescenceThickness: [100, 400], emissionColor: null, emissionIntensity: 0.0, envIntensity: 1.0,
  });

  const MATERIALS = RAW.map((m) => {
    const cfg = { ...MATERIAL_DEFAULTS, ...m };
    cfg.doppler = makeDopplerProfile(cfg.baseColor, cfg.dopplerStyle, cfg.dopplerOverride || {});
    delete cfg.dopplerOverride;
    return Object.freeze(cfg);
  });

  /** UI 分组（按文档 §3 的五个系） */
  const GROUPS = ['钢铁基础', '彩色金属', '宝石珠光', '珠光液态', '特殊视觉'];

  K3D.materials24 = {
    DOPPLER_STYLES,
    MATERIALS,
    GROUPS,
    MATERIAL_DEFAULTS,
    makeDopplerProfile,
    list: () => MATERIALS.slice(),
    byGroup: (g) => MATERIALS.filter((m) => m.group === g),
    get(id) { return MATERIALS.find((m) => m.id === id) || MATERIALS[0]; },
  };
}(window.K3D = window.K3D || {}));
