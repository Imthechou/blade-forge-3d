/**
 * 《锻刀大赛 BladeSkin》P0 —— BladeSkinState / 确定性 Seed / 皮肤组合器
 * （技术方案 §9.7 §12 §13 §14 §23）
 *
 * 核心原则（文档开头第 5 行）：
 *   **数据决定结果，Viewer 只负责呈现；同一 Seed 可稳定复现同一把刀皮。**
 *   → 本文件里禁止出现 Math.random()，一切随机都走 seededRandom(seed)。
 *
 * 职责：
 *   1. BladeSkinState 的构造 / 归一化 / 序列化（可存档、可回放）
 *   2. seed → 多个子种子（patternSeed / warpSeed / colorPhaseSeed / fresnelSeed / scratchSeed）
 *   3. Wear 拆解成 5 路（edge / surface / pattern / roughness / scratch，文档 §12）
 *   4. composeBladeSkin(state) → 渲染层直接可用的 uniform 包（文档 §23 的组合器）
 */
'use strict';

(function attach(K3D) {
  // ── 确定性随机（mulberry32：同 seed 永远同序列） ──────────────────
  function seededRandom(seed) {
    let a = (Number(seed) >>> 0) || 1;
    return function rand() {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  /** 把任意字符串/数字混成 32 位种子（稳定、跨会话一致） */
  function hashSeed(...parts) {
    let h = 2166136261 >>> 0;
    for (const p of parts) {
      const s = String(p);
      for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 16777619) >>> 0;
      }
    }
    return h >>> 0;
  }
  const smoothstep = (e0, e1, x) => {
    const t = Math.min(1, Math.max(0, (x - e0) / Math.max(e1 - e0, 1e-6)));
    return t * t * (3 - 2 * t);
  };

  /** seed → 子种子（文档 §13：skinSeed 派生 patternSeed/materialVariantSeed/finishSeed/scratchSeed
   *  以及 §9.7 的 warpSeed / colorPhaseSeed / fresnelVariationSeed） */
  function deriveSeeds(seed) {
    const r = seededRandom(hashSeed('bladeskin', seed));
    const pick = () => Math.floor(r() * 1000000);
    return {
      patternSeed: pick(),
      warpSeed: pick(),
      colorPhaseSeed: r(),          // 0~1：色彩相位（做色相上的相位偏移）
      fresnelSeed: r(),
      scratchSeed: pick(),
      materialVariantSeed: pick(),
      finishSeed: pick(),
    };
  }

  /** Wear 拆解（文档 §12 给了 4 条，这里补 roughnessWear 凑齐 5 路） */
  function wearLevels(wear) {
    const w = Math.min(1, Math.max(0, Number(wear) || 0));
    return {
      edge: smoothstep(0.15, 0.85, w),
      surface: smoothstep(0.20, 0.90, w),
      pattern: smoothstep(0.35, 1.00, w),
      scratch: smoothstep(0.25, 0.80, w),
      roughness: smoothstep(0.20, 0.90, w),
    };
  }

  /** 默认 state（文档 §14） */
  const STATE_DEFAULTS = Object.freeze({
    materialId: 'M01',
    textureId: 'T04',
    finishId: 'F10',
    wear: 0.12,
    seed: 381729,
    patternSeed: null,        // null = 由 seed 派生
    patternScale: 1.0,
    patternRotation: 0,
    patternOffset: { x: 0, y: 0 },
    variantParams: {},
  });

  /** 构造并归一化一个 BladeSkinState */
  function makeState(partial = {}) {
    const s = { ...STATE_DEFAULTS, ...partial };
    s.materialId = (K3D.materials24.get(s.materialId) || {}).id || 'M01';
    s.textureId = (K3D.textures12.get(s.textureId) || {}).id || 'T04';
    s.finishId = (K3D.finishes12.get(s.finishId) || {}).id || 'F10';
    s.wear = Math.min(1, Math.max(0, Number(s.wear) || 0));
    s.seed = (Number(s.seed) >>> 0) || 381729;
    s.patternScale = Number(s.patternScale) || 1;
    s.patternRotation = Number(s.patternRotation) || 0;
    s.patternOffset = {
      x: Number(s.patternOffset && s.patternOffset.x) || 0,
      y: Number(s.patternOffset && s.patternOffset.y) || 0,
    };
    s.variantParams = { ...(s.variantParams || {}) };
    return s;
  }

  /** 稳定指纹（用于缓存 key / 存档对比；同 state 必同串） */
  function hashState(s) {
    const st = makeState(s);
    return [
      st.materialId, st.textureId, st.finishId,
      st.wear.toFixed(3), st.seed,
      st.patternSeed == null ? 'auto' : st.patternSeed,
      st.patternScale.toFixed(3), st.patternRotation.toFixed(3),
      st.patternOffset.x.toFixed(3), st.patternOffset.y.toFixed(3),
      Object.keys(st.variantParams).sort().map((k) => k + '=' + st.variantParams[k]).join(','),
    ].join('|');
  }

  /**
   * 皮肤组合器（文档 §23）：把 BladeSkinState 组合成渲染层可用的 uniform 包。
   * Viewer 只负责「读 state → 设参数 → 渲染」，不自己决定应该是什么材质（文档 §22）。
   */
  function composeBladeSkin(state) {
    const st = makeState(state);
    const matBase = K3D.materials24.get(st.materialId);
    const tex = K3D.textures12.get(st.textureId);
    const finBase = K3D.finishes12.get(st.finishId);
    // 工艺阶段可对基础材质/工艺做轻量变体，不改变材料/纹理/工艺 ID。
    const mat = { ...matBase, ...(st.variantParams.material || {}) };
    const fin = { ...finBase, ...(st.variantParams.finishProfile || {}) };
    const seeds = deriveSeeds(st.seed);
    if (st.patternSeed != null) seeds.patternSeed = st.patternSeed >>> 0;
    const wear = wearLevels(st.wear);
    const d = mat.doppler;

    // 纹理参数 = 该纹理默认值 + 用户覆盖（文档 §6：seed/scale/rotation/offset/warp 必带）
    const tp = {
      ...tex.defaults,
      scale: st.patternScale,
      rotation: st.patternRotation,
      offsetX: st.patternOffset.x,
      offsetY: st.patternOffset.y,
      ...(st.variantParams.texture || {}),
    };
    // 工艺参数 = 该工艺默认值 + 用户覆盖
    const fp = { ...fin.defaults, ...(st.variantParams.finish || {}) };

    // ── Wear 对工艺/多普勒的衰减（文档 §9.10：磨损要"逐渐失去完整度"，不只是降颜色）──
    const dopplerStrength = (fp.strength ?? d.strength) * (1.0 - st.wear * 0.55);
    const iridescence = (mat.iridescence || 0) * (1.0 - st.wear * 0.70);
    const patternContrast = Math.max(0.05, (tp.contrast ?? 0.5) * (1.0 - st.wear * 0.45));
    const dopplerPreserve = Math.min(0.65, Math.max(0.25, (fp.preserveRatio ?? d.preserveRatio) + st.wear * 0.18));

    return {
      state: st,
      material: mat,
      texture: tex,
      finish: fin,
      seeds,
      wear,
      uniforms: {
        // ── 材质层 ──
        uBladeBaseColor: mat.baseColor,
        uBladeMetalness: mat.metalness,
        uBladeRoughness: mat.roughness,
        uBladeRoughVar: mat.roughnessVariation,
        uBladeSpecular: mat.specularIntensity,
        uBladeClearcoat: mat.clearcoat,
        uBladeClearcoatRough: mat.clearcoatRoughness,
        uBladeAnisotropy: mat.anisotropy,
        uBladeAnisotropyRot: mat.anisotropyRotation,
        uBladeTransmission: mat.transmission,
        uBladeIOR: mat.ior,
        uBladeIridescence: iridescence,                       // 已被 wear 衰减
        uBladeIridThickness: mat.iridescenceThickness || [100, 400],
        uBladeEmission: mat.emissionColor || '#000000',
        uBladeEmissionInt: mat.emissionIntensity || 0,
        uBladeEnvIntensity: mat.envIntensity,
        // ── 纹理层（id 走 int 分支，参数走 vec4 打包，避免 uniform 爆炸）──
        uTexId: K3D.textures12.indexOf(tex.id),
        uTexParam0: [tp.scale ?? 1, (tp.rotation ?? 0) * Math.PI / 180, tp.offsetX ?? 0, tp.offsetY ?? 0],
        uTexParam1: [tp.warp ?? 0, patternContrast, tp.density ?? 0, tp.direction ?? 0],
        uTexParam2: [tp.flowScale ?? 0, tp.warpStrength ?? 0, tp.layerCount ?? 0, tp.roughnessStrength ?? 0.4],
        uTexParam3: [tp.mistLarge ?? 0, tp.mistSmall ?? 0, tp.softness ?? 0, tp.cellScale ?? 0],
        uTexParam4: [tp.gridScale ?? 0, tp.grooveWidth ?? 0, tp.lineDensity ?? 0, tp.lineWidth ?? 0],
        uTexParam5: [tp.shardScale ?? 0, tp.shardContrast ?? 0, tp.plateThickness ?? 0, tp.frequency ?? 0],
        uTexParam6: [tp.tile ?? 0, tp.flowDir ?? 0, tp.stretch ?? 0, tp.anisotropy ?? 0],
        // ── 工艺层 ──
        uFinId: K3D.finishes12.indexOf(fin.id),
        uFinMix: fin.mix,
        uFinParam0: [fp.amount ?? 0, fp.darkness ?? 0, fp.gradient ?? 0, fp.heatSpread ?? 0],
        uFinParam1: [fp.phase ?? 0, fp.temperature ?? 0, fp.hueShift ?? 0, fp.coat ?? 0],
        uFinParam2: [dopplerStrength, dopplerPreserve, fp.fresnelPower ?? 2.2, fp.fresnelIntensity ?? 0.45],
        uFinParam3: [fp.colorPhase ?? 0, fp.flowSpeed ?? 0, fp.iridescence ?? 0, tp.colorSpread ?? 0],
        uFinColor: fp.tintHex || '#ffffff',
        // ── 多普勒调色板（材质派生，文档 §9.2）──
        uDopPal0: d.paletteStart,
        uDopPal1: d.paletteMid,
        uDopPal2: d.paletteAlt,
        uDopPal3: d.paletteEnd,
        uDopMeta: [d.hueShift, d.saturationBoost, d.brightnessBoost, d.anchorHue],
        uDopStyle: ['D01', 'D02', 'D03', 'D04'].indexOf(d.style) + 1,
        // ── 种子（文档 §9.7：seed 同时影响雾团与色彩相位）──
        uSeeds: [seeds.patternSeed / 1000000, seeds.warpSeed / 1000000, seeds.colorPhaseSeed, seeds.fresnelSeed],
        // ── Wear（文档 §12）──
        uWear01: st.wear,
        uWearLevels: [wear.edge, wear.surface, wear.pattern, wear.scratch],
        uWearRough: wear.roughness,
      },
    };
  }

  K3D.bladeSkin = {
    seededRandom, hashSeed, deriveSeeds, wearLevels,
    STATE_DEFAULTS, makeState, hashState, composeBladeSkin,
    list: () => ({ materials: K3D.materials24.list(), textures: K3D.textures12.list(), finishes: K3D.finishes12.list() }),
  };
}(window.K3D = window.K3D || {}));
