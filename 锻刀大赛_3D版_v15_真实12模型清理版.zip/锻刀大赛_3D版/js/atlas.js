/* Knife3D · atlas.js
 * UV 空间光栅化：根据 3D 模型的 UV + 顶点，把程序化花纹「烘焙」成适配该模型的贴图。
 *
 * 核心思路：花纹在 3D 物体空间求值（与 UV 岛排布无关，跨岛天然连续），
 * 逐三角形在 UV 空间光栅化，每个像素用重心坐标反算 3D 位置后着色。
 * 刀身 / 刀柄用模型自带 ORM 贴图的 B 通道（metalness）判定：
 *   刀身 ≈ 1 → 画花纹；刀柄 ≈ 0 → 保留模型自带贴图。
 *
 * 真实模型适配（v2）：
 *   · UV 岛重叠（两面共用）→ 光栅化改为「加权平均」而非后写覆盖，
 *     重叠区是两侧花纹的混合，消除平色斑块与锯齿边界
 *   · 坐标按「刀身实际范围」归一化（s 和 a 各自归一），花纹频率与刀型尺度无关
 *   · fade 用「刀身中心线弧长」参数化，渐变沿真实刀身路径分布（弯刀不再挤成一团）
 *   · 生成后按刀身平均亮度归一化，跨皮肤跨刀型亮度一致
 * 本文件是纯算法（不碰 DOM），输出 TypedArray，方便在 Node 里做单元测试。
 */
(function (global) {
'use strict';
const K3D = (global.K3D = global.K3D || {});

/* ---------------------------------------------------------------- 3D 噪声 */

function hash3(i, j, k, seed) {
  let h = (i * 374761393 + j * 668265263 + k * 1274126177 + seed * 2654435761) | 0;
  h = ((h ^ (h >>> 13)) * 1274126177) | 0;
  return ((h ^ (h >>> 16)) & 0xFFFF) / 65535;
}

function fadeT(t) { return t * t * (3 - 2 * t); }
function lerp(a, b, t) { return a + (b - a) * t; }
function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
function smoothstep(e0, e1, x) {
  const t = clamp01((x - e0) / (e1 - e0 || 1e-6));
  return t * t * (3 - 2 * t);
}

function noise3(x, y, z, seed) {
  const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
  const ux = fadeT(x - ix), uy = fadeT(y - iy), uz = fadeT(z - iz);
  const c = [];
  for (let a = 0; a < 2; a++) {
    c[a] = [];
    for (let b = 0; b < 2; b++) {
      c[a][b] = [hash3(ix + a, iy + b, iz, seed), hash3(ix + a, iy + b, iz + 1, seed)];
    }
  }
  const x00 = lerp(c[0][0][0], c[1][0][0], ux);
  const x10 = lerp(c[0][1][0], c[1][1][0], ux);
  const x01 = lerp(c[0][0][1], c[1][0][1], ux);
  const x11 = lerp(c[0][1][1], c[1][1][1], ux);
  return lerp(lerp(x00, x10, uy), lerp(x01, x11, uy), uz);
}

function fbm3(x, y, z, seed, octaves) {
  let v = 0, amp = 1, freq = 1, total = 0;
  for (let o = 0; o < octaves; o++) {
    v += noise3(x * freq, y * freq, z * freq, seed + o * 101) * amp;
    total += amp;
    amp *= 0.5;
    freq *= 2;
  }
  return v / total;
}

function hexRgb(h) {
  h = h.replace('#', '');
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

function ramp3(c1, c2, c3, t) {
  const k = clamp01(t);
  let f, to, a;
  if (k < 0.5) { f = c1; to = c2; a = k * 2; } else { f = c2; to = c3; a = 1; }
  return [f[0] + (to[0] - f[0]) * a, f[1] + (to[1] - f[1]) * a, f[2] + (to[2] - f[2]) * a];
}

/** 任意档数渐变：把 t 均分到 colors.length-1 段。用于 fade 的 紫→粉→橙→金 多段过渡
 *（3 档时中间色只占 t=0.5 一点，首尾色几乎直跳，观感很硬）。 */
function rampN(colors, t) {
  const n = colors.length - 1;
  if (n <= 0) return colors[0].slice();
  const x = clamp01(t) * n;
  const i = Math.min(n - 1, Math.floor(x));
  const f = x - i;
  const a = colors[i], b = colors[i + 1];
  return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f];
}

/** 饱和度增强：官方涂装比纯程序化配色更"出彩"，把颜色推离自身的灰。 */
function enhance(c, sat) {
  const l = c[0] * 0.2126 + c[1] * 0.7152 + c[2] * 0.0722;
  return [
    Math.min(255, Math.max(0, l + (c[0] - l) * sat)),
    Math.min(255, Math.max(0, l + (c[1] - l) * sat)),
    Math.min(255, Math.max(0, l + (c[2] - l) * sat)),
  ];
}

/** 对比度：把 t 从中点向外推，让色块边界更清晰（纯噪声渐变容易发灰）。 */
function contrastT(t, k = 1.28) {
  return clamp01((t - 0.5) * k + 0.5);
}

/* ---------------------------------------------------------------- 刀身标架 */

/**
 * 从网格预扫描刀身（metalness>0.5 的区域）的实际范围，建立花纹标架：
 *   axis    刀身长轴（包围盒最长边）
 *   s/a     长轴方向 / 横向，各自按「刀身实际占据的区间」归一化
 *   arc     中心线弧长表：把 s∈0..1 映射到「沿刀身真实路径的弧长占比」，
 *           弯刀（如爪刀）的渐变因此沿刀刃分布而不是沿包围盒直线
 */
const ARC_BUCKETS = 64;

function buildFrame(mesh, ormB) {
  const { positions, uvs, index } = mesh;
  let minX = 1e9, minY = 1e9, minZ = 1e9, maxX = -1e9, maxY = -1e9, maxZ = -1e9;
  for (let i = 0; i < positions.length; i += 3) {
    const x = positions[i], y = positions[i + 1], z = positions[i + 2];
    if (x < minX) minX = x; if (x > maxX) maxX = x;
    if (y < minY) minY = y; if (y > maxY) maxY = y;
    if (z < minZ) minZ = z; if (z > maxZ) maxZ = z;
  }
  const dims = [maxX - minX, maxY - minY, maxZ - minZ];
  let ai = 0;
  for (let d = 1; d < 3; d++) if (dims[d] > dims[ai]) ai = d;
  const axis = [0, 0, 0]; axis[ai] = 1;
  const origin = [minX, minY, minZ];
  const span = Math.max(dims[ai], 1e-6);

  // 横向 a 取「次长轴」（宽度），b 取第三轴（厚度）——
  // 不能用叉乘：叉乘顺序可能把 a 分到厚度方向（真实熊刀实测 aDen=0.015，
  // 噪声被放大 66 倍，花纹在横向退化成高频抖动）
  const others = [0, 1, 2].filter((d) => d !== ai);
  const aIdx = dims[others[0]] >= dims[others[1]] ? others[0] : others[1];
  const bIdx = 3 - ai - aIdx;
  const b1 = [0, 0, 0]; b1[aIdx] = 1;
  const b2 = [0, 0, 0]; b2[bIdx] = 1;

  const project = (vi) => ({
    s: (positions[vi * 3 + ai] - origin[ai]) / span,
    a: (positions[vi * 3 + aIdx] - origin[aIdx]) / span,
  });

  // 第一遍：所有 ORM 白三角形 → 候选刀身
  const bladeTriList = [];
  for (let f = 0; f < index.length; f += 3) {
    const i0 = index[f], i1 = index[f + 1], i2 = index[f + 2];
    const um = (uvs[i0 * 2] + uvs[i1 * 2] + uvs[i2 * 2]) / 3;
    const vm = (uvs[i0 * 2 + 1] + uvs[i1 * 2 + 1] + uvs[i2 * 2 + 1]) / 3;
    if (ormB(um, vm) < 0.5) continue;
    bladeTriList.push([i0, i1, i2]);
  }

  // 3D 空间连通块分析：metalness=1 的金属小件（尾钉、挂具）在 3D 上与刀身
  // 不共享顶点 → 独立连通块。它们会把刀身 sMin/sMax 拉偏（渐变被压缩，
  // 真实熊刀实测：小件把 sMin 从 0.49 拉到 0，fade 整刀变粉）。
  // 取「三角形数最多的连通块」为主刀身；其他块若 s 中心落在主块范围
  // ±0.12 内则保留（刀身镶件），否则降级为刀柄。
  const triCount = bladeTriList.length;
  const blockOf = new Int32Array(triCount).fill(-1);
  // 连通性按「3D 位置」而不是顶点索引：真实模型的两面/侧壁常是顶点重复的
  // 独立三角形（不共享 index），按索引判定会把同一刀身拆成多个块
  const posKey = (vi) => {
    const x = positions[vi * 3], y = positions[vi * 3 + 1], z = positions[vi * 3 + 2];
    return Math.round(x * 500) + '_' + Math.round(y * 500) + '_' + Math.round(z * 500);
  };
  const vertTris = new Map();
  bladeTriList.forEach((tri, ti) => {
    for (const v of tri) {
      const k = posKey(v);
      if (!vertTris.has(k)) vertTris.set(k, []);
      vertTris.get(k).push(ti);
    }
  });
  const blocks = [];
  for (let ti = 0; ti < triCount; ti++) {
    if (blockOf[ti] >= 0) continue;
    const id = blocks.length;
    const queue = [ti];
    blockOf[ti] = id;
    let tris = 0, sLo = 1e9, sHi = -1e9;
    while (queue.length) {
      const t = queue.pop();
      tris++;
      for (const v of bladeTriList[t]) {
        const s = (positions[v * 3 + ai] - origin[ai]) / span;
        if (s < sLo) sLo = s;
        if (s > sHi) sHi = s;
        for (const nt of vertTris.get(posKey(v)) || []) {
          if (blockOf[nt] < 0) { blockOf[nt] = id; queue.push(nt); }
        }
      }
    }
    blocks.push({ id, tris, sLo, sHi });
  }
  const mainBlock = blocks.reduce((a, b) => (b.tris > a.tris ? b : a), blocks[0]);
  const keepBlock = new Uint8Array(blocks.length);
  for (const blk of blocks) {
    const center = (blk.sLo + blk.sHi) / 2;
    const pad = (mainBlock.sHi - mainBlock.sLo) * 0.12 + 0.02;
    blk.keep = blk.id === mainBlock.id ||
      (center >= mainBlock.sLo - pad && center <= mainBlock.sHi + pad);
    keepBlock[blk.id] = blk.keep ? 1 : 0;
  }

  // 第二遍：只统计保留块里的「真刀身」
  let smin = 1e9, smax = -1e9, amin = 1e9, amax = -1e9;
  const bladeTris = [];
  for (let ti = 0; ti < triCount; ti++) {
    if (!keepBlock[blockOf[ti]]) continue;
    const [i0, i1, i2] = bladeTriList[ti];
    bladeTris.push([i0, i1, i2]);
    for (const vi of [i0, i1, i2]) {
      const p = project(vi);
      if (p.s < smin) smin = p.s;
      if (p.s > smax) smax = p.s;
      if (p.a < amin) amin = p.a;
      if (p.a > amax) amax = p.a;
    }
  }
  const noBlade = bladeTris.length === 0;
  if (noBlade) { smin = 0; smax = 1; amin = -0.5; amax = 0.5; }

  const sDen = Math.abs(smax - smin) > 1e-6 ? smax - smin : 1;
  const aDen = Math.abs(amax - amin) > 1e-6 ? amax - amin : 1;

  // 主刀身的 s 保留区间（光栅化时把离群金属件强制按刀柄处理）
  let sKeepLo = 1e9, sKeepHi = -1e9;
  for (const blk of blocks) {
    if (!blk.keep) continue;
    sKeepLo = Math.min(sKeepLo, blk.sLo);
    sKeepHi = Math.max(sKeepHi, blk.sHi);
  }
  if (noBlade) { sKeepLo = 0; sKeepHi = 1; }

  // 中心线：把刀身顶点按 s 分桶，取每桶平均 a；再沿折线累积弧长
  const buckets = Array.from({ length: ARC_BUCKETS }, () => ({ sum: 0, n: 0 }));
  for (const [i0, i1, i2] of bladeTris) {
    for (const vi of [i0, i1, i2]) {
      const p = project(vi);
      const sn = clamp01((p.s - smin) / sDen);
      const bi = Math.min(ARC_BUCKETS - 1, Math.floor(sn * ARC_BUCKETS));
      buckets[bi].sum += p.a;
      buckets[bi].n++;
    }
  }
  const centerA = buckets.map((bk, i) => {
    if (bk.n > 0) return bk.sum / bk.n;
    // 空桶：取最近非空桶
    for (let d = 1; d < ARC_BUCKETS; d++) {
      if (i - d >= 0 && buckets[i - d].n) return buckets[i - d].sum / buckets[i - d].n;
      if (i + d < ARC_BUCKETS && buckets[i + d].n) return buckets[i + d].sum / buckets[i + d].n;
    }
    return 0;
  });
  // 轻度平滑
  const smoothA = centerA.map((_, i) => {
    const p = centerA[Math.max(0, i - 1)];
    const q = centerA[Math.min(ARC_BUCKETS - 1, i + 1)];
    return (p + centerA[i] * 2 + q) / 4;
  });
  // 累积弧长（含侧向偏移的变化 → 弯刀路径更真实）
  const cum = new Float64Array(ARC_BUCKETS);
  for (let i = 1; i < ARC_BUCKETS; i++) {
    const ds = 1 / (ARC_BUCKETS - 1);
    const da = smoothA[i] - smoothA[i - 1];
    cum[i] = cum[i - 1] + Math.hypot(ds, da);
  }
  const total = cum[ARC_BUCKETS - 1] || 1;
  const arc = Array.from(cum, (v) => v / total);

  return {
    axis, origin, span, b1, b2,
    axisIdx: ai, aIdx, bIdx,
    span2: Math.max(dims[aIdx], 1e-6),   // 次长轴 bbox 跨度（切割倾角归一化，与 engine 一致）
    sKeepLo, sKeepHi,
    sMin: smin, sDen, aMin: amin, aDen,
    arc, noBlade,
    stats: { bladeTris: bladeTris.length, sRange: [+smin.toFixed(3), +smax.toFixed(3)] },
  };
}

/* ---------------------------------------------------------------- 花纹（3D 物体空间） */

/**
 * 刀柄材质纹理生成器（12 种）。
 * 约定：只返回**结构明暗系数**（约 0.35~1.45），输出灰度 —— 颜色由 shader 的
 * 刀柄着色（tint）给，这样用户换色时纹理结构保持不变，且预设与色板可自由组合。
 * 全部复用 fbm3 / sin，零外部资产；单像素 ≤4 次噪声调用。
 */
const HANDLE_KINDS = {
  // 木质：沿长轴定向条纹（低频扰动成自然木纹）+ 年轮
  wood: (s, a, b, sd) => {
    const warp = (fbm3(s * 2, a * 2, b * 2, sd, 3) - 0.5) * 1.6;
    const grain = 0.5 + 0.5 * Math.sin((a * 14 + warp * 3) * Math.PI);
    const ring = 0.5 + 0.5 * Math.sin((s * 3 + warp) * Math.PI * 2);
    return 0.78 + (grain - 0.5) * 0.42 + (ring - 0.5) * 0.16;
  },
  // 玉质：低频云雾（边界极软，温润）
  jade: (s, a, b, sd) => {
    const cloud = fbm3(s * 1.3, a * 1.3, b * 1.3, sd, 4);
    return 0.74 + (smoothstep(0.32, 0.72, cloud) - 0.5) * 0.48;
  },
  // 竹质：竖向高频纤维 + 周期性竹节
  bamboo: (s, a, b, sd) => {
    const fiber = 0.5 + 0.5 * Math.sin(a * 46 + (fbm3(s * 3, a * 3, b * 3, sd, 2) - 0.5) * 2);
    const node = Math.pow(Math.abs(Math.sin(s * 3.2)), 14);
    return 0.80 + (fiber - 0.5) * 0.26 + node * 0.30;
  },
  // 皮革：高频粒面 + 中频起伏（哑光）
  leather: (s, a, b, sd) => {
    const grain = fbm3(s * 34, a * 34, b * 34, sd, 2);
    const bump = fbm3(s * 7, a * 7, b * 7, sd + 9, 3);
    return 0.74 + (grain - 0.5) * 0.30 + (bump - 0.5) * 0.34;
  },
  // 碳纤维：两组 45° 斜纹按棋盘交替 = 编织格
  carbon: (s, a, b, sd) => {
    const t1 = 0.5 + 0.5 * Math.sin((s + a) * 62);
    const t2 = 0.5 + 0.5 * Math.sin((s - a) * 62);
    const cell = (Math.floor(s * 26) + Math.floor(a * 26)) % 2;
    return 0.70 + ((cell ? t1 : t2) - 0.5) * 0.46;
  },
  // 机加工：同心车削纹
  machined: (s, a, b) => {
    const r = Math.hypot(a - 0.5, s - 0.5);
    return 0.84 + (0.5 + 0.5 * Math.sin(r * 95) - 0.5) * 0.26;
  },
  // 聚合物：极细磨砂（近纯色）
  polymer: (s, a, b, sd) => 0.88 + (fbm3(s * 70, a * 70, b * 70, sd, 1) - 0.5) * 0.10,
  // 拉丝金属：各向异性（纵向低频、横向高频）
  brushed: (s, a, b, sd) => 0.84 + (fbm3(s * 5, a * 95, b * 95, sd, 2) - 0.5) * 0.30,
  // 陶瓷：极弱斑驳 + 近纯色（锐利高光）
  ceramic: (s, a, b, sd) => 0.92 + (fbm3(s * 2.2, a * 2.2, b * 2.2, sd, 2) - 0.5) * 0.12,
  // 大理石：湍流脉络
  marble: (s, a, b, sd) => {
    const n = fbm3(s * 2.4, a * 2.4, b * 2.4, sd, 4);
    return 0.80 + (smoothstep(0.35, 0.7, n) - 0.5) * 0.42;
  },
  // 橡胶：超高频细颗粒（最哑光）
  rubber: (s, a, b, sd) => 0.66 + (fbm3(s * 52, a * 52, b * 52, sd, 2) - 0.5) * 0.20,
  // G10 战术：层压平行色带 + 玻璃布底纹
  g10: (s, a, b, sd) => {
    const layer = 0.5 + 0.5 * Math.sin(a * 44 + (fbm3(s * 6, a * 6, b * 6, sd, 2) - 0.5) * 1.2);
    const cloth = fbm3(s * 58, a * 58, b * 58, sd + 3, 1) - 0.5;
    return 0.78 + (layer - 0.5) * 0.34 + cloth * 0.12;
  },
};

class Pattern {
  constructor(spec, frame) {
    this.kind = spec.kind;
    this.c1 = hexRgb(spec.c1);
    this.c2 = hexRgb(spec.c2);
    this.c3 = hexRgb(spec.c3);
    this.c4 = spec.c4 ? hexRgb(spec.c4) : null;   // 可选第 4 档（fade 的多段渐变）
    this.freq = spec.freq ?? 5;
    // 刀型个体差异（由 knifeSalt 派生，确定性）：相位偏移 + 密度微调。
    // 回退到「三层体系后」的幅度（±0.12 / ±0.08 / ±6%）。
    this.salt = spec.knifeSalt || null;
    if (this.salt) this.freq *= 1 + (this.salt[1] - 0.5) * 0.12;
    this.seed = (spec.seed ?? 11) + (spec.seedShift ?? 0);
    this.extra = spec;
    this.f = frame;
    // seed「窗口偏移」：对齐 CS2 pattern index 语义 —— 花纹在刀身上平移/旋转，
    // 而非换一整套噪声。du/dv∈[0,1)，rot 弧度。
    this.du = spec.du ?? 0;
    this.dv = spec.dv ?? 0;
    this.rot = spec.rot ?? 0;
    // ── 用户纹理参数（方案 §44 交互参数）──
    // ⚠ 缩放不能只乘 this.freq：多数生成器（doppler / vein / detailAt）用的是**硬编码频率**，
    //   只有少数读 this.freq。所以缩放要在 local() 里作用于**坐标空间**，对所有生成器统一生效。
    this.texScale = (Number.isFinite(spec.freqScale) && spec.freqScale > 0) ? spec.freqScale : 1;
    if (Number.isFinite(spec.rotExtra)) this.rot += spec.rotExtra;
    if (Number.isFinite(spec.offU)) this.du += spec.offU;
    if (Number.isFinite(spec.offV)) this.dv += spec.offV;
  }

  /** 3D 点 → (s 0..1 沿刀身, a 0..1 横向, b 厚度方向 /span)，含窗口偏移 */
  local(x, y, z) {
    const { axis, origin, span, b1, b2, sMin, sDen, aMin, aDen } = this.f;
    const px = x - origin[0], py = y - origin[1], pz = z - origin[2];
    const sRaw = (px * axis[0] + py * axis[1] + pz * axis[2]) / span;
    const aRaw = px * b1[0] + py * b1[1] + pz * b1[2];
    const b = (px * b2[0] + py * b2[1] + pz * b2[2]) / span;
    let s = clamp01((sRaw - sMin) / sDen);
    let a = clamp01((aRaw / span - aMin) / aDen);
    // 纹理缩放（方案 §44）：缩放**坐标空间**，以中点为锚 → 对所有生成器统一生效
    if (this.texScale !== 1) {
      s = clamp01(0.5 + (s - 0.5) * this.texScale);
      a = clamp01(0.5 + (a - 0.5) * this.texScale);
    }
    // 个体差异：整把刀的花纹场做小幅平移（换刀纹路走向不同，同刀可复现）
    if (this.salt) {
      s += (this.salt[0] - 0.5) * 0.24;
      a += (this.salt[1] - 0.5) * 0.16;
    }
    if (this.rot || this.du || this.dv) {
      // 先小角度旋转（s/a 平面），再平移；取模让花纹无缝滑动
      if (this.rot) {
        const c = Math.cos(this.rot), sn = Math.sin(this.rot);
        const ns = s * c - a * sn;
        a = s * sn + a * c;
        s = ns;
      }
      s = (s - this.du) % 1; if (s < 0) s += 1;
      a = (a - this.dv) % 1; if (a < 0) a += 1;
    }
    return [s, a, b];
  }

  /** 弧长占比：s → 沿刀身真实路径的 0..1 */
  arcAt(s) {
    const arc = this.f.arc;
    const x = clamp01(s) * (arc.length - 1);
    const i = Math.min(arc.length - 2, Math.floor(x));
    return lerp(arc[i], arc[i + 1], x - i);
  }

  /**
   * 微观细节层：各向异性高频噪声 —— 沿刀身方向频率低（拉丝被拉长）、
   * 横向频率高。官方贴图都带这层磨痕/拉丝，纯程序化花纹少了它就会显得"塑料"。
   * 返回 0..2 的乘数（默认幅度 ±8%）。
   */
  detailAt(x, y, z) {
    const [s, a, b] = this.local(x, y, z);
    const amp = this.extra.detail ?? 0.24;
    if (amp <= 0) return 1;
    // 双频细节：中频（磨痕起伏，±amp/2）+ 高频（拉丝，±amp/2），两层都只乘在刀身上
    const mid = fbm3(s * 6, a * 28, b * 28, this.seed + 700, 3) - 0.5;
    const fine = fbm3(s * 14, a * 95, b * 95, this.seed + 900, 2) - 0.5;
    return 1 + (mid * 0.5 + fine * 0.5) * amp;
  }

  at(x, y, z) {
    const [s, a, b] = this.local(x, y, z);
    const sd = this.seed;
    // solid（纯色）：三段材质系统的基础皮肤（黑钢/银钢/黄金），刀身只有一个基色
    if (this.kind === 'solid') return [this.c1[0], this.c1[1], this.c1[2]];
    // 刀柄材质：输出灰度结构（颜色由 shader 的刀柄着色给）
    const hk = HANDLE_KINDS[this.kind];
    if (hk) {
      const g = Math.max(0, Math.min(255, hk(s, a, b, sd) * 255));
      return [g, g, g];
    }
    // linear（fade 渐变）：沿弧长的渐变 + 中频弯曲消除横向硬分带
    // （旧版纯 arcAt(s) 在弯刀上会出一条粉/蓝边界线）
    if (this.kind === 'linear') {
      const bend = this.extra.bend ?? 0.10;
      const warp = (fbm3(s * 3, a * 3, b * 3, sd + 55, 3) - 0.5) * 2 * bend;
      // 渐变起止与跨度（方案 v2 §15 的 start/end/scale）：
      // shift 平移渐变位置、span 控制它铺多宽 —— 对应 CS2 Fade 的渐变覆盖率
      const shift = this.extra.fadeShift ?? 0;
      const span = Math.max(0.05, this.extra.fadeSpan ?? 1);
      let t = clamp01((this.arcAt(s) + warp - bend - shift) / span);
      t = contrastT(t, this.extra.contrast ?? 1.0);
      // c4 存在时用 4 档渐变（紫→粉→橙→金），过渡更接近 CS2 Fade 的多段彩虹
      const stops = this.c4 ? [this.c1, this.c2, this.c3, this.c4] : [this.c1, this.c2, this.c3];
      return enhance(rampN(stops, t), 1.22);
    }

    if (this.kind === 'marble') {
      const f = this.freq;
      // 脉络模式（大马士革/大理石）：经典湍流 —— |noise| 多倍频叠加扭曲一条正弦，
      // 得到细密的流动脉络，而不是普通 fbm 的大色块
      if (this.extra.vein) {
        let turb = 0, amp = 1, fr = 1;
        for (let o = 0; o < 4; o++) {
          turb += Math.abs(fbm3(s * fr, a * fr, b * fr, sd + o * 77, 2) - 0.5) * amp;
          amp *= 0.62; fr *= 2.1;
        }
        const veinF = (this.extra.veinFreq ?? 7) * this.texScale;   // 纹理缩放在脉络路径也要生效
        const warpAmp = this.extra.warpExtra ?? 1.0;
        const phaseOff = this.extra.phase ?? 0;
        let t = 0.5 + 0.5 * Math.sin((s * veinF + turb * 5.0 * warpAmp + phaseOff) * Math.PI);
        t = contrastT(clamp01(t), this.extra.contrast ?? 1.25);
        return enhance(ramp3(this.c1, this.c2, this.c3, t), this.extra.sat ?? 1.15);
      }
      const n1 = fbm3(s * f, a * f, b * f, sd, 5);
      const n2 = fbm3(s * f + 5.2, a * f + 1.3, b * f, sd + 50, 4);
      const n3 = fbm3(s * f * 0.5, a * f * 0.5, b * f * 0.5, sd + 100, 3);
      // ⚠ 不要用 (x+0.5)%1：取模会在 0 处产生硬边断层 → 渲染成"迷彩硬块"。
      //   三频加权本身就是 0..1 的平滑场。
      let t = n1 * 0.5 + n2 * 0.3 + n3 * 0.2;
      // 定向波纹：叠一层平滑正弦带（让大理石呈流动波纹而非均匀斑点）
      const band = this.extra.band ?? 0.2;
      if (band > 0) {
        const bf = this.extra.bandFreq ?? 3;
        const warp = (fbm3(s * 2.2, a * 2.2, b * 2.2, sd + 321, 3) - 0.5) * 1.6;
        const wave = 0.5 + 0.5 * Math.sin((s * bf + warp) * Math.PI * 2);
        t = t * (1 - band) + wave * band;
      }
      t = contrastT(clamp01(t), this.extra.contrast ?? 1.14);
      return enhance(ramp3(this.c1, this.c2, this.c3, t), 1.26);
    }

    if (this.kind === 'tiger') {
      const f = this.freq * 2;
      const low = fbm3(s * 2.6, a * 2.6, b * 2.6, sd, 3) - 0.5;
      const high = fbm3(s * 9, a * 9, b * 9, sd + 77, 2) - 0.5;
      // 条纹沿「弧长方向」走，弯刀上条纹跟随刀身弯曲
      const sArc = this.arcAt(s);
      const phase = (sArc + a) * Math.PI * f + low * 2.7 + high * 0.35;
      const wave = Math.sin(phase) * 0.74
        + Math.sin(phase * 3 + low * 2.4) * 0.17
        + Math.sin(phase * 5 + high * 1.6) * 0.09;
      const edge = this.extra.edge ?? 0.30;
      let t = smoothstep(-edge, edge, wave);
      const br = this.extra.branch ?? 0.35;
      if (br > 0) {
        const fine = Math.sin(phase * 3.3 + low * 5.0 + high * 2.0);
        t = clamp01(t - smoothstep(0.10, 0.50, fine) * br * t * t);
      }
      const c = ramp3(this.c1, this.c2, this.c3, t);
      const fib = this.extra.fiber ?? 0.26;
      const sh = 1 + (fbm3(s * 42, a * 42, b * 42, sd + 200, 2) - 0.5) * fib;
      return enhance([c[0] * sh, c[1] * sh, c[2] * sh], 1.15);
    }

    if (this.kind === 'doppler') {
      // 多普勒：**深色底 + 明亮的漩涡云带**（像液体/星云流动），不是规则条纹。
      // 关键用「域扭曲湍流」(domain-warped fbm)：先用两组噪声偏移采样坐标，
      // 再取噪声 —— 得到有机的流动云团。此前用正弦叠加做相位，`a*f*2`
      // 让相位随刀身宽度跑 8 个周期 → 渲染成了竖条码（错得最离谱的一次）。
      const sArc = this.arcAt(s);
      // ① 低频湍流：大块云团
      const n1 = fbm3(s * 1.8, a * 1.8, b * 1.8, sd, 4);
      // ② 域扭曲：两组低频噪声当偏移量，让云团"流动"起来
      const wx = (fbm3(s * 1.5 + 3.1, a * 1.5, b * 1.5, sd + 77, 3) - 0.5) * 1.8;
      const wy = (fbm3(s * 1.5, a * 1.5 + 5.7, b * 1.5, sd + 133, 3) - 0.5) * 1.8;
      const n2 = fbm3(s * 2.1 + wx, a * 2.1 + wy, b * 2.1, sd + 200, 4);
      // ③ 相位：湍流主导 + 沿刀身缓慢漂移 + 轻微极角漩涡
      // warpAmp / phaseOff 来自用户参数（方案 §17/§19 的 Warp 与 Phase）
      const warpAmp = this.extra.warpExtra ?? 1.0;
      const phaseOff = this.extra.phase ?? 0;
      const swirl = Math.atan2(a - 0.5, sArc - 0.5) * 0.10 * warpAmp;
      const phase = (n1 * 0.5 + n2 * 0.5) * warpAmp + sArc * 0.55 + swirl + phaseOff;
      // ④ 宽色带：整刀 2~3 条有机宽带（不是细密条纹）
      const t = 0.5 + 0.5 * Math.sin(phase * Math.PI * 2);
      const w = smoothstep(0.30, 0.72, t);
      // ⑤ 配色：c1 深底 掺 c3 增层次，c2 作亮带
      const base = [
        this.c1[0] * 0.65 + this.c3[0] * 0.35,
        this.c1[1] * 0.65 + this.c3[1] * 0.35,
        this.c1[2] * 0.65 + this.c3[2] * 0.35,
      ];
      const col = [
        base[0] + (this.c2[0] - base[0]) * w,
        base[1] + (this.c2[1] - base[1]) * w,
        base[2] + (this.c2[2] - base[2]) * w,
      ];
      return enhance(col, 1.15);
    }

    return this.c1.slice();
  }
}

/* ---------------------------------------------------------------- 法线层 */

/**
 * 从花纹明度场生成各向异性法线贴图（拉丝质感）。
 * 做法：把花纹 RGB 转成灰度高度场 → 沿「拉痕方向」求偏导 → 编码到 normalMap。
 * 拉痕各向异性：沿刀身（u）方向频率高、横向（v）频率低，模拟金属拉丝/磨痕。
 * 返回 RGBA Uint8ClampedArray（normalMap 约定：R=x, G=y, B=z，平面=(128,128,255)）。
 */
function generateNormal(color, size, mask, { strength = 0.7, aniso = 2.5 } = {}) {
  const W = size, H = size;
  const out = new Uint8ClampedArray(W * H * 4);
  const lum = (o4) => (color[o4] * 0.2126 + color[o4 + 1] * 0.7152 + color[o4 + 2] * 0.0722) / 255;
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const o = y * W + x;
      if (!mask[o]) {
        // 未覆盖区 = 平面法线
        const o4 = o * 4;
        out[o4] = 128; out[o4 + 1] = 128; out[o4 + 2] = 255; out[o4 + 3] = 255;
        continue;
      }
      const o4 = o * 4;
      const cx = (x + 1 < W && mask[o + 1]) ? lum((o + 1) * 4) : lum(o4);
      const cy = (y + 1 < H && mask[o + W]) ? lum((o + W) * 4) : lum(o4);
      const dx = (cx - lum(o4)) * strength * aniso;   // u 方向（沿刀身，拉痕高频）
      const dy = (cy - lum(o4)) * strength;           // v 方向（横向低频）
      // 归一化切平面法线 (−dx, −dy, 1) → RGB
      const nz = 1 / Math.sqrt(dx * dx + dy * dy + 1);
      out[o4] = Math.round((-dx * nz) * 127 + 128);
      out[o4 + 1] = Math.round((-dy * nz) * 127 + 128);
      out[o4 + 2] = Math.round(nz * 255);
      out[o4 + 3] = 255;
    }
  }
  return out;
}

/* ---------------------------------------------------------------- 光栅化 */

function makeSampler(img) {
  if (!img || !img.data) return null;
  const { w, h, data } = img;
  return function (u, v) {
    const x = Math.min(w - 1, Math.max(0, Math.floor(clamp01(u) * w)));
    const y = Math.min(h - 1, Math.max(0, Math.floor(clamp01(v) * h)));
    const o = (y * w + x) * 4;
    return [data[o] / 255, data[o + 1] / 255, data[o + 2] / 255];
  };
}

/**
 * ORM 白区的连通域过滤：metalness=1 的不只有刀身，还有刀柄上的金属小件
 * （尾钉、快挂扣等）。小件会把刀身 s 范围拉偏（渐变被压缩）、还会被误涂花纹。
 * 做法：对白区做 flood fill，面积 ≥ 主岛 8% 的连通域才算刀身，其余当刀柄。
 * 返回 null 表示无法分析（无 ORM），调用方按全刀身兜底。
 */
function bladeDomainMask(orm, minRatio = 0.08) {
  if (!orm || !orm.data) return null;
  const { w, h, data } = orm;
  const n = w * h;
  const white = new Uint8Array(n);
  let whiteCount = 0;
  for (let i = 0; i < n; i++) {
    if (data[i * 4 + 2] > 128) { white[i] = 1; whiteCount++; }
  }
  if (!whiteCount || whiteCount === n) return null;
  const label = new Int32Array(n);
  const queue = new Int32Array(n);
  const areas = [0];
  let cur = 0;
  for (let start = 0; start < n; start++) {
    if (!white[start] || label[start]) continue;
    cur++;
    let head = 0, tail = 0, area = 0;
    queue[tail++] = start;
    label[start] = cur;
    while (head < tail) {
      const o = queue[head++];
      area++;
      const x = o % w, y = (o / w) | 0;
      if (x > 0 && white[o - 1] && !label[o - 1]) { label[o - 1] = cur; queue[tail++] = o - 1; }
      if (x < w - 1 && white[o + 1] && !label[o + 1]) { label[o + 1] = cur; queue[tail++] = o + 1; }
      if (y > 0 && white[o - w] && !label[o - w]) { label[o - w] = cur; queue[tail++] = o - w; }
      if (y < h - 1 && white[o + w] && !label[o + w]) { label[o + w] = cur; queue[tail++] = o + w; }
    }
    areas.push(area);
  }
  const maxArea = Math.max.apply(null, areas);
  const keep = new Uint8Array(cur + 1);
  let kept = 0;
  for (let i = 1; i <= cur; i++) {
    if (areas[i] >= maxArea * minRatio) { keep[i] = 1; kept++; }
  }
  return { label, keep, w, h, domains: cur, kept };
}

/**
 * 生成 atlas。
 * @param {object} mesh  {positions, normals, uvs, index} TypedArray
 * @param {object} maps  {orm: 像素源|null, baseColor: 像素源|null}
 * @param {object} spec  皮肤花纹配方（见 skins.js）
 * @param {object} opts  {size, handleTone, fallbackHandle, bladeGain, dilate, targetLum}
 * @returns {{color, metal, mask, stats}}
 */
function generate(mesh, maps, spec, opts) {
  const size = opts.size || 1024;
  const W = size, H = size;
  const positions = mesh.positions;
  const uvs = mesh.uvs;
  const index = mesh.index;

  const ormSampler = makeSampler(maps.orm);
  const baseSampler = makeSampler(maps.baseColor);
  const dom = bladeDomainMask(maps.orm);
  const ormW = dom ? dom.w : 0, ormH = dom ? dom.h : 0;
  const ormB = (u, v) => {
    if (!ormSampler) return 1;
    const c = ormSampler(u, v);
    if (c[2] < 0.5) return 0;
    // 连通域过滤：金属小件不算刀身（当刀柄处理，保留原版观感）
    if (dom) {
      const x = Math.min(ormW - 1, Math.floor(u * ormW));
      const y = Math.min(ormH - 1, Math.floor(v * ormH));
      if (!dom.keep[dom.label[y * ormW + x]]) return 0;
    }
    return c[2];
  };

  const frame = buildFrame(mesh, ormB);
  const pattern = new Pattern(spec, frame);
  // 刀柄材质（可选）：程序化纹理，烘焙进 atlas 的刀柄区域
  const hm = opts.handleMaterial;
  const handlePat = hm && HANDLE_KINDS[hm.kind]
    ? new Pattern({ kind: hm.kind, seed: hm.seed ?? 11, freq: 1,
                     c1: '#808080', c2: '#808080', c3: '#808080' }, frame)
    : null;

  const color = new Uint8ClampedArray(W * H * 4);
  const metal = new Uint8ClampedArray(W * H * 4);
  const mask = new Uint8Array(W * H);          // 0 未覆盖 1 刀身 2 刀柄
  const tone = opts.handleTone || { gain: 1, tint: [1, 1, 1], desat: 0 };
  const fb = opts.fallbackHandle || [0.18, 0.19, 0.21];

  // 加权累加缓冲：UV 岛重叠区 = 两侧花纹的混合，而不是后写覆盖
  const accC = new Float32Array(W * H * 3);
  const accM = new Float32Array(W * H * 3);
  const accW = new Float32Array(W * H);
  const accBW = new Float32Array(W * H);
  const accS = new Float32Array(W * H);    // 长轴归一化位置（用于三区域细分：刀身/护手+尾部/刀柄）

  for (let f = 0; f < index.length; f += 3) {
    const i0 = index[f], i1 = index[f + 1], i2 = index[f + 2];
    const u0 = uvs[i0 * 2], v0 = uvs[i0 * 2 + 1];
    const u1 = uvs[i1 * 2], v1 = uvs[i1 * 2 + 1];
    const u2 = uvs[i2 * 2], v2 = uvs[i2 * 2 + 1];
    const x0 = u0 * W, y0 = v0 * H;
    const x1 = u1 * W, y1 = v1 * H;
    const x2 = u2 * W, y2 = v2 * H;
    const area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
    if (Math.abs(area) < 1e-9) continue;
    const inv = 1 / area;

    const minx = Math.max(0, Math.floor(Math.min(x0, x1, x2)));
    const maxx = Math.min(W - 1, Math.ceil(Math.max(x0, x1, x2)));
    const miny = Math.max(0, Math.floor(Math.min(y0, y1, y2)));
    const maxy = Math.min(H - 1, Math.ceil(Math.max(y0, y1, y2)));

    for (let py = miny; py <= maxy; py++) {
      const cy = py + 0.5;
      for (let px = minx; px <= maxx; px++) {
        const cx = px + 0.5;
        let w0 = ((x1 - cx) * (y2 - cy) - (x2 - cx) * (y1 - cy)) * inv;
        let w1 = ((x2 - cx) * (y0 - cy) - (x0 - cx) * (y2 - cy)) * inv;
        let w2 = 1 - w0 - w1;
        if (w0 < -0.02 || w1 < -0.02 || w2 < -0.02) continue;
        w0 = clamp01(w0); w1 = clamp01(w1); w2 = clamp01(w2);

        const vx = positions[i0 * 3] * w0 + positions[i1 * 3] * w1 + positions[i2 * 3] * w2;
        const vy = positions[i0 * 3 + 1] * w0 + positions[i1 * 3 + 1] * w1 + positions[i2 * 3 + 1] * w2;
        const vz = positions[i0 * 3 + 2] * w0 + positions[i1 * 3 + 2] * w1 + positions[i2 * 3 + 2] * w2;
        const pu = u0 * w0 + u1 * w1 + u2 * w2;
        const pv = v0 * w0 + v1 * w1 + v2 * w2;

        // 离群金属件（s 在主刀身区间外）强制按刀柄处理
        const vAx = frame.axisIdx === 0 ? vx : frame.axisIdx === 1 ? vy : vz;
        const sRaw = (vAx - frame.origin[frame.axisIdx]) / frame.span;
        // 回退到「三层体系后」的遮罩规则：ORM 金属度 + 离群金属件（sKeep）判刀柄。
        // （"整刀铺皮肤 + 原皮暗区"的分层方案已撤回，观感不符预期）
        // ⚠ 与 aRegion 顶点属性用**同一套边界**（js/regions.js）。
        //   此前烘焙用 ORM+长轴区间、shader 用位置边界，两套不一致 →
        //   夹缝区域既不在烘焙的刀身区内、也不在 shader 的护手/刀柄区内
        //   → 显示模型原贴图 = 一道"白块"。
        const rg = spec.region || { bladeStart: frame.sKeepLo };
        // ⚠ 切割位置必须与 engine._buildRegionAttribute 的 t 公式一致（含倾角投影），
        //    否则图案边界（烘焙）与 aRegion 顶点属性错位。angle=0 时退化为纯长轴，行为不变。
        let tCut = sRaw;
        const angleRad = (Number(rg.angle) || 0) * Math.PI / 180;
        if (angleRad !== 0) {
          const vA2 = frame.aIdx === 0 ? vx : frame.aIdx === 1 ? vy : vz;
          const tAx2 = (vA2 - frame.origin[frame.aIdx]) / Math.max(frame.span2 || 1e-6, 1e-6);
          tCut = sRaw * Math.cos(angleRad) + tAx2 * Math.sin(angleRad);
          tCut = Math.max(0, Math.min(1, tCut));
        }
        // 刀身 mask：主体 + 线外浅铺，**边界整体往柄侧外扩 PATTERN_EXTEND**。
        // ⚠ 为什么要外扩：花纹是「花纹色 ←→ 刀柄底色(模型亮金属灰)」插值出来的，
        //   过渡带若压在可见交界线上，会把花纹冲淡成一条淡白灰（用户报的"链接线发白"）。
        //   外扩后，可见交界处 atlas 已是满强度花纹，过渡带被推进到刀柄质感占主导处并被盖掉。
        // ⚠ engine 顶点权重侧的边界仍用 bladeStart（不外扩）——两侧故意错开 PATTERN_EXTEND，
        //   露出的那一点花纹正是 SKIRT/BLEED 想做的"低透明度超出"。
        const FEATHER = (K3D.regions && K3D.regions.FEATHER) || 0.012;
        const SKIRT = (K3D.regions && Number(K3D.regions.SKIRT)) || 0.05;
        const BLEED = (K3D.regions && K3D.regions.BLEED != null) ? Number(K3D.regions.BLEED) : 0.35;
        const EXT = (K3D.regions && Number(K3D.regions.PATTERN_EXTEND)) || 0;
        const bsAtlas = rg.bladeStart - EXT;
        const bwCore = smoothstep(bsAtlas - FEATHER, bsAtlas + FEATHER, tCut);
        const bwTail = BLEED * smoothstep(bsAtlas - SKIRT, bsAtlas + FEATHER, tCut);
        const bw = Math.max(bwCore, bwTail);

        // 刀身：3D 花纹；刀柄：模型自带贴图 × 皮肤暗色调
        // ⚠ 花纹 pc 与原版采样必须同单位（0..255）：此前 oc 是 0..1，
        //   bw=0 时 r=oc≈0 → 刀柄整片黑
        const pc = pattern.at(vx, vy, vz);
        const det = pattern.detailAt(vx, vy, vz);
        const oc = baseSampler ? baseSampler(pu, pv) : fb;
        // ── 非刀身区域高光压缩（必须与 js/material.js 的 HLC_CEIL / HLC_K 一致）──
        // 护手/刀柄底色来自模型自带的亮金属，不压就会在皮肤旁边读作惨白。
        // 只作用于刀柄侧底色（hr/hg/hb），刀身花纹（pc）不动。
        const HLC_CEIL = 0.42, HLC_K = 0.45;
        const hlc = (x) => (x <= HLC_CEIL ? x : HLC_CEIL + (x - HLC_CEIL) * HLC_K);
        let hr = hlc(oc[0]) * 255, hg = hlc(oc[1]) * 255, hb = hlc(oc[2]) * 255;
        if (handlePat) {
          // 刀柄材质纹理（灰度结构）代替模型贴图；再混入一点模型贴图的微观明暗，避免死板
          const hv = handlePat.at(vx, vy, vz);
          const md = (oc[0] + oc[1] + oc[2]) / 3;
          const k = 0.86 + 0.28 * md;
          hr = hv[0] * k; hg = hv[1] * k; hb = hv[2] * k;
        }
        if (tone.desat > 0) {
          const l = hr * 0.2126 + hg * 0.7152 + hb * 0.0722;
          hr = lerp(hr, l, tone.desat);
          hg = lerp(hg, l, tone.desat);
          hb = lerp(hb, l, tone.desat);
        }
        hr = hr * tone.tint[0] * tone.gain;
        hg = hg * tone.tint[1] * tone.gain;
        hb = hb * tone.tint[2] * tone.gain;

        // 细节层只作用在刀身（花纹），刀柄保持原版贴图的微观结构
        const pr = pc[0] * det, pg = pc[1] * det, pb = pc[2] * det;
        const r = hr + (pr - hr) * bw;
        const g = hg + (pg - hg) * bw;
        const bl = hb + (pb - hb) * bw;
        // 金属度：CS2「二元金属度规则」—— 金属件保持高 metalness（近 1.0），
        // 花纹暗部只轻微下压（0.82~1.0）保留层次，别掉到中间值（有光照伪影 + 发闷）；
        // 刀柄 metalness 低（非金属配件）
        // ⚠ 金属度只跟**主体**（bwCore）走，不跟浅铺尾巴：CS2 的"二元金属度规则"要求金属件近 1.0、
        //   非金属件近 0.12，中间值会有光照伪影 + 发闷。浅铺只改颜色、不改金属度。
        const mv = (0.12 + 0.88 * bwCore) * (0.82 + 0.18 * r / 255) * 255;

        const o = py * W + px;
        accC[o * 3] += r; accC[o * 3 + 1] += g; accC[o * 3 + 2] += bl;
        accM[o * 3] += mv; accM[o * 3 + 1] += mv; accM[o * 3 + 2] += mv;
        accW[o] += 1;
        accBW[o] += bw;
        accS[o] += sRaw;
        mask[o] = 1;   // 先标记覆盖，最后按平均 bw 细分刀身/刀柄
      }
    }
  }

  // 归一化累加 → 最终颜色；按平均 bw 细分刀身/刀柄
  for (let o = 0; o < W * H; o++) {
    const w = accW[o];
    if (!w) continue;
    const bw = accBW[o] / w;
    const o3 = o * 3, o4 = o * 4;
    color[o4] = accC[o3] / w;
    color[o4 + 1] = accC[o3 + 1] / w;
    color[o4 + 2] = accC[o3 + 2] / w;
    // ── 粗糙度变体（方案 v2 P4）：刀身 pixel A 通道编码 pattern roughness
    //   亮带抛光（A=255）、暗带磨砂（A→0），按 patternRough 强度调制。
    //   刀柄/护手区域：A 保留 255（shader 侧用 uHandleRoughness，不走此处）。
    if (opts.patternRough && opts.patternRough > 0) {
      const lum = color[o4] * 0.2126 + color[o4 + 1] * 0.7152 + color[o4 + 2] * 0.0722;
      const raw = clamp01(lum / 255);
      // smoothstep 软化过渡，避免硬边；strength 控制 modulation 幅度
      const variation = smoothstep(0.25, 0.75, raw) * opts.patternRough;
      color[o4 + 3] = Math.round(255 * (1 - variation));
    } else {
      color[o4 + 3] = 255;
    }
    // ── 三区域 Mask（文档 §3/§5）：R = 刀柄 / G = 护手+尾部 / B = 金属度 ──
    // 刀身 = 非刀柄区域；护手+尾部 = 紧邻刀根的一小段（占刀身长的 12%）。
    // G 通道原本就空闲（three 的 metalnessMap 只读 B、roughness 用模型自带 ORM），
    // 所以三区域可以零额外贴图、零额外显存地塞进同一张图。
    // ⚠ 不用 A 通道：canvas 的 alpha 预乘会把 A=0 的像素 RGB 清零（踩过的坑）。
    const sAvg = accS[o] / w;
    const isHandle = bw < 0.5;
    const guardBand = Math.max(0.02, (frame.sKeepHi - frame.sKeepLo) * 0.12);
    const inGuardBand = sAvg >= (frame.sKeepLo - guardBand) && sAvg < frame.sKeepLo;
    const isGuard = isHandle && inGuardBand;
    const isHandleRegion = isHandle && !inGuardBand;
    metal[o4] = isHandleRegion ? 255 : 0;
    metal[o4 + 1] = isGuard ? 255 : 0;
    metal[o4 + 2] = accM[o3 + 2] / w;
    metal[o4 + 3] = 255;
    mask[o] = bw > 0.5 ? 1 : 2;
  }

  // 刀身亮度归一化：金属 albedo 应为 180–250。
  // ⚠ 用「gamma 提亮」而不是线性 gain —— 线性 gain 会把亮端乘爆成纯白
  //   （fade 的粉色 240×1.81 → 255，刀尖变白）。gamma 只抬暗部、不动亮部。
  const targetLum = opts.targetLum ?? 196;
  let sum = 0, n = 0;
  for (let o = 0; o < W * H; o++) {
    if (mask[o] !== 1) continue;
    const o4 = o * 4;
    sum += color[o4] * 0.2126 + color[o4 + 1] * 0.7152 + color[o4 + 2] * 0.0722;
    n++;
  }
  let gain = 1;
  if (n > 0) {
    const avg = sum / n;
    gain = Math.min(2.4, Math.max(0.85, targetLum / Math.max(avg, 1)));
    const need = Math.abs(gain - 1) > 0.02;
    if (need) {
      // gamma 解：255·(avg/255)^γ = target → γ = ln(target/255)/ln(avg/255)
      const g = Math.log(targetLum / 255) / Math.log(Math.min(avg, 254) / 255);
      const gam = Math.min(2.2, Math.max(0.55, g));
      const lut = new Uint8ClampedArray(256);
      for (let i = 0; i < 256; i++) lut[i] = 255 * Math.pow(i / 255, gam);
      for (let o = 0; o < W * H; o++) {
        if (mask[o] !== 1) continue;
        const o4 = o * 4;
        color[o4] = lut[color[o4]];
        color[o4 + 1] = lut[color[o4 + 1]];
        color[o4 + 2] = lut[color[o4 + 2]];
      }
    }
  }

  // 膨胀：沿未覆盖像素的边界推进，填掉 UV 岛边缘的缝
  const dilate = opts.dilate ?? 2;
  if (dilate > 0) {
    let cand = [];
    for (let o = 0; o < W * H; o++) if (!mask[o]) cand.push(o);
    for (let it = 0; it < dilate && cand.length; it++) {
      const snap = mask.slice();
      const nxt = [];
      for (const o of cand) {
        if (mask[o]) continue;
        const py = (o / W) | 0, px = o - py * W;
        let hit = -1;
        if (px > 0 && snap[o - 1]) hit = o - 1;
        else if (px < W - 1 && snap[o + 1]) hit = o + 1;
        else if (py > 0 && snap[o - W]) hit = o - W;
        else if (py < H - 1 && snap[o + W]) hit = o + W;
        if (hit < 0) { nxt.push(o); continue; }
        const o4 = o * 4, h4 = hit * 4;
        color[o4] = color[h4]; color[o4 + 1] = color[h4 + 1];
        color[o4 + 2] = color[h4 + 2]; color[o4 + 3] = 255;
        metal[o4] = metal[h4]; metal[o4 + 1] = metal[h4 + 1];
        metal[o4 + 2] = metal[h4 + 2]; metal[o4 + 3] = metal[h4 + 3];   // A=遮罩，随膨胀一起复制
        mask[o] = snap[hit];
        if (px > 0 && !mask[o - 1]) nxt.push(o - 1);
        if (px < W - 1 && !mask[o + 1]) nxt.push(o + 1);
        if (py > 0 && !mask[o - W]) nxt.push(o - W);
        if (py < H - 1 && !mask[o + W]) nxt.push(o + W);
      }
      cand = nxt;
    }
  }

  // 生成法线贴图（基于花纹明度场的各向异性拉丝）。
  // ⚠ 振幅要给足：之前 strength=0.24 时法线偏转不到 1°，等于一张平面法线，
  //   导致材质侧「法线强度」滑块缩放后毫无视觉变化。给到 ~2.2 才有可见的拉丝起伏。
  const normal = opts.normal !== false && mask.some((v) => v === 1)
    ? generateNormal(color, W, mask, {
        strength: opts.normalStrength ?? 2.2,
        aniso: opts.aniso ?? 1.8,
      })
    : null;

  let blade = 0, covered = 0;
  for (let o = 0; o < mask.length; o++) {
    if (mask[o]) { covered++; if (mask[o] === 1) blade++; }
  }
  return {
    color, metal, mask, normal,
    stats: {
      size, covered: covered / (W * H),
      bladeRatio: covered ? blade / covered : 0,
      axis: ['x', 'y', 'z'][frame.axis.findIndex((v) => v === 1)],
      bladeGain: +gain.toFixed(3),
      bladeS: frame.stats.sRange,
      bladeTris: frame.stats.bladeTris,
    },
  };
}

/* ---------------------------------------------------------------- 导出 */

K3D.noise = { hash3, noise3, fbm3, smoothstep, clamp01 };
K3D.Pattern = Pattern;
K3D.Atlas = { generate, buildFrame, bladeDomainMask };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { K3D, Pattern, Atlas: K3D.Atlas, noise: K3D.noise, hexRgb };
}
})(typeof window !== 'undefined' ? window : globalThis);
