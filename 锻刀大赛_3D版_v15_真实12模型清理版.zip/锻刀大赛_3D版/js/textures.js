/**
 * Texture 定义表（《SkinShader 完整实现方案 v2》§12 / §40）
 *
 * Skin = 皮肤工艺（材质/区域/磨损/引用哪个 Texture）
 * Texture = 图案内容（生成器 + 参数 + 配色）
 * 两者解耦：一个 Texture 可以被多个 Skin 复用，Skin 不再内联图案。
 * 目前由 tools/split_textures.js 从原 skins.js 自动抽出，id 为 `<skinId>_tex`；
 * 之后可以按工艺归并共用（例如多个 patina 皮共用同一张纹理）。
 */
'use strict';

(function (global) {
const K3D = (global.K3D = global.K3D || {});
  const TEXTURES = [
    { id: 'blue_steel_tex', name: 'blue_steel', kind: 'marble', c1: '#c8ced6', c2: '#6d7b8c', c3: '#2f3a47', freq: 6, seed: 3 },
    { id: 'case_hardened_tex', name: 'case_hardened', kind: 'marble', c1: '#4a6fa5', c2: '#8b6914', c3: '#1a1a2e', freq: 3, seed: 5 },
    { id: 'slaughter_tex', name: 'slaughter', kind: 'marble', c1: '#c23b2b', c2: '#8f1d1d', c3: '#2a0f0c', freq: 5, seed: 9 },
    { id: 'fade_tex', name: 'fade', kind: 'linear', bend: 0.10, contrast: 1.0, c1: '#4a1f7a', c2: '#c94d9e', c3: '#e0663a', c4: '#f5c63f', freq: 1, seed: 7 },
    { id: 'damascus_tex', name: 'damascus', kind: 'marble', vein: true, veinFreq: 9, contrast: 1.25, sat: 1.05, patternRough: 0.55, c1: '#eef2f6', c2: '#9aa1a8', c3: '#3f464e', freq: 9, seed: 11 },
    { id: 'autotronic_tex', name: 'autotronic', kind: 'marble', c1: '#d5d8db', c2: '#8e9093', c3: '#a8302f', freq: 5, seed: 11 },
    { id: 'doppler_tex', name: 'doppler', kind: 'doppler', c1: '#0b1f5c', c2: '#2f6fe0', c3: '#0a1030', freq: 4, seed: 11 },
    { id: 'doppler_purple_tex', name: 'doppler_purple', kind: 'doppler', c1: '#2a1a5c', c2: '#c56292', c3: '#1a3a8c', freq: 4, seed: 11 },
    { id: 'marble_fade_tex', name: 'marble_fade', kind: 'marble', vein: true, veinFreq: 5, contrast: 1.15, sat: 1.35, c1: '#eae6de', c2: '#3f5fae', c3: '#bf4a2f', freq: 4, seed: 11 },
    { id: 'ultraviolet_tex', name: 'ultraviolet', kind: 'marble', c1: '#6a3f88', c2: '#3a2050', c3: '#150c1e', freq: 4, seed: 11 },
    { id: 'black_steel_tex', name: 'black_steel', kind: 'solid', c1: '#22252b', c2: '#22252b', c3: '#22252b', freq: 1, seed: 3 },
    { id: 'silver_steel_tex', name: 'silver_steel', kind: 'solid', c1: '#c9ced6', c2: '#c9ced6', c3: '#c9ced6', freq: 1, seed: 4 },
    { id: 'gold_tex', name: 'gold', kind: 'solid', c1: '#d8b04a', c2: '#d8b04a', c3: '#d8b04a', freq: 1, seed: 5 },
  ];

  K3D.textures = {
    TEXTURES,
    get: (id) => TEXTURES.find((t) => t.id === id) || null,
    /** 取可直接喂给 K3D.Atlas.generate 的 pattern spec（去掉 id/name 这类元字段） */
    patternOf(id) {
      const t = K3D.textures.get(id);
      if (!t) return null;
      const { id: _i, name: _n, ...spec } = t;
      return spec;
    },
  };
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = K3D.textures;
  }
})(typeof window !== 'undefined' ? window : globalThis);
