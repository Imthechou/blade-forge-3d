/**
 * Atlas 持久化存储（IndexedDB）
 *
 * 背景：atlas 烘焙（1024² × 3 通道）约 770ms/次（SwiftShader 软渲染；真机更快但仍是秒级）。
 * 每次刷新页面、每次切刀重新烘焙的代价都在这。烘焙结果只由
 *   (knifeId, skinId, seed, 刀柄材质, 纹理参数, 区域边界) 决定 —— 是纯函数。
 * 所以把烘焙结果存进 IndexedDB：
 *   · 第二次打开页面（同刀同皮肤）直接命中 → 0ms 烘焙
 *   · 后台预热时命中 → 秒出
 *
 * 失效策略：ver（公式版本号）。shader / regions / skins 的烘焙公式改动后，
 * 把 K3D.AtlasStore.VER 加 1，旧记录自动作废（读时比对 ver）。
 *
 * 存储量估算：每条约 12MB（color/metal/normal 各 1024²×4），12 刀 ≈ 144MB，
 * 桌面端 IDB 配额（磁盘 60%）完全放得下；移动端注意。写入失败（配额/隐私模式）
 * 静默降级 —— 性能优化不该反过来弄挂功能。
 */
'use strict';

(function attach(K3D) {
  const DB_NAME = 'k3d_atlas_v1';
  const STORE = 'atlas';
  // ⚠ 公式版本号：atlas.js / regions.js（SKIRT/BLEED/PATTERN_EXTEND）/ skins 烘焙相关改动后 +1
  const VER = 1;

  let _openPromise = null;
  function open() {
    if (_openPromise) return _openPromise;
    _openPromise = new Promise((resolve, reject) => {
      if (!window.indexedDB) return reject(new Error('indexedDB 不可用'));
      const rq = indexedDB.open(DB_NAME, 1);
      rq.onupgradeneeded = () => {
        if (!rq.result.objectStoreNames.contains(STORE)) {
          rq.result.createObjectStore(STORE, { keyPath: 'key' });
        }
      };
      rq.onsuccess = () => resolve(rq.result);
      rq.onerror = () => reject(rq.error || new Error('IDB open 失败'));
    });
    return _openPromise;
  }

  /** 读一条；任何异常（隐私模式/配额/关闭 IDB）都返回 null，不抛 */
  async function get(storedKey) {
    try {
      const db = await open();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, 'readonly');
        const rq = tx.objectStore(STORE).get(storedKey);
        rq.onsuccess = () => resolve(rq.result || null);
        rq.onerror = () => reject(rq.error);
      });
    } catch (e) { return null; }
  }

  /** 写一条（fire-and-forget 安全） */
  async function set(storedKey, record) {
    try {
      const db = await open();
      await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, 'readwrite');
        tx.objectStore(STORE).put(Object.assign({ key: storedKey, ver: VER }, record));
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
      return true;
    } catch (e) {
      console.warn('[atlasStore] IDB 写入失败（降级为内存缓存）：', e && e.message);
      return false;
    }
  }

  K3D.AtlasStore = { VER, get, set };
}(window.K3D = window.K3D || {}));
