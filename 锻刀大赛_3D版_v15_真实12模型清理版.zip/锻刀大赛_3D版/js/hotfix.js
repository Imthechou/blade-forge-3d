/* Blade Forge mobile 3D hotfix.
 *
 * v12: 不再强制 MeshPhysicalMaterial 使用 GLSL1。
 * Three.js r169 + WebGL2 应使用引擎自己的 shader 版本协商；之前强制
 * GLSL1 会让部分 iOS/WebGL2 设备上的自定义 BladeSkin 程序无法正常编译，
 * 结果就是“模型加载了但刀不显示”。
 *
 * 模型的居中、统一尺寸和朝向全部由 Viewer.setModel() 负责。
 */
(function (global) {
  'use strict';
  const THREE = global.THREE;
  const K3D = global.K3D;
  if (!THREE || !K3D) return;
  // Intentionally no shader monkey-patch here.
})(window);
