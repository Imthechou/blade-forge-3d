/* Knife3D · app.js
 * UI：竖版移动优先。顶部刀型条 / 4:5 舞台 / 参数面板（含内嵌皮肤选择器）。
 * 原生 JS，无框架。
 */
(function (global) {
'use strict';
const K3D = (global.K3D = global.K3D || {});
const $ = (sel) => document.querySelector(sel);

const WEAR_PRESETS = [
  ['崭新出厂', 0.0], ['略有磨损', 0.15], ['久经沙场', 0.38], ['破损不堪', 0.66], ['战痕累累', 1.0],
];

const TINT_SWATCHES = ['#ffffff', '#8e99a6', '#6f7d92', '#7d8694', '#5d6068', '#4a2a48', '#3d2c50', '#6d5a3a', '#7a4038'];

const state = {
  knifeId: null,
  skinId: 'fade',          // 向后兼容：当前完整皮肤 ID
  finishId: 'fade',        // 新：当前选中的工艺（patina/fade/anodized_multicolored/solid）
  textureId: null,         // 纹理覆盖（null = 用工艺默认）
  params: {},
  autoRotate: false,
  exposure: 1.15,
  loading: false,
  statusText: '',
  // 区域边界覆盖（null = 用 regions.js 默认值）
  // 持久化到 localStorage key: k3d_regions
  regionBladeStart: null,
  regionGuardStart: null,
  regionAngle: 0,       // 切割平面倾斜角度（度），0=垂直于长轴
  _bsSlider: null,
  _gsSlider: null,
  _baSlider: null,      // 角度滑块
  _bsLabel: null,
  _gsLabel: null,
  _baLabel: null,
};

/** 区域边界持久化：按 knifeId 存到 localStorage，切换刀型时自动恢复。 */
const REGION_LS_KEY = 'k3d_regions';
function _loadRegions() {
  try {
    const raw = localStorage.getItem(REGION_LS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}
function _saveRegions() {
  try { localStorage.setItem(REGION_LS_KEY, JSON.stringify(_savedRegions)); } catch {}
}
// 每次打开页面时从 localStorage 恢复（切到某刀型时由 _restoreRegionState 写入 overrideMap）
const _savedRegions = _loadRegions();

let engine = null;
let viewer = null;
const thumbCache = new Map();     // knifeId -> dataURL

/* ---------------------------------------------------------------- 工具 */

/** 让横滚条支持滚轮转横向 + 鼠标拖拽（触屏本来就能滑）。 */
function enableStripScroll(el) {
  if (!el) return;
  const overflow = () => el.scrollWidth - el.clientWidth > 2;

  el.addEventListener('wheel', (e) => {
    if (!overflow()) return;
    // 垂直滚轮转成横向滚动；已到两端则交回页面
    const delta = Math.abs(e.deltaY) > Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
    const before = el.scrollLeft;
    el.scrollLeft += delta;
    if (el.scrollLeft !== before) e.preventDefault();
  }, { passive: false });

  let dragging = false, startX = 0, startLeft = 0, moved = 0;
  el.addEventListener('pointerdown', (e) => {
    if (e.pointerType === 'touch' || !overflow()) return;
    dragging = true; moved = 0;
    startX = e.clientX;
    startLeft = el.scrollLeft;
  });
  el.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    const dx = e.clientX - startX;
    moved = Math.abs(dx);
    if (moved > 3) el.setPointerCapture(e.pointerId);
    el.scrollLeft = startLeft - dx;
  });
  const end = (e) => {
    if (!dragging) return;
    dragging = false;
    // 拖动后抑制这次 click，避免误选皮肤
    if (moved > 6) {
      el.querySelectorAll('button').forEach((b) => {
        b.addEventListener('click', (ev) => { ev.stopPropagation(); ev.preventDefault(); }, { capture: true, once: true });
      });
      setTimeout(() => el.querySelectorAll('button').forEach((b) => b.blur()), 0);
    }
  };
  el.addEventListener('pointerup', end);
  el.addEventListener('pointercancel', end);
  el.addEventListener('pointerleave', end);
}

function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
}

function setStatus(text) {
  state.statusText = text || '';
  const n = $('#status');
  if (n) n.textContent = text || '';
  n && n.classList.toggle('show', !!text);
}

/** 当前生效的完整材质参数 = 面板默认 + 皮肤默认 + 用户覆盖 */
function currentParams() {
  const skin = K3D.skins.get(state.skinId);
  const h = K3D.skins.handleOf(state.skinId);
  const g = K3D.skins.guardOf({}, h);   // 护手默认色跟随该皮肤的刀柄色调
  return {
    // patternSeed：优先用用户已设值，其次回退到 0（原版无种子）
    patternSeed: state.params.patternSeed ?? 0,
    // L3 刀柄（默认 + 皮肤配方）
    handleGain: h.gain,
    handleTint: h.tintHex,
    handleDesat: h.desat,
    handleMetalness: h.metalness,
    handleRoughness: h.roughness,
    handleReflection: h.reflection,
    handleMaterial: h.material,
    // L3 护手+尾部（区域 1，方案 v2）
    guardGain: g.gain,
    guardTint: g.tintHex,
    guardDesat: g.desat,
    guardMetalness: g.metalness,
    guardRoughness: g.roughness,
    guardReflection: g.reflection,
    // L2 刀身质感（中性默认 + 皮肤 PBR 配方）
    // 纹理参数（方案 §44）中性默认：缩放 1 / 旋转与偏移 0 = 不改变皮肤自带配方
    texScale: 1, texRotation: 0, texOffsetU: 0, texOffsetV: 0,
    fadeShift: 0, fadeSpan: 1, texWarp: 1, texPhase: 0,
    wear: 0, dirt: 0,
    ...K3D.material.MATERIAL_DEFAULTS,
    ...skin.material,
    ...state.params,
  };
}

/* ---------------------------------------------------------------- 刀型条 */

function renderKnifeStrip(knives) {
  const strip = $('#knifeStrip');
  strip.innerHTML = '';
  for (const k of knives) {
    const btn = el('button', 'knife-chip' + (k.id === state.knifeId ? ' active' : ''));
    const thumb = thumbCache.get(k.id);
    btn.innerHTML = thumb
      ? '<img class="knife-thumb" src="' + thumb + '" alt=""><span class="knife-name">' + k.name + '</span>'
      : '<span class="knife-glyph"></span><span class="knife-name">' + k.name + '</span>';
    btn.title = k.nameEn || k.name;
    btn.addEventListener('click', () => selectKnife(k.id));
    strip.appendChild(btn);
  }
}

/* ---------------------------------------------------------------- 参数面板 */

let rebakeTimer = null;
/** 纹理类参数改的是 atlas，需要重烘焙 → 防抖后走 applySkin（而非 setParams） */
function scheduleRebake() {
  clearTimeout(rebakeTimer);
  rebakeTimer = setTimeout(() => applySkin(), 260);
}

function sliderRow(label, key, min, max, step, fmt, rebake) {
  const row = el('div', 'param-row');
  const head = el('div', 'param-head');
  head.appendChild(el('span', 'param-label', label));
  const val = el('span', 'param-value', fmt(currentParams()[key]));
  head.appendChild(val);
  const input = el('input', 'slider');
  input.type = 'range';
  input.min = min; input.max = max; input.step = step;
  input.value = currentParams()[key];
  input.addEventListener('input', () => {
    const v = Number(input.value);
    state.params[key] = v;
    val.textContent = fmt(v);
    if (rebake) scheduleRebake();   // 纹理参数 → 重烘焙
    else pushParams();              // 材质参数 → 实时
  });
  row.appendChild(head);
  row.appendChild(input);
  return row;
}

function fmt2(v) { return Number(v).toFixed(2); }
function fmt0(v) { return String(Math.round(v)); }

/** 图案索引滑块：0..1000 = 8 模板 × 125 细节（CSGO pattern/index 的轻量模拟）。
 *  改种子需要重新烘焙 atlas（ensureAtlas 按 seed 缓存），所以走防抖 + applySkin，
 *  不走 pushParams（材质参数通道不重烘焙）。 */
let seedTimer = 0;
function patternRow() {
  const row = el('div', 'param-row');
  const head = el('div', 'param-head');
  head.appendChild(el('span', 'param-label', '图案索引'));
  const val = el('span', 'param-value');
  head.appendChild(val);

  const refresh = () => {
    const v = Math.max(0, Math.min(1000, Math.round(currentParams().patternSeed)));
    const tpl = K3D.patternTemplateOf(v);
    val.textContent = '模板 ' + tpl + ' · 细节 ' + (v % 125);
  };
  refresh();

  const input = el('input', 'slider');
  input.type = 'range'; input.min = 0; input.max = 1000; input.step = 1;
  input.value = currentParams().patternSeed;
  if (state.skinId === 'original') input.disabled = true;
  input.addEventListener('input', () => {
    state.params.patternSeed = Number(input.value);
    refresh();
    if (state.skinId === 'original') return;
    clearTimeout(seedTimer);
    // BladeSkin 系统内部处理 seed，不需要走旧 atlas 通道 → 直接用 applyBladeSkinNow()
    seedTimer = setTimeout(() => applyBladeSkinNow(), 50);
  });
  row.appendChild(head);
  row.appendChild(input);
  return row;
}

/** 分组标题（带「重烘焙 / 实时」角标，让用户知道改动何时生效） */
function groupHead(title, badge) {
  const h = el('div', 'group-title');
  h.appendChild(el('span', '', title));
  if (badge) h.appendChild(el('span', 'badge ' + (badge === '实时' ? 'badge-live' : 'badge-bake'), badge));
  return h;
}

/** 曝光行（L1 全局） */
function exposureRow() {
  const row = el('div', 'param-row');
  const head = el('div', 'param-head');
  head.appendChild(el('span', 'param-label', '曝光'));
  const val = el('span', 'param-value', fmt2(state.exposure));
  head.appendChild(val);
  const input = el('input', 'slider');
  input.type = 'range'; input.min = 0.5; input.max = 2; input.step = 0.01;
  input.value = state.exposure;
  input.addEventListener('input', () => {
    state.exposure = Number(input.value);
    val.textContent = fmt2(state.exposure);
    viewer.setExposure(state.exposure);
  });
  row.appendChild(head); row.appendChild(input);
  return row;
}

/** 自动旋转行（L1 全局） */
function rotateRow() {
  const row = el('div', 'param-row');
  const label = el('label', 'switch');
  const input = el('input');
  input.type = 'checkbox'; input.checked = state.autoRotate;
  input.addEventListener('change', () => {
    state.autoRotate = input.checked;
    viewer.setAutoRotate(state.autoRotate);
  });
  label.appendChild(input);
  label.appendChild(el('span', 'switch-text', '自动旋转'));
  row.appendChild(label);
  return row;
}


/* ───────────────────────────── BladeSkin 面板支撑 ───────────────────────────── */

/** 当前 BladeSkinState（懒初始化） */
function skinState() {
  if (!state.skin) state.skin = K3D.bladeSkin.makeState({});
  return state.skin;
}

/** 组合并应用（只写刀身；护手/刀柄沿用原有通道） */
function applyBladeSkinNow() {
  if (!engine || !state.knifeId || !K3D.bladeSkin) return null;
  const pack = K3D.bladeSkin.composeBladeSkin(skinState());
  engine.applyBladeSkin(state.knifeId, pack);
  state._skinPack = pack;
  return pack;
}

function selectMaterial(id) {
  skinState().materialId = id;
  renderParams();
  applyBladeSkinNow();
}
function selectTexture(id) {
  const sk = skinState();
  sk.textureId = id;
  sk.variantParams.texture = {};     // 换纹理 → 该纹理参数回到它自己的默认值
  renderParams();
  applyBladeSkinNow();
}
function selectFinish(id) {
  const sk = skinState();
  sk.finishId = id;
  sk.variantParams.finish = {};
  renderParams();
  applyBladeSkinNow();
}

/** 读某个 scope 下的参数值（用户覆盖 > 该项默认） */
function skinParamValue(scope, key) {
  const sk = skinState();
  const ov = (sk.variantParams[scope] || {})[key];
  if (ov !== undefined && ov !== null) return Number(ov);
  const def = scope === 'texture'
    ? K3D.textures12.get(sk.textureId).defaults
    : K3D.finishes12.get(sk.finishId).defaults;
  return Number(def[key] != null ? def[key] : 0);
}
function setSkinParam(scope, key, v) {
  const sk = skinState();
  if (!sk.variantParams[scope]) sk.variantParams[scope] = {};
  sk.variantParams[scope][key] = v;
}

/** 纹理/工艺参数滑块（写进 variantParams，实时应用） */
function variantSlider(label, scope, key, min, max, step, fmt) {
  const row = el('div', 'param-row');
  const head = el('div', 'param-head');
  head.appendChild(el('span', 'param-label', label));
  const val = el('span', 'param-value', fmt(skinParamValue(scope, key)));
  head.appendChild(val);
  const input = el('input', 'slider');
  input.type = 'range'; input.min = min; input.max = max; input.step = step;
  input.value = skinParamValue(scope, key);
  input.addEventListener('input', () => {
    const v = Number(input.value);
    setSkinParam(scope, key, v);
    val.textContent = fmt(v);
    applyBladeSkinNow();
  });
  row.appendChild(head); row.appendChild(input);
  return row;
}

/** 状态根参数滑块（wear / patternScale / patternRotation / patternOffset*） */
function rootSlider(label, key, min, max, step, fmt, live) {
  const sk = skinState();
  const read = () => (key === 'patternOffsetX' ? sk.patternOffset.x
    : key === 'patternOffsetY' ? sk.patternOffset.y : sk[key]);
  const write = (v) => {
    if (key === 'patternOffsetX') sk.patternOffset.x = v;
    else if (key === 'patternOffsetY') sk.patternOffset.y = v;
    else sk[key] = v;
  };
  const row = el('div', 'param-row');
  const head = el('div', 'param-head');
  head.appendChild(el('span', 'param-label', label));
  const val = el('span', 'param-value', fmt(read()));
  head.appendChild(val);
  const input = el('input', 'slider');
  input.type = 'range'; input.min = min; input.max = max; input.step = step;
  input.value = read();
  input.addEventListener('input', () => {
    const v = Number(input.value);
    write(v);
    val.textContent = fmt(v);
    if (live) applyBladeSkinNow();
  });
  row.appendChild(head); row.appendChild(input);
  return row;
}

/** Seed 行：输入框 + 随机按钮（随机种子一旦落进 state，后续完全确定性可复现） */
function seedRow() {
  const sk = skinState();
  const row = el('div', 'param-row');
  const head = el('div', 'param-head');
  head.appendChild(el('span', 'param-label', 'Seed'));
  const input = el('input', 'seed-input');
  input.type = 'number';
  input.value = String(sk.seed);
  input.addEventListener('change', () => {
    sk.seed = (Number(input.value) >>> 0) || 1;
    sk.patternSeed = null;              // 手改 seed → 花纹种子重新派生（§13）
    applyBladeSkinNow();
  });
  head.appendChild(input);
  row.appendChild(head);
  const dice = el('button', 'chip', '🎲 随机');
  dice.title = '换一个种子：雾团位置/大小、色彩相位、高光都会一起变（文档 §9.7）';
  dice.addEventListener('click', () => {
    // 这里用时间戳取一个"外部随机源"，只用来产生种子本身；
    // 一旦写进 state，之后的一切都由 seededRandom 决定 → 同 seed 必复现
    sk.seed = (Date.now() % 100000000) >>> 0;
    sk.patternSeed = null;
    input.value = String(sk.seed);
    applyBladeSkinNow();
  });
  row.appendChild(dice);
  return row;
}

function renderParams() {
  const panel = $('#params');
  panel.innerHTML = '';
  const sk = skinState();
  const tex = K3D.textures12.get(sk.textureId);
  const fin = K3D.finishes12.get(sk.finishId);

  /* ── 刀身材质（24 种，按文档 §3 的五个系分组）────────────────── */
  const matG = el('div', 'param-group');
  matG.appendChild(groupHead('刀身材质', '实时'));
  for (const g of K3D.materials24.GROUPS) {
    matG.appendChild(el('div', 'sub-title', g));
    const chips = el('div', 'chips chips-wrap');
    for (const m of K3D.materials24.byGroup(g)) {
      const btn = el('button', 'skin-chip' + (sk.materialId === m.id ? ' active' : ''));
      const sw = el('span', 'skin-swatch');
      sw.style.background = 'linear-gradient(135deg, ' + m.baseColor + ' 0%, #2b2f36 100%)';
      btn.appendChild(sw);
      btn.appendChild(el('span', 'skin-name', m.name));
      btn.title = m.id + ' ' + m.nameEn + ' · 金属 ' + m.metalness.toFixed(2)
        + ' / 粗糙 ' + m.roughness.toFixed(2) + (m.clearcoat ? ' / 清漆 ' + m.clearcoat.toFixed(2) : '');
      btn.addEventListener('click', () => selectMaterial(m.id));
      chips.appendChild(btn);
    }
    matG.appendChild(chips);
  }
  panel.appendChild(matG);

  /* ── 刀身纹理（12 种）────────────────────────────────────────── */
  const texG = el('div', 'param-group');
  texG.appendChild(groupHead('刀身纹理', '实时'));
  const texRow = el('div', 'chips chips-wrap');
  for (const t of K3D.textures12.list()) {
    const btn = el('button', 'chip' + (sk.textureId === t.id ? ' active' : ''), t.name + (t.star ? ' ★' : ''));
    btn.title = t.id + ' ' + t.nameEn + ' — ' + t.desc;
    btn.addEventListener('click', () => selectTexture(t.id));
    texRow.appendChild(btn);
  }
  texG.appendChild(texRow);
  panel.appendChild(texG);

  /* ── 工艺特效（12 种）────────────────────────────────────────── */
  const finG = el('div', 'param-group');
  finG.appendChild(groupHead('工艺特效', '实时'));
  const finRow = el('div', 'chips chips-wrap');
  for (const f of K3D.finishes12.list()) {
    const btn = el('button', 'chip' + (sk.finishId === f.id ? ' active' : ''));
    btn.textContent = f.name;
    btn.title = f.id + ' ' + f.nameEn + '（' + f.type + '）— ' + f.desc;
    btn.addEventListener('click', () => selectFinish(f.id));
    finRow.appendChild(btn);
  }
  finG.appendChild(finRow);

  /* ── 磨损（文档 §12：总 wear → 五路自动派生）──────────────────── */
  finG.appendChild(el('div', 'sub-title', '磨损'));
  finG.appendChild(rootSlider('磨损', 'wear', 0, 1, 0.01, fmt2, true));
  {
    const w = K3D.bladeSkin.wearLevels(sk.wear);
    const info = el('div', 'param-hint',
      '边缘 ' + w.edge.toFixed(2) + ' · 表面 ' + w.surface.toFixed(2) + ' · 花纹 ' + w.pattern.toFixed(2)
      + ' · 划痕 ' + w.scratch.toFixed(2) + ' · 粗糙 ' + w.roughness.toFixed(2));
    finG.appendChild(info);
  }
  panel.appendChild(finG);

  /* ── Seed 与花纹（文档 §6/§9.7/§13）──────────────────────────── */
  const seedG = el('div', 'param-group');
  seedG.appendChild(groupHead('随机花纹', '实时'));
  seedG.appendChild(seedRow());
  seedG.appendChild(rootSlider('缩放', 'patternScale', 0.3, 3, 0.01, fmt2, true));
  seedG.appendChild(rootSlider('旋转', 'patternRotation', -180, 180, 1, (v) => Math.round(v) + '°', true));
  seedG.appendChild(rootSlider('偏移 U', 'patternOffsetX', -1, 1, 0.01, fmt2, true));
  seedG.appendChild(rootSlider('偏移 V', 'patternOffsetY', -1, 1, 0.01, fmt2, true));
  panel.appendChild(seedG);

  /* ── 纹理参数（按所选纹理的 schema 动态生成）──────────────────── */
  if (tex.schema && tex.schema.length) {
    const g = el('div', 'param-group');
    g.appendChild(groupHead(tex.name + ' · 参数', '实时'));
    for (const [key, label, min, max, step] of tex.schema) {
      g.appendChild(variantSlider(label, 'texture', key, min, max, step,
        step >= 1 ? (v) => String(Math.round(v)) : fmt2));
    }
    panel.appendChild(g);
  }

  /* ── 工艺参数（按所选工艺的 schema 动态生成）──────────────────── */
  if (fin.schema && fin.schema.length) {
    const g = el('div', 'param-group');
    g.appendChild(groupHead(fin.name + ' · 参数', '实时'));
    for (const [key, label, min, max, step] of fin.schema) {
      g.appendChild(variantSlider(label, 'finish', key, min, max, step, fmt2));
    }
    panel.appendChild(g);
  }

  /* ── 刀柄（沿用原有通道与参数，行为不变）──────────────────────── */
  const handle = el('div', 'param-group');
  handle.appendChild(groupHead('刀柄', '实时'));
  const matRow = el('div', 'param-row');
  matRow.appendChild(el('div', 'param-head', '<span class="param-label">材质</span>'));
  const matChips = el('div', 'chips chips-wrap');
  const curMat = currentParams().handleMaterial;
  for (const m of K3D.skins.HANDLE_MATERIALS) {
    const c = el('button', 'chip' + (curMat === m.id ? ' active' : ''), m.name);
    c.title = m.name + '（金属' + m.metalness + ' / 粗糙' + m.roughness + '）';
    c.addEventListener('click', () => {
      state.params.handleMaterial = m.id;
      state.params.handleTint = m.tintHex;
      state.params.handleDesat = m.desat;
      state.params.handleGain = m.gain;
      state.params.handleMetalness = m.metalness;
      state.params.handleRoughness = m.roughness;
      state.params.handleReflection = m.reflection;
      renderParams();
      applySkin();          // 纹理烘焙进 atlas → 走重烘焙通道
    });
    matChips.appendChild(c);
  }
  matRow.appendChild(matChips);
  handle.appendChild(matRow);
  handle.appendChild(el('div', 'sub-title', '颜色'));
  handle.appendChild(sliderRow('亮度', 'handleGain', 0.2, 1.6, 0.01, fmt2));
  handle.appendChild(sliderRow('去饱和', 'handleDesat', 0, 1, 0.01, fmt2));
  const tintRow = el('div', 'param-row');
  tintRow.appendChild(el('div', 'param-head', '<span class="param-label">着色</span>'));
  const swatches = el('div', 'chips');
  for (const hex of TINT_SWATCHES) {
    const cur = currentParams().handleTint || '#ffffff';
    const c = el('button', 'chip swatch' + (String(cur).toLowerCase() === hex.toLowerCase() ? ' active' : ''));
    c.style.setProperty('--sw', hex);
    c.title = hex;
    c.addEventListener('click', () => {
      state.params.handleTint = hex;
      renderParams(); pushParams();
    });
    swatches.appendChild(c);
  }
  tintRow.appendChild(swatches);
  handle.appendChild(tintRow);
  handle.appendChild(el('div', 'sub-title', '质感'));
  handle.appendChild(sliderRow('金属度', 'handleMetalness', 0, 1, 0.01, fmt2));
  handle.appendChild(sliderRow('粗糙度', 'handleRoughness', 0, 1, 0.01, fmt2));
  handle.appendChild(sliderRow('反射', 'handleReflection', 0, 2, 0.01, fmt2));
  panel.appendChild(handle);

  /* ── 操作 ─────────────────────────────────────────────────────── */
  const actions = el('div', 'param-actions');
  const reset = el('button', 'action-btn reset', '↺ 重置刀身皮肤');
  reset.addEventListener('click', () => {
    state.skin = K3D.bladeSkin.makeState({});
    renderParams();
    applyBladeSkinNow();
  });
  actions.appendChild(reset);
  panel.appendChild(actions);
}

/* ---------------------------------------------------------------- 数据流 */

/** 最终生效参数 = 材质默认 + 皮肤 PBR 配方 + 用户覆盖（含刀柄 bladeMask）。
 *  ⚠ 必须合并 skin.material：否则只传用户覆盖会把皮肤的虹彩/清漆/低粗糙冲掉。
 *  刀柄走 K3D.skins.handleOf（默认 + 皮肤配方 + 用户覆盖），与刀身完全独立。 */
function effectiveParams() {
  const skin = K3D.skins.get(state.skinId);
  const p = { ...currentParams() };
  const g = K3D.skins.guardOf({
    gain: p.guardGain, tintHex: p.guardTint, desat: p.guardDesat,
    metalness: p.guardMetalness, roughness: p.guardRoughness,
    reflection: p.guardReflection,
  });
  const h = K3D.skins.handleOf(state.skinId, {
    gain: p.handleGain, tintHex: p.handleTint, desat: p.handleDesat,
    metalness: p.handleMetalness, roughness: p.handleRoughness, reflection: p.handleReflection,
  });
  p.bladeMask = {
    // 三区域系统对所有皮肤生效（原版除外 —— 原版要保留模型原样）
    active: state.skinId !== 'original',
    handleGain: h.gain,
    handleTint: h.tintHex,
    handleDesat: h.desat,
    handleMetalness: h.metalness,
    handleRoughness: h.roughness,
    handleReflection: h.reflection,
    // 区域 1：护手 + 尾部
    guardGain: g.gain,
    guardTint: g.tintHex,
    guardDesat: g.desat,
    guardMetalness: g.metalness,
    guardRoughness: g.roughness,
    guardReflection: g.reflection,
    debugMode: state.debugMode || 0,   // 0=最终 / 1=区域视图
    wear: p.wear ?? 0,                 // 磨损量（shader 里按 WearRate 磨出底材）
    dirt: p.dirt ?? 0,                 // 积垢（凹槽积垢，按几何曲率）
  };
  return p;
}

/** 材质通道：只更新 PBR uniform，不重烘焙。 */
function pushParams() {
  if (!engine || !state.knifeId) return;
  const applied = engine.setParams(state.knifeId, effectiveParams());
  if (applied) applied.patternSeed = state.params.patternSeed;
  // ⚠ 旧通道（刀柄/护手）会顺带把材质层的 metalness/roughness 等改回去，
  //   所以每次推完都要把刀身的 BladeSkin 再应用一次（纯 uniform 更新，代价很小）
  applyBladeSkinNow();
}

/** 用当前 state.regionBladeStart / regionGuardStart / regionAngle 覆盖重建区域。
 *  覆盖持久存到 K3D.regions.overrideMap（所有下游 aRegion / atlas 烘焙统一读它），
 *  不再做「临时包装 regions.of + finally 还原」——那是导致部分刀
 *  烘焙读到旧边界、覆盖线卡住的竞态根因。 */
function _rebuildRegions() {
  if (!engine || !state.knifeId) return;
  // 不变量：护手带必须整体位于刀身之前（guardStart ≤ bladeStart）。
  // 允许拉到相等（= 这把刀不要护手带）；只拦"越过 bladeStart"这种会把护手压到刀身上的输入。
  // ⚠ 上限要用**有效 bladeStart**（覆盖值 ?? regions.js 基准值）：只拖 guardStart 一把滑块时
  //   regionBladeStart 仍是 null，若只比覆盖值就会漏掉夹紧（state 存着越界值，只有渲染侧兜底）。
  const effBladeStart = state.regionBladeStart != null
    ? state.regionBladeStart
    : (K3D.regions.of ? (K3D.regions.of(state.knifeId) || {}).bladeStart : null);
  if (effBladeStart != null && state.regionGuardStart != null &&
      state.regionGuardStart > effBladeStart) {
    state.regionGuardStart = Number(effBladeStart.toFixed(3));
    if (state._gsSlider) state._gsSlider.value = state.regionGuardStart;
    if (state._gsLabel) state._gsLabel.textContent = state.regionGuardStart.toFixed(3);
  }
  const hasOverride = state.regionBladeStart != null || state.regionGuardStart != null || state.regionAngle !== 0;
  if (!hasOverride) {
    engine.setRegionOverride(state.knifeId, null);
    engine.rebuildRegions(state.knifeId);
    // 持久化清除
    if (_savedRegions[state.knifeId]) {
      delete _savedRegions[state.knifeId].bladeStart;
      delete _savedRegions[state.knifeId].guardStart;
      delete _savedRegions[state.knifeId].angle;
      if (Object.keys(_savedRegions[state.knifeId]).length === 0) delete _savedRegions[state.knifeId];
      _saveRegions();
    }
    scheduleRebake();   // 回落到 regions.js 基准值，重烘焙
    return;
  }
  engine.setRegionOverride(state.knifeId, {
    bladeStart: state.regionBladeStart,
    guardStart: state.regionGuardStart,
    angle: state.regionAngle || 0,
  });
  engine.rebuildRegions(state.knifeId);
  // 持久化
  if (!_savedRegions[state.knifeId]) _savedRegions[state.knifeId] = {};
  if (state.regionBladeStart != null) _savedRegions[state.knifeId].bladeStart = state.regionBladeStart;
  else delete _savedRegions[state.knifeId].bladeStart;
  if (state.regionGuardStart != null) _savedRegions[state.knifeId].guardStart = state.regionGuardStart;
  else delete _savedRegions[state.knifeId].guardStart;
  if (state.regionAngle !== 0) _savedRegions[state.knifeId].angle = state.regionAngle;
  else delete _savedRegions[state.knifeId].angle;
  _saveRegions();
  // 防抖重烘焙（overrideMap 已持久，缓存 key 含 regionKey → 强制新烘焙，无竞态）
  scheduleRebake();
}
async function selectKnife(id) {
  if (state.loading || state.knifeId === id) return;
  state.loading = true;
  state.knifeId = id;
  renderKnifeStrip(engine.knives);
  setStatus('模型加载中…');
  try {
    await new Promise((r) => setTimeout(r, 20));   // 让 loading 状态先画出来
    // 先恢复该刀型的持久覆盖（写入 overrideMap），保证 loadKnife/applySkin
    // 第一次烘焙就用正确的边界，避免"先烘焙基准值再重烘焙覆盖值"的双重烘焙。
    _restoreRegionState(id);
    const info = await engine.loadKnife(id);
    viewer.setModel(info.root, id);
    // 拍缩略图（首拍后写回卡片）
    if (!thumbCache.has(id)) {
      const url = viewer.snapshot(160, 120);
      thumbCache.set(id, url);
      renderKnifeStrip(engine.knives);
    }
    // ── 性能两步走（任务 16）──────────────────────────────────────
    // ① fast：不烘 atlas（~770ms），模型 + 刀身新皮肤（BladeSkin 走 shader，不依赖 atlas）
    //    立刻上屏 → 用户不再卡在"生成皮肤贴图…"
    // ② 后台补烘 atlas（程序化刀柄纹理 + 分区 mask），烘好再 rebuildRegions；
    //    烘好后若已切到别的刀则丢弃（knifeId 校验）
    setStatus('');
    await applySkin({ fast: true });
    engine.rebuildRegions(id);
    state.loading = false;
    applySkin().then((r) => {
      if (state.knifeId === id && r) engine.rebuildRegions(id);
    }).catch(() => {});
  } catch (e) {
    console.error('[selectKnife]', e);
    setStatus('加载失败：' + e.message);
  } finally {
    state.loading = false;
  }
}

/** 从 localStorage 恢复某刀型的区域覆盖 → 同步 state / overrideMap / 滑块 UI。 */
function _restoreRegionState(id) {
  const saved = _savedRegions[id];
  // 清理历史脏覆盖：修复前 guardStart 被标到 bladeStart **之后**（护手盖满刀身的那批值）。
  // 只有"严格越过 bladeStart"才算脏；相等是合法配置（零宽护手带），保留。
  // 直接丢弃该字段回落到 regions.js 新值；bladeStart/angle 保留（那是用户真调过的部分）。
  if (saved && saved.bladeStart != null && saved.guardStart != null && saved.guardStart > saved.bladeStart) {
    delete saved.guardStart;
    _saveRegions();
  }
  if (saved && (saved.bladeStart != null || saved.guardStart != null || saved.angle != null)) {
    state.regionBladeStart = saved.bladeStart ?? null;
    state.regionGuardStart = saved.guardStart ?? null;
    state.regionAngle = saved.angle ?? 0;
    engine.setRegionOverride(id, {
      bladeStart: state.regionBladeStart,
      guardStart: state.regionGuardStart,
      angle: state.regionAngle || 0,
    });
  } else {
    state.regionBladeStart = null;
    state.regionGuardStart = null;
    state.regionAngle = 0;
    engine.setRegionOverride(id, null);
  }
  if (state._bsSlider) state._bsSlider.value = state.regionBladeStart ?? '';
  if (state._bsLabel) state._bsLabel.textContent = state.regionBladeStart != null ? state.regionBladeStart.toFixed(3) : '—';
  if (state._gsSlider) state._gsSlider.value = state.regionGuardStart ?? '';
  if (state._gsLabel) state._gsLabel.textContent = state.regionGuardStart != null ? state.regionGuardStart.toFixed(3) : '—';
  if (state._baSlider) state._baSlider.value = state.regionAngle ?? 0;
  if (state._baLabel) state._baLabel.textContent = (state.regionAngle ?? 0) + '°';
}

async function applySkin({ fast = false } = {}) {
  if (!state.knifeId) return;
  setStatus(state.skinId === 'original' ? '' : (fast ? '' : '生成皮肤贴图…'));
  try {
    await new Promise((r) => setTimeout(r, 20));
    const r = await engine.applySkin(state.knifeId, state.skinId, effectiveParams(), { fast });
    setStatus('');
    if (r.atlasStats) {
      const s = r.atlasStats;
      console.info('[atlas] 刀身占比', (s.bladeRatio * 100).toFixed(1) + '%', '覆盖率', (s.covered * 100).toFixed(1) + '%', '长轴', s.axis);
    }
    // 刀身颜色由 BladeSkin shader 接管（在旧通道之后应用，保证刀身不被旧配方覆盖）
    applyBladeSkinNow();
  } catch (e) {
    console.error('[applySkin]', e);
    setStatus('皮肤生成失败：' + e.message);
  }
}

/* 注：旧的「切换纹理/工艺」选择器已移除 —— 刀身皮肤改由 BladeSkin 系统
 * （刀身材质 / 刀身纹理 / 工艺特效）驱动，见 renderParams 与 js/skin/*。
 * state.skinId / finishId 现在只作为**护手与刀柄通道**的配方来源（固定 'fade'，界面上不再暴露），
 * 以保证护手/刀柄的观感与基线完全一致。 */

/* ---------------------------------------------------------------- 启动 */

async function boot() {
  engine = new K3D.engine();
  viewer = new K3D.Viewer($('#stage'));
  engine.renderer = viewer.renderer;
  global.__k3dEngine = engine;   // 调试/测试钩子：读取 atlas 缓存与统计
  global.__k3dViewer = viewer;   // 调试/测试钩子：读取相机与 pivot
  // 环境贴图加载完成后挂到所有材质（否则材质级「反射强度」被 three 忽略）
  viewer.onEnvMapReady = (tex) => engine.setEnvMap(tex);
  engine.onStatus((s) => {
    if (s && s.stage === 'knife') setStatus(s.message || '');
  });
  engine.onError((e) => setStatus(e && e.message ? e.message : String(e)));

  $('#btnReset').addEventListener('click', () => viewer.resetView());

  let knives = [];
  try {
    knives = await engine.init();
  } catch (e) {
    setStatus('清单加载失败：' + e.message + '（请先运行 tools/build.py 或用本地服务器打开）');
    return;
  }
  // 内联包（file://）或协议确定之后再加环境贴图，保证 HDR 通路正确
  viewer.loadEnvironment();
  if (!knives.length) {
    setStatus('assets/models/ 里还没有模型 —— 运行 tools/make_sample_knives.py 生成示例，或放入你的 .glb 后运行 tools/build.py');
    return;
  }
  renderKnifeStrip(knives);
  renderParams();
  enableStripScroll($('#knifeStrip'));
  await selectKnife(knives[0].id);
  // 后台预热：首刀 ready 后延迟 500ms 启动（不抢首屏），预热**所有皮肤**的 atlas
  // 分片烘好并写 IDB → 之后切刀/切换皮肤秒出；命中 IDB 时近零成本
  setTimeout(() => {
    if (!state.knifeId) return;
    const params = effectiveParams();
    // 预热当前皮肤
    engine.prewarm(state.skinId, params).catch(() => {});
    // 同时预热其他常见皮肤（多普勒/大马士革钢/渐变等），每个间隔 30ms 不抢主线程
    const extraSkins = K3D.skins.SKINS
      .map(s => s.id)
      .filter(id => id !== state.skinId && id !== 'original')
      .slice(0, 4);  // 最多预热 4 个，避免 IDB 写得太满
    let delay = 500;
    for (const sid of extraSkins) {
      delay += 300;
      setTimeout(() => {
        engine.prewarm(sid, params).catch(() => {});
      }, delay);
    }
  }, 500);
}

document.addEventListener('DOMContentLoaded', boot);
/** 诊断句柄（tools/ 下的 playwright 脚本靠它读运行时的 aRegion / 几何 / BladeSkin 状态，
 *  避免在测试里重实现一遍公式）。业务代码请勿依赖。 */
const dbgHandle = {
  engine: () => engine,
  viewer: () => viewer,
  _lastSkin: null,
    /** 读某把刀运行时的 aRegion：返回 { verts, bladeVerts, bladeCoveredByGuard, maxPartitionErr } */
    regionStats(knifeId) {
      const info = engine && engine.loaded && engine.loaded.get(knifeId);
      if (!info) return null;
      let verts = 0, bladeVerts = 0, covered = 0, err = 0;
      info.root.traverse((m) => {
        if (!m.isMesh || !m.geometry) return;
        const a = m.geometry.attributes.aRegion && m.geometry.attributes.aRegion.array;
        if (!a) return;
        for (let i = 0; i < a.length; i += 3) {
          const wB = a[i], wG = a[i + 1], wH = a[i + 2];
          verts++;
          err = Math.max(err, Math.abs(wB + wG + wH - 1));
          if (wB > 0.5) { bladeVerts++; if (wG > 0.5) covered++; }
        }
      });
      return { verts, bladeVerts, bladeCoveredByGuard: covered, maxPartitionErr: err };
    },
    /** BladeSkin 直连入口（P1 验证 / P2 面板都会用）：
     *  applySkinState({materialId,textureId,finishId,wear,seed,...}) → 组合并应用到当前刀身 */
    applySkinState(partial) {
      if (!engine || !state.knifeId || !K3D.bladeSkin) return null;
      const st = K3D.bladeSkin.makeState(partial || {});
      state.skin = st;                       // 让面板与 state 保持同步（同一份数据）
      const pack = K3D.bladeSkin.composeBladeSkin(st);
      engine.applyBladeSkin(state.knifeId, pack);
      dbgHandle._lastSkin = { state: st, pack };
      return { state: st, pack, hash: K3D.bladeSkin.hashState(st) };
    },
    /** 读最近一次应用结果（供测试断言材质层属性） */
    lastSkin: () => dbgHandle._lastSkin,
    /** 手动推一次旧通道（刀柄/护手）参数——测试里改 state.params 后需要它才会生效
     *  （新面板的滑块有的只走 BladeSkin 通道，不会触发 pushParams） */
    pushParams: () => pushParams(),
    /** 渲染一帧（截图前确保已上屏） */
    render: () => { if (viewer && viewer.renderer) viewer.renderer.render(viewer.scene, viewer.camera); },
    /** 读刀身材质上的 BladeSkin 注入状态（uniform 名 → 值） */
    bladeSkinUniforms(knifeId) {
      const info = engine && engine.loaded && engine.loaded.get(knifeId);
      if (!info || !info.materials[0]) return null;
      const hooks = K3D.material.hookMap(info.materials[0]);
      const h = hooks.get('bladeSkin');
      if (!h) return null;
      const out = {};
      for (const [k, v] of Object.entries(h.uniforms)) {
        const val = v.value;
        out[k] = (val && val.toArray) ? val.toArray() : val;
      }
      return out;
    },
};

K3D.app = { boot, state, dbg: dbgHandle };
})(window);
