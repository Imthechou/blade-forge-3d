/**
 * 三区域配置（《SkinShader 完整实现方案 v2》§3 / §6）
 *
 * 区域：0 = Blade（刀身）/ 1 = GuardPommel（护手+尾部）/ 2 = Handle（刀柄）
 *
 * V2 主方案用**顶点属性 aRegion**（vec3 One-Hot：r=刀身 g=护手+尾部 b=刀柄）表达区域，
 * 不依赖 Packed UV、不增加纹理采样、不会因 UV 岛重叠误分区；
 * region_mask 纹理仅作 fallback / 烘焙 / 调试。
 *
 * ⚠ 边界语义与**不变量**（engine._buildRegionAttribute 依赖它，写反会整片串色）：
 *   - t = 沿长轴的归一化位置，**0 = 柄尾，1 = 刀尖**
 *   - 刀身     = t ≥ bladeStart
 *   - 护手带   = [guardStart, bladeStart]（柄侧那一段金属环，即护手块自身）
 *   - 刀柄     = t < guardStart
 *   - 必须满足 **guardStart ≤ bladeStart**；**允许相等**（带宽为 0 = 这把刀不要护手带，
 *     例如金属刀身直接连到握把、没有独立护手块的刀型）。
 *     若写成 guardStart > bladeStart（越过刀身），engine 会把 guardStart 夹回 bladeStart
 *     （→ 零宽护手带）兜底，不会串色，但数据本身应当写对。
 *   - UI 上 `guardStart` 滑块的可用上限就是 `bladeStart`（拖到顶 = 护手带收成 0）。
 *
 * 标定来源：
 *   - bladeStart：几何剖面（沿长轴分 bin 的截面宽度）+ 人工视觉复核
 *   - guardStart：tools/measure_guard.js 测出的护手宽度局部极大值（带宽夹在 0.035~0.08）
 *   - angle：切割平面相对长轴的倾角（度），用于弧形刀（爪子刀/弯刀）贴合指环弧
 */
'use strict';

(function attach(K3D) {
  /** knifeId → 区域边界（沿长轴归一化）。
   *  可通过 tools/measure_guard.js 重新测量护手位置，或在 App「区域边界」面板拖动滑块
   *  实时预览（1:1 对应 guardStart 位置，可一路拖到 bladeStart 把护手带收成 0）后导出。 */
  const KNIFE_REGIONS = {
    // 蝴蝶刀：双柄 + 中心轴对称，刀身位于中部
    knife_balisong: { bladeStart: 0.5, guardStart: 0.5, angle: -6 },
    // 刺刀
    knife_bayonet:  { bladeStart: 0.39, guardStart: 0.39 },
    // 折刀
    knife_folding:  { bladeStart: 0.45, guardStart: 0.45, angle: -8 },
    // 短剑
    knife_gladius:  { bladeStart: 0.52, guardStart: 0.52, angle: -2 },
    // 爪子刀
    knife_karambit: { bladeStart: 0.45, guardStart: 0.45, angle: -16 },
    // 匕首
    knife_kris:     { bladeStart: 0.33, guardStart: 0.33, angle: 4 },
    // 战壕刀
    knife_machete:  { bladeStart: 0.32, guardStart: 0.315, angle: -5 },
    knife_saber:    { bladeStart: 0.335, guardStart: 0.335, angle: -4 },
    // 骷髅头战术刀
    knife_skull:    { bladeStart: 0.34, guardStart: 0.34, angle: -5 },
    // 直刃战术刀
    knife_straight: { bladeStart: 0.42, guardStart: 0.42 },
    // 生存刀
    knife_survival: { bladeStart: 0.445, guardStart: 0.445, angle: -5 },
    // 唐刀/弯刀
    knife_tangdao:  { bladeStart: 0.35, guardStart: 0.35, angle: -2 },
  };

  /** 未登记的刀型用这套兜底 */
  const DEFAULT_REGION = { bladeStart: 0.36, guardStart: 0.28 };

  /** 边界过渡带宽度（归一化长轴）。V2 §3.3 允许 1~3px 柔化，这里用软过渡避免硬切。 */
  const FEATHER = 0.012;

  /**
   * 线外浅铺（消除交界处的"没效果白痕"）—— **固定值，对所有刀型统一生效，不开放参数**
   *
   * 问题：刀身花纹在 bladeStart 处停止后，那条线附近只剩护手/刀柄质感 —— 而护手/刀柄质感是
   *       「模型原贴图 × 去饱和 × tint」的亮金属表现，紧贴彩色皮肤时就是一条亮白痕。
   * 做法：让刀身花纹**统一越过 bladeStart 往柄侧再浅铺一点点**，以低不透明度压在护手/刀柄
   *       质感之上，用皮肤色把这条亮痕盖掉（皮肤在 shader 里是底色，护手/刀柄按权重盖上去，
   *       所以"刀身权重"在浅铺区抬起来 = 那两块盖得少一点 = 皮肤透出来）。
   *
   *   SKIRT 浅铺长度（归一化长轴，柄侧方向）—— "一点点"，约刀长的 5%
   *   BLEED 浅铺区顶到 bladeStart 时的最高不透明度（低透明度，别盖成"护手被染紫"）
   *
   * ⚠ 必须与 js/engine.js（顶点权重）和 js/atlas.js（烘焙 mask）用**同一套公式**，
   *   否则又会出现「图案与区域错位」的白块（历史上踩过）。
   * ⚠ 别超过 0.5：atlas 用 `bw < 0.5` 把纹素分类成刀身/刀柄，浅铺过 0.5 会把分类翻面。
   */
  const SKIRT = 0.05;
  const BLEED = 0.35;

  /**
   * 花纹边界外扩（atlas 烘焙侧专用）
   *
   * 问题：atlas 的花纹是「花纹色 ←→ 刀柄底色（模型亮金属灰）」插值出来的。这个过渡带如果
   *       正好压在可见的 bladeStart 交界线上，就会把花纹冲淡成**一条淡白灰**——
   *       用户看到的就是"各块之间的连接线处发白"。
   * 做法：把 **atlas 的花纹边界整体往柄侧挪 PATTERN_EXTEND**，这样在可见交界处
   *       atlas 已经是满强度花纹（bw=1），过渡带被推进到刀柄质感占主导的那一段里，
   *       被刀柄/护手的着色盖掉 → 交界线上不再有白灰。
   *       多余露出的那一点点花纹，正好就是 SKIRT/BLEED 想要的"低透明度超出"效果。
   *
   * 实测（karambit + fade，820×900 视角）：发白像素 0.51% → 见 tools/analyze_white.js
   */
  const PATTERN_EXTEND = 0.02;

  K3D.regions = {
    KNIFE_REGIONS,
    DEFAULT_REGION,
    FEATHER,
    SKIRT,
    BLEED,
    PATTERN_EXTEND,
    /** 每刀型的持久覆盖（UI 滑块调 bladeStart/guardStart/angle 时写入，无竞态）。
     *  优先级：用户 overrideMap > KNIFE_REGIONS 配置 > DEFAULT_REGION。 */
    overrideMap: {},
    /** 取某把刀的区域边界（含用户覆盖） */
    of(knifeId, override) {
      return { ...DEFAULT_REGION, ...(KNIFE_REGIONS[knifeId] || {}),
               ...(this.overrideMap[knifeId] || {}), ...(override || {}) };
    },
  };
}(window.K3D = window.K3D || {}));
