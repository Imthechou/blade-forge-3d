/* Knife3D · material.js
 * 材质参数层：参数规范化、冻结公式、shader 注入。
 * 冻结公式沿用 cs2-knife-viewer（中性参数 = 原版观感）：
 *   roughness_eff = min(1, M.roughness × orig.roughness × (1 + 1.1·wear) + 0.22·wear)
 *   metalness_eff = max(0, M.metalness × orig.metalness × (1 - 0.45·wear))
 *   envMapIntensity_eff = M.reflection × orig.envMapIntensity × (1 - 0.55·wear)
 *   color_eff = orig.color → lerp(#8b929b, 0.6·wear) × M.baseColor
 *
 * 注入两处 fragment hook：
 *   patternStrength —— 底色与花纹的混合权重
 *   bladeMask      —— 刀柄微调（刀柄 = 模型自带贴图 × 去饱和 × 着色 × 增量）
 *                     判定依据：ORM 的 B 通道（metalness），smoothstep(0.35, 0.75)
 */
(function (global) {
'use strict';
const K3D = (global.K3D = global.K3D || {});
const THREE = global.THREE;

const WEAR_TINT = new THREE.Color('#8b929b');

const MATERIAL_DEFAULTS = Object.freeze({
  baseColor: '#ffffff',
  metalness: 1, roughness: 1,
  patternStrength: 1, normalStrength: 1, reflection: 0.4,
  // ⚠ 清漆/虹彩默认都必须为 0（实测：0.1 也足以"影响颜色"）：
  //   - clearcoat 0.1 → 给刀身加白镜面，浅色皮肤饱和度腰斩（damascus 0.134→0.077）
  //   - iridescence 0.1 → 薄膜干涉只作用于非金属，会把电介质刀柄洗成亮灰
  //   两者在金属刀身上确实无感；要宝石感请降金属度到 0.6-0.8 后手动开。
  clearcoat: 0, clearcoatRoughness: 0.1,
  iridescence: 0, iridescenceIOR: 1.3,
  wear: 0,
});

const MATERIAL_LIMITS = Object.freeze({
  metalness: [0, 1], roughness: [0, 1],
  patternStrength: [0, 1], normalStrength: [0, 2], reflection: [0, 2],
  clearcoat: [0, 1], clearcoatRoughness: [0, 1],
  iridescence: [0, 1], iridescenceIOR: [1.2, 2.5],
  wear: [0, 1],
});

const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

function clamp(value, [min, max]) {
  const n = Number(value);
  if (!Number.isFinite(n)) return null;
  return Math.min(max, Math.max(min, n));
}

function deepMerge(...layers) {
  const out = {};
  for (const layer of layers) {
    if (!isObj(layer)) continue;
    for (const [k, v] of Object.entries(layer)) {
      if (v === undefined) continue;
      out[k] = isObj(v) && isObj(out[k]) ? deepMerge(out[k], v) : v;
    }
  }
  return out;
}

function normalizeMaterial(input = {}) {
  const out = { ...MATERIAL_DEFAULTS };
  const src = isObj(input) ? input : {};
  if (isObj(src.bladeMask)) out.bladeMask = deepMerge(src.bladeMask);
  if (typeof src.baseColor === 'string' || Array.isArray(src.baseColor)) out.baseColor = src.baseColor;
  for (const [key, range] of Object.entries(MATERIAL_LIMITS)) {
    if (src[key] === undefined) continue;
    const v = clamp(src[key], range);
    if (v !== null) out[key] = v;
  }
  return out;
}

function colorFromSpec(spec, fallback = '#ffffff') {
  const c = new THREE.Color();
  try {
    if (typeof spec === 'string') c.setStyle(spec.trim());
    else if (Array.isArray(spec) && spec.length >= 3) c.setRGB(spec[0], spec[1], spec[2], THREE.SRGBColorSpace);
    else c.setStyle(fallback);
  } catch (e) { c.setStyle(fallback); }
  return c;
}

/** MeshStandardMaterial → MeshPhysicalMaterial（clearcoat 需要），逐项拷贝。 */
function toPhysicalMaterial(original) {
  const p = new THREE.MeshPhysicalMaterial();
  for (const k of ['map', 'metalnessMap', 'roughnessMap', 'normalMap', 'aoMap', 'emissiveMap']) {
    p[k] = original[k] ?? null;
  }
  for (const k of ['name', 'side', 'metalness', 'roughness', 'envMapIntensity',
    'aoMapIntensity', 'emissiveIntensity']) {
    if (original[k] !== undefined) p[k] = original[k];
  }
  p.color.copy(original.color);
  p.emissive.copy(original.emissive);
  if (original.normalScale) p.normalScale.copy(original.normalScale);
  p.userData = { ...original.userData };
  p.clearcoat = 0; p.clearcoatRoughness = 0.1;
  p.ior = 1.5; p.specularIntensity = 1; p.sheen = 0;
  p.iridescence = 0; p.iridescenceIOR = 1.3; p.transmission = 0;
  return p;
}

function computeApplied(orig, M) {
  const wear = clamp(M.wear, MATERIAL_LIMITS.wear) ?? 0;
  const base = colorFromSpec(M.baseColor);
  return {
    roughness: Math.min(1, M.roughness * orig.roughness * (1 + 1.1 * wear) + 0.22 * wear),
    metalness: Math.max(0, M.metalness * orig.metalness * (1 - 0.45 * wear)),
    envMapIntensity: M.reflection * orig.envMapIntensity * (1 - 0.55 * wear),
    color: orig.color.clone().lerp(WEAR_TINT, 0.6 * wear).multiply(base),
    normalScaleX: M.normalStrength * (orig.normalScale ? orig.normalScale.x : 1),
    normalScaleY: M.normalStrength * (orig.normalScale ? orig.normalScale.y : 1),
    clearcoat: M.clearcoat, clearcoatRoughness: M.clearcoatRoughness,
    iridescence: M.iridescence, iridescenceIOR: M.iridescenceIOR,
    patternStrength: M.patternStrength, wear,
    baseColorHex: typeof M.baseColor === 'string' ? M.baseColor : base.getHexString(),
  };
}

/* ---------------------------------------------------------- fragment hook 管理 */

const HOOKS_KEY = '__k3dHooks';

function hookMap(material) {
  if (!material.userData[HOOKS_KEY]) material.userData[HOOKS_KEY] = new Map();
  return material.userData[HOOKS_KEY];
}

function syncFragmentHooks(material) {
  const hooks = hookMap(material);
  if (hooks.size === 0) {
    if (material.userData.__hooksInstalled) {
      material.userData.__hooksInstalled = false;
      material.onBeforeCompile = () => {};
      material.userData.__hooksDirty = true;
      material.needsUpdate = true;
    }
    return;
  }
  const uniforms = {};
  const common = [];
  const mapFrag = [];
  const roughFrag = [];     // 注入到 #include <roughnessmap_fragment> 之后
  const metalFrag = [];     // 注入到 #include <metalnessmap_fragment> 之后
  const physFrag = [];      // 注入到 #include <lights_physical_fragment> 之后
  const vertCommon = [];    // 顶点着色器：#include <common> 之后
  const vertBody = [];      // 顶点着色器：#include <begin_vertex> 之后
  for (const hook of hooks.values()) {
    Object.assign(uniforms, hook.uniforms);
    if (hook.common) common.push(hook.common);
    if (hook.mapFragment) mapFrag.push(hook.mapFragment);
    if (hook.roughnessFragment) roughFrag.push(hook.roughnessFragment);
    if (hook.metalnessFragment) metalFrag.push(hook.metalnessFragment);
    if (hook.physicalFragment) physFrag.push(hook.physicalFragment);
    if (hook.vertexCommon) vertCommon.push(hook.vertexCommon);
    if (hook.vertexBody) vertBody.push(hook.vertexBody);
  }
  material.onBeforeCompile = (shader) => {
    for (const [name, slot] of Object.entries(uniforms)) shader.uniforms[name] = slot;
    let src = shader.fragmentShader;
    if (common.length) src = src.replace('#include <common>', '#include <common>\n' + common.join('\n'));
    if (mapFrag.length) src = src.replace('#include <map_fragment>', '#include <map_fragment>\n' + mapFrag.join('\n'));
    if (roughFrag.length) src = src.replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n' + roughFrag.join('\n'));
    if (metalFrag.length) src = src.replace('#include <metalnessmap_fragment>', '#include <metalnessmap_fragment>\n' + metalFrag.join('\n'));
    if (physFrag.length) src = src.replace('#include <lights_physical_fragment>', '#include <lights_physical_fragment>\n' + physFrag.join('\n'));
    shader.fragmentShader = src;
    // 顶点着色器：区域属性需要从顶点传到片元（aRegion → vRegion）
    let vs = shader.vertexShader;
    if (vertCommon.length) vs = vs.replace('#include <common>', '#include <common>\n' + vertCommon.join('\n'));
    if (vertBody.length) vs = vs.replace('#include <begin_vertex>', '#include <begin_vertex>\n' + vertBody.join('\n'));
    shader.vertexShader = vs;
  };
  material.userData.__hooksInstalled = true;
  material.userData.__hooksDirty = true;
  // ⚠⚠ 关键：three 的默认 customProgramCacheKey() 返回 onBeforeCompile.toString()，
  //   而这里每次生成的 onBeforeCompile **源码文本完全相同**（逻辑都在闭包里读 hooks）。
  //   于是「增删 hook / 改 signature」时 cacheKey 不变 → three 直接复用旧 program →
  //   着色器改了但画面纹丝不动（实测：强制把刀身染成品红都看不出来）。
  //   必须让 cacheKey 反映当前 hook 集合 + 各自 signature。
  material.customProgramCacheKey = () => {
    // ⚠ 不能用函数源码本身：这里每次生成的 onBeforeCompile 源码是**常量**（逻辑在闭包里读 hooks），
    //   增删 hook 后源码不变 → cacheKey 不变 → three 复用"缺少该 hook"的旧 program。
    //   用 hook 集合 + signature 做 key：集合/结构变才变，纯 uniform 值更新不变。
    const parts = [];
    for (const [k, h] of hooks) parts.push(k + '#' + (h.signature || ''));
    return parts.join('|');
  };
  material.needsUpdate = true;
}

function upsertHook(material, key, spec) {
  const hooks = hookMap(material);
  const existing = hooks.get(key);
  if (existing && existing.signature === spec.signature) {
    for (const [name, slot] of Object.entries(spec.uniforms)) {
      const target = existing.uniforms[name];
      if (!target) continue;
      const value = slot.value;
      if (value && value.isTexture) target.value = value;      // 贴图只换引用，勿 copy
      else if (target.value && typeof target.value.copy === 'function') target.value.copy(value);
      else target.value = value;
    }
    return;
  }
  hooks.set(key, spec);
  syncFragmentHooks(material);
}

function removeHook(material, key) {
  if (hookMap(material).delete(key)) syncFragmentHooks(material);
}

function setPatternStrength(material, strength, baseColor) {
  if (strength === 1) { removeHook(material, 'patternStrength'); return; }
  upsertHook(material, 'patternStrength', {
    signature: 'patternStrength',
    uniforms: {
      uPatternStrength: { value: strength },
      uBaseColor: { value: baseColor.clone() },
    },
    common: 'uniform float uPatternStrength;\nuniform vec3 uBaseColor;',
    mapFragment: 'diffuseColor.rgb = mix( uBaseColor, diffuseColor.rgb, uPatternStrength );',
  });
}

/**
 * P4 Damascus：从 atlas 纹理 A 通道读取 pattern roughness 变体，
 * 调制 roughnessFactor。亮带抛光（A≈255）、暗带磨砂（A→0）。
 * intensity > 0 才注入 hook；0 则清掉避免残留。
 */
function setRoughPattern(material, roughTex, intensity) {
  if (intensity <= 0 || !roughTex) {
    removeHook(material, 'roughPattern');
    return;
  }
  upsertHook(material, 'roughPattern', {
    signature: 'roughPattern:' + (roughTex.uuid || ''),
    uniforms: {
      uRoughPatternTex: { value: roughTex },
      uRoughPatternIntensity: { value: Math.min(1, Math.max(0, intensity)) },
    },
    common: 'uniform sampler2D uRoughPatternTex;\nuniform float uRoughPatternIntensity;',
    roughnessFragment: `{
  float pRough = 1.0 - texture2D( uRoughPatternTex, vMapUv ).a * uRoughPatternIntensity;
  roughnessFactor = clamp( roughnessFactor * pRough, 0.0, 1.0 );
}`,
  });
}

/** 统一的「区域顶点属性」hook：aRegion / aBladeT / aEdge 的声明 + 赋值。
 *  必须在所有会用到这些属性/varying 的 hook（bladeMask、bladeSkin）编译前装上。
 *  ⚠ 属性声明只能有一份：旧实现把声明写在 bladeMask hook 里，bladeMask 缺席时
 *    bladeSkin 用 aBladeT 就 undeclared（或两者都声明就 redefinition，二选一都会炸）。
 *  所以声明独立成一个**恒装**的 hook，与 bladeMask 的启用/停用无关。 */
function setBladeAttrs(material) {
  upsertHook(material, 'bladeAttrs', {
    signature: 'bladeAttrs',
    uniforms: {},
    vertexCommon: `attribute vec3 aRegion;
attribute float aBladeT;
attribute float aEdge;
varying vec3 vRegion;
varying float vBladeT;
varying float vEdge;`,
    vertexBody: `vRegion = aRegion;
vBladeT = aBladeT;
vEdge = aEdge;`,
  });
}

function setBladeMask(material, cfg, origMap, maskMap, maskAlpha) {
  // cfg.active 由调用方给出：皮肤配方带 handle 块、或用户调过刀柄 → 注入。
  // 刀柄样式（颜色 + 质感）统一由本 hook 负责，atlas 烘焙侧不再着色，避免双重应用。
  // maskAlpha=true  → 遮罩取 atlas metal 贴图的 **A 通道**（我们自己烘焙的刀身/刀柄分区，更准）
  // maskAlpha=false → 退化为模型自带 ORM 的 B 通道（无皮肤时的兜底）
  const active = !!cfg && cfg.active !== false && !!origMap && !!maskMap;
  if (!active) { removeHook(material, 'bladeMask'); return; }
  const pick = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);
  let low = pick(cfg.low, 0.35), high = pick(cfg.high, 0.75);
  if (low >= high) { low = 0.35; high = 0.75; }
  upsertHook(material, 'bladeMask', {
    signature: 'bladeMask:v2' + (maskAlpha ? ':alpha' : ':orm'),
    uniforms: {
      uBladeOrigMap: { value: origMap },
      uBladeMaskMap: { value: maskMap },
      uBladeMaskLow: { value: low },
      uBladeMaskHigh: { value: high },
      uHandleGain: { value: pick(cfg.handleGain, 1) },
      uHandleTint: { value: colorFromSpec(cfg.handleTint, '#ffffff') },
      uHandleDesat: { value: Math.min(1, Math.max(0, pick(cfg.handleDesat, 0))) },
      uHandleMetalness: { value: Math.min(1, Math.max(0, pick(cfg.handleMetalness, 0.35))) },
      uHandleRoughness: { value: Math.min(1, Math.max(0, pick(cfg.handleRoughness, 0.6))) },
      uHandleReflection: { value: Math.min(2, Math.max(0, pick(cfg.handleReflection, 1))) },
      // 护手+尾部（区域 1）：独立材质 profile
      uGuardGain: { value: pick(cfg.guardGain, 1) },
      uGuardTint: { value: colorFromSpec(cfg.guardTint, '#ffffff') },
      uGuardDesat: { value: Math.min(1, Math.max(0, pick(cfg.guardDesat, 0))) },
      uGuardMetalness: { value: Math.min(1, Math.max(0, pick(cfg.guardMetalness, 1))) },
      uGuardRoughness: { value: Math.min(1, Math.max(0, pick(cfg.guardRoughness, 0.35))) },
      uGuardReflection: { value: Math.min(2, Math.max(0, pick(cfg.guardReflection, 1))) },
      uDebugMode: { value: pick(cfg.debugMode, 0) },   // 0=最终 / 1=区域视图
      // 磨损系统（方案 §30/§31）：wear01 × WearRate → 露出底材
      uWear: { value: Math.min(1, Math.max(0, pick(cfg.wear, 0))) },
      uWearLow: { value: pick(cfg.wearLow, 0.10) },
      uWearHigh: { value: pick(cfg.wearHigh, 0.55) },
      // Cavity / Dirt（方案 §5.2）：凹槽积垢/油污
      uDirt: { value: Math.min(1, Math.max(0, pick(cfg.dirt, 0))) },
      // 曲率 AO + 曲率粗糙度（方案 B）：用 vEdge 给刀身加光影/棱线高光，出层次感
      // 固定默认值，始终生效（不接滑块），全局作用于所有工艺
      uCurvAO: { value: 0.6 },
      uCurvRough: { value: 0.5 },
    },
    common: (maskAlpha ? '#define K3D_MASK_ALPHA 1\n' : '') + `uniform sampler2D uBladeOrigMap;
uniform sampler2D uBladeMaskMap;
uniform float uBladeMaskLow;
uniform float uBladeMaskHigh;
uniform float uHandleGain;
uniform vec3 uHandleTint;
uniform float uHandleDesat;
uniform float uHandleMetalness;
uniform float uHandleRoughness;
uniform float uHandleReflection;
uniform float uGuardGain;
uniform vec3 uGuardTint;
uniform float uGuardDesat;
uniform float uGuardMetalness;
uniform float uGuardRoughness;
uniform float uGuardReflection;
uniform float uDebugMode;
uniform float uWear;
uniform float uWearLow;
uniform float uWearHigh;
uniform float uDirt;
uniform float uCurvAO;
uniform float uCurvRough;
varying vec3 vRegion;      // 三区域 One-Hot：r=刀身 / g=护手+尾部 / b=刀柄
varying float vBladeT;     // 沿长轴归一化位置（0=柄尾 1=刀尖），磨损速率用
varying float vEdge;       // 几何边缘因子（0=凹槽 1=凸棱），磨损乘子用
// 区域权重（aRegion 顶点属性）；属性缺失时兜底为「全部刀身」
void k3dRegionW( out float wB, out float wG, out float wH ) {
  wB = vRegion.r; wG = vRegion.g; wH = vRegion.b;
  if ( wB + wG + wH < 0.01 ) { wB = 1.0; wG = 0.0; wH = 0.0; }
}
// 刀柄权重（旧接口保留：纹理 mask 兜底路径用）
float k3dHandleW( vec2 uv ) {
  float wB, wG, wH;
  k3dRegionW( wB, wG, wH );
  if ( vRegion.r + vRegion.g + vRegion.b > 0.01 ) return wH;
  #ifdef K3D_MASK_ALPHA
    float m = texture2D( uBladeMaskMap, uv ).r;
  #else
    float m = 1.0 - texture2D( uBladeMaskMap, uv ).b;
  #endif
  return smoothstep( uBladeMaskLow, uBladeMaskHigh, m );
}`,
    vertexCommon: `// 区域属性声明/赋值统一在 'bladeAttrs' hook（见 setBladeAttrs）`,
    vertexBody: ``,
    mapFragment: `{
  vec3 dbgPattern = diffuseColor.rgb;   // atlas 烘焙出的图案（供调试视图「图案」档）
  // 护手+尾部 / 刀柄 的基底都取模型自带贴图（三层体系后的做法）
  vec3 raw = diffuse * texture2D( uBladeOrigMap, vMapUv ).rgb;
  // ── 非刀身区域高光压缩 ───────────────────────────────────────────
  // 护手/刀柄的底色都由 raw 派生，而这两块常落在模型自带的**亮金属**上：
  // 不压的话它们在皮肤旁边会读作"惨白"（用户报的"块与块之间的连接处发白"）。
  // 这里把亮端软压向中灰，保住结构但不再刺眼。刀身不受影响（刀身走 atlas 采样色）。
  // ⚠ 常量必须与 js/atlas.js 烘焙侧的 HLC_CEIL / HLC_K 保持一致，否则两侧色不一致。
  {
    const float HLC_CEIL = 0.42;
    const float HLC_K    = 0.45;
    raw = min( raw, vec3( HLC_CEIL ) ) + max( vec3( 0.0 ), raw - vec3( HLC_CEIL ) ) * HLC_K;
  }
  // 只提暗部（软下限）：暗底 × 彩色 = 看不见，需要抬到可上色的亮度
  float hl = dot( raw, vec3( 0.2126, 0.7152, 0.0722 ) );
  vec3 lifted = raw * clamp( 0.5 / max( hl, 0.05 ), 1.0, 2.2 );
  vec3 lum = vec3( dot( lifted, vec3( 0.2126, 0.7152, 0.0722 ) ) );
  float wB, wG, wH; k3dRegionW( wB, wG, wH );
  // ── 磨损系统（方案 §30/§31/§33）──────────────────────────────
  // ①② WearRate：刀尖/刀刃优先磨（§5.2），护手/刀柄磨得慢（真刀的握手处不易掉漆）
  float tAxis = clamp( vBladeT, 0.0, 1.0 );
  float bladeWearRate = mix( 0.20, 1.00, smoothstep( 0.40, 1.00, tAxis ) );
  float wearRate = wB * bladeWearRate + wG * 0.25 + wH * 0.15;
  // ③ EdgeFactor（方案 §7）：凸棱先掉漆、凹槽保留颜色 → WearFinal = Wear × Rate × Edge
  wearRate *= mix( 0.55, 1.70, clamp( vEdge, 0.0, 1.0 ) );
  float wearAmt = uWear * wearRate;
  // ③ Paint → Wear → Reveal Substrate：磨掉处露出**模型底材**（不是变灰）
  //    金属皮上是「彩色 → 银亮」，符合方案 §33 对 Doppler/anasodized 的期望
  float paintAmount = 1.0 - smoothstep( uWearLow, uWearHigh, wearAmt );
  diffuseColor.rgb = mix( lifted, diffuseColor.rgb, paintAmount );
  // ── Cavity / Dirt（方案 §5.2）：凹槽积垢、油污、氧化 —— 用几何曲率反推
  //    凹槽（vEdge→0）积垢、凸棱（vEdge→1）干净；真刀的螺丝孔/锻打凹槽最黑
  float cavity = 1.0 - clamp( vEdge, 0.0, 1.0 );
  float dirt = cavity * uDirt;
  diffuseColor.rgb *= ( 1.0 - dirt * 0.55 );
  // ── 方案 B：曲率 AO（始终生效，让刀身磨线/凹槽出层次）──────────────
  // vEdge=0(凹) 压暗、vEdge=1(凸/刃口) 提亮 → 刃口那条线自然被"点亮"，
  // 磨线凹陷被压出阴影，起伏立刻可见。只作用于刀身权重区（wB），护手/刀柄保留各自着色。
  {
    float e = clamp( vEdge, 0.0, 1.0 );
    float curvatureAO = mix( 1.0 - uCurvAO * 0.35, 1.0 + uCurvAO * 0.30, e );
    diffuseColor.rgb *= mix( 1.0, curvatureAO, wB );
  }
  // ── 区域 1：护手 + 尾部 ──
  vec3 guardColor = mix( lifted, lum, uGuardDesat ) * uGuardTint * uGuardGain * uGuardReflection;
  // ── 区域 2：刀柄 ──
  vec3 handleColor = mix( lifted, lum, uHandleDesat ) * uHandleTint * uHandleGain * uHandleReflection;
  float hW = ( vRegion.r + vRegion.g + vRegion.b > 0.01 ) ? wH : k3dHandleW( vMapUv );
  // 刀身（vRegion.r）保持 atlas 烘焙的皮肤颜色不动，另外两块按权重覆盖
  diffuseColor.rgb = mix( diffuseColor.rgb, guardColor, wG );
  diffuseColor.rgb = mix( diffuseColor.rgb, handleColor, hW );
  // ── 调试视图（方案 v2 §43）────────────────────────────────
  // 1=区域掩码 / 2=图案 / 3=底材 / 4=磨损 / 5=边缘因子
  if ( uDebugMode > 0.5 ) {
    if ( uDebugMode < 1.5 ) {          // 区域：刀身=白 / 护手+尾部=黄 / 刀柄=蓝（§6.3）
      diffuseColor.rgb = vec3( 0.0 );
      diffuseColor.rgb = mix( diffuseColor.rgb, vec3( 1.0, 1.0, 1.0 ), wB );
      diffuseColor.rgb = mix( diffuseColor.rgb, vec3( 1.0, 0.86, 0.24 ), wG );
      diffuseColor.rgb = mix( diffuseColor.rgb, vec3( 0.31, 0.55, 1.0 ), wH );
    } else if ( uDebugMode < 2.5 ) {   // 图案：只看 atlas 烘焙结果
      diffuseColor.rgb = dbgPattern;
    } else if ( uDebugMode < 3.5 ) {   // 底材：模型原贴图（提亮后）
      diffuseColor.rgb = lifted;
    } else if ( uDebugMode < 4.5 ) {   // 磨损：白=未磨 / 黑=磨穿露底
      diffuseColor.rgb = vec3( paintAmount );
    } else if ( uDebugMode < 5.5 ) {   // 边缘因子：白=凸棱 / 黑=凹槽
      diffuseColor.rgb = vec3( vEdge );
    }
  }
}`,
    // 三区域各自质感：护手/刀柄按权重覆盖，刀身保持皮肤材质
    // （three 的 envMapIntensity 是 uniform 无法逐像素调，「反射」用 albedo 亮度表达）
    roughnessFragment: `{
  float wB, wG, wH; k3dRegionW( wB, wG, wH );
  // ── 方案 B：曲率粗糙度（刀身）──
  // 凸的刃口(vEdge→1) 更光 → 高光更锐利；凹的磨线(vEdge→0) 更糙 → 哑光。
  // 让"起伏"从镜面均匀高光变成有棱有角的明暗分布。只作用于刀身权重 wB。
  {
    float e = clamp( vEdge, 0.0, 1.0 );
    // 以 0.5 为中点：凸 e=1 → -uCurvRough*0.5（更光），凹 e=0 → +uCurvRough*0.5（更糙）
    float bladeRough = clamp( roughnessFactor + uCurvRough * ( 0.5 - e ) * 0.8, 0.0, 1.0 );
    roughnessFactor = mix( bladeRough, roughnessFactor, 0.0 );  // 先取刀身值
    roughnessFactor = mix( roughnessFactor, uGuardRoughness, wG );
    roughnessFactor = mix( roughnessFactor, uHandleRoughness, wH );
  }
  // 调试模式：强制哑光，让调试色不被高光/反射盖住（否则金属上根本看不清）
  if ( uDebugMode > 0.5 ) roughnessFactor = 1.0;
}`,
    metalnessFragment: `{
  float wB, wG, wH; k3dRegionW( wB, wG, wH );
  metalnessFactor = mix( metalnessFactor, uGuardMetalness, wG );
  metalnessFactor = mix( metalnessFactor, uHandleMetalness, wH );
  // 调试模式：强制非金属 → 调试色以漫反射直读，不被反射染色
  if ( uDebugMode > 0.5 ) metalnessFactor = 0.0;
}`,
    // 刀柄/护手屏蔽虹彩+清漆：薄膜干涉和 clearcoat 只作用于金属刀身，
    // 护手/刀柄（电介质）会被彩虹色/清漆层污染 → 按遮罩把贡献归零。
    physicalFragment: `#ifdef USE_IRIDESCENCE
{
  // 虹彩只保留刀身（wB≈1），护手+刀柄归零
  float wB, wG, wH; k3dRegionW( wB, wG, wH );
  float nonBlade = max( wG, wH );
  material.iridescence = mix( material.iridescence, 0.0, nonBlade );
  material.iridescenceFresnel = mix( material.iridescenceFresnel, vec3( 0.0 ), nonBlade );
  material.iridescenceF0 = mix( material.iridescenceF0, vec3( 0.0 ), nonBlade );
}
#endif
#ifdef USE_CLEARCOAT
{
  float wB2, wG2, wH2; k3dRegionW( wB2, wG2, wH2 );
  // clearcoat 只保留刀身（wB≈1），护手+刀柄归零
  float nonBlade2 = max( wG2, wH2 );
  material.clearcoat = mix( material.clearcoat, 0.0, nonBlade2 );
  material.clearcoatRoughness = mix( material.clearcoatRoughness, 0.0, nonBlade2 );
}
#endif`,
  });
}

/**
 * 把参数写进材质。atlas 贴图（map）已由 engine 设置好，这里只写参数与注入。
 * 注意：本项目的 atlas 里刀柄已按皮肤着色，所以默认**不**启用刀柄遮罩；
 * 只有用户手动微调刀柄（handleGain/tint/desat 非中性）时才注入。
 */
function applyMaterialState(material, M, opts = {}) {
  const orig = material.userData.orig;
  if (!orig) return null;
  const applied = computeApplied(orig, M);

  // 「区域顶点属性」hook：aRegion/aBladeT/aEdge 的**唯一**声明点，恒装不撤。
  // （bladeMask 启用/停用、bladeSkin 挂上/摘下都不影响这些属性的声明，
  //   否则会出现 undeclared 或 redefinition —— 两个都实测踩过）
  setBladeAttrs(material);

  // clearcoat / iridescence 从 0→>0 会改变 USE_CLEARCOAT / USE_IRIDESCENCE 宏，
  // 需要重编译；其余都是 uniform，不需要
  const hadCC = material.clearcoat > 0;
  const hasCC = applied.clearcoat > 0;
  const hadIR = (material.iridescence || 0) > 0;
  const hasIR = applied.iridescence > 0;

  material.roughness = applied.roughness;
  material.metalness = applied.metalness;
  material.envMapIntensity = applied.envMapIntensity;
  material.color.copy(orig.color).lerp(WEAR_TINT, 0.6 * applied.wear)
    .multiply(colorFromSpec(M.baseColor));
  material.normalScale.set(applied.normalScaleX, applied.normalScaleY);
  material.clearcoat = applied.clearcoat;
  material.clearcoatRoughness = applied.clearcoatRoughness;
  material.iridescence = applied.iridescence;
  material.iridescenceIOR = applied.iridescenceIOR;

  setPatternStrength(material, applied.patternStrength, colorFromSpec(M.baseColor));

  // P4 Damascus：pattern roughness 变体（亮带抛光 / 暗带磨砂）
  setRoughPattern(material, opts.patternRoughMap || null, opts.patternRoughIntensity || 0);

  // 是否注入由调用方通过 bladeMask.active 决定（皮肤有 handle 配方 或 用户调过）
  // 遮罩贴图：有皮肤时用 atlas 的 metal 贴图（A 通道=刀柄分区，更准），
  //           否则退回模型自带 ORM（B 通道）。由 engine.applySkin 记录在 userData。
  setBladeMask(
    material, M.bladeMask, orig.map,
    material.userData.maskTex || orig.metalnessMap,
    !!material.userData.maskAlpha,
  );

  if ((hadCC !== hasCC) || (hadIR !== hasIR)) material.needsUpdate = true;
  return applied;
}

/** 清掉材质的 program 缓存（three r169：命中缓存不会重跑 onBeforeCompile）。 */
function invalidateHookProgram(renderer, material) {
  if (!material.userData || !material.userData.__hooksDirty) return;
  material.userData.__hooksDirty = false;
  const props = renderer && renderer.properties ? renderer.properties.get(material) : null;
  if (props) props.programs = undefined;
  material.needsUpdate = true;
}

K3D.material = {
  MATERIAL_DEFAULTS, MATERIAL_LIMITS, WEAR_TINT,
  normalizeMaterial, deepMerge, colorFromSpec,
  toPhysicalMaterial, computeApplied, applyMaterialState,
  invalidateHookProgram, defaultMaterial: () => ({ ...MATERIAL_DEFAULTS }),
  // hook 管理器（BladeSkin 皮肤系统要用它挂 bladeSkin 注入；多注入点共存不互相覆盖）
  upsertHook, removeHook, hookMap,
  // 区域顶点属性（aRegion/aBladeT/aEdge）的唯一声明 hook，bladeSkin 侧挂 hook 前需确认已装
  setBladeAttrs,
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = K3D.material;
}
})(typeof window !== 'undefined' ? window : globalThis);
