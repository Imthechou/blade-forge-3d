/* Knife3D · skins.js
 * 皮肤配方层。
 *
 * 每套皮肤 = 花纹（3D 程序化，与刀型无关）+ 刀柄暗色调（handleTone）+ 材质微调。
 * 刀身配色沿用 cs2-knife-viewer 项目里「按原生贴图实测主色」标定的一组值，
 * 保证同一套皮肤在任何刀型上颜色一致。
 *
 * 刀柄暗色派生规则 deriveHandle(primaryHex)：
 *   亮度 ×0.30、饱和度 ×0.45、色相略偏冷 —— 得到「同色系但压暗的金属件」观感。
 *   皮肤配方里可显式写 handleTone 覆盖自动派生。
 */
(function (global) {
'use strict';
const K3D = (global.K3D = global.K3D || {});

/** '#rrggbb' → [h(0..1), s, v] */
function rgbToHsv(hex) {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const d = max - min;
  let h = 0;
  if (d > 0) {
    if (max === r) h = ((g - b) / d) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h /= 6;
    if (h < 0) h += 1;
  }
  return [h, max === 0 ? 0 : d / max, max];
}

function hsvToRgb(h, s, v) {
  const i = Math.floor(h * 6);
  const f = h * 6 - i;
  const p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
  const m = [[v, t, p], [q, v, p], [p, v, t], [p, q, v], [t, p, v], [v, p, q]][i % 6];
  return m;
}
/** [r,g,b]（0..1）→ '#rrggbb'（护手/刀柄色调都以 hex 形式存放） */
function rgbToHex(rgb) {
  const c = (x) => Math.max(0, Math.min(255, Math.round(x * 255))).toString(16).padStart(2, '0');
  return '#' + c(rgb[0]) + c(rgb[1]) + c(rgb[2]);
}

const to2 = (n) => Math.round(clamp01(n) * 255).toString(16).padStart(2, '0');
function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

/** 由刀身主色派生刀柄暗色（返回 [r,g,b] 0..1）。 */
function deriveHandle(primaryHex, opts = {}) {
  const [h, s, v] = rgbToHsv(primaryHex);
  // 色相略向冷端偏移（+0.55 圈内取补间偏冷的一侧），饱和度与亮度压低
  const hue = (h + (opts.hueShift ?? 0.55)) % 1;
  const sat = s * (opts.satMul ?? 0.45);
  const val = v * (opts.valMul ?? 0.30) + (opts.valAdd ?? 0.06);
  return hsvToRgb(hue, sat, val);
}

/** 刀柄色调 → material.js 使用的 bladeMask.handleTint/handleGain/handleDesat。 */
function toneToMask(tone) {
  if (!tone) return null;
  return {
    handleGain: tone.gain ?? 1,
    handleTint: tone.tintHex ?? '#ffffff',
    handleDesat: tone.desat ?? 0,
  };
}

/*
 * 工艺（Finish）定义表。
 * 每个 Finish = PBR 材质 profile + 默认纹理引用（可选）+ 刀柄默认色调。
 * 与 Texture 解耦：同一个 Finish 可配不同的 Texture。
 */
const FINISHES = [
  {
    id: 'patina', name: '包浆氧化', nameEn: 'Patina',
    finishStyle: 'patina',
    defaultTexture: null,   // 由皮肤层指定
    handle: { gain: 1, tintHex: '#8e99a6', desat: 0.55 },
    // 降膜感（iridescence）+ 降金属度让直接光照参与塑形 + 提粗糙度扩散反射 → 刃口有明暗层次
    material: { metalness: 0.85, roughness: 0.34, iridescence: 0.10, iridescenceIOR: 1.5, reflection: 0.95 },
  },
  {
    id: 'fade', name: '渐变涂层', nameEn: 'Fade',
    finishStyle: 'fade',
    defaultTexture: 'fade_tex',
    handle: { gain: 0.95, tintHex: '#6f7d92', desat: 0.50 },
    // clearcoat 0.2→0.05 去掉蜡釉感；iridescence 0.3→0.10 去彩色膜；metalness 降到 0.72 让光照塑形；roughness 提至 0.32 让起伏显现
    material: { metalness: 0.72, roughness: 0.32, clearcoat: 0.05, clearcoatRoughness: 0.10, iridescence: 0.10, iridescenceIOR: 1.6, reflection: 0.95 },
  },
  {
    id: 'anodized_multicolored', name: '阳极着色', nameEn: 'Anodized',
    finishStyle: 'anodized_multicolored',
    defaultTexture: 'doppler_tex',
    handle: { gain: 0.8, tintHex: '#2a3550', desat: 0.55 },
    // 阳极是**介电薄膜**（真品 metalness≈0），保留其招牌虹彩但降到 0.30；去 wax clearcoat；metalness 降到 0.6 让漫反射出层次
    material: { metalness: 0.60, roughness: 0.30, clearcoat: 0.08, clearcoatRoughness: 0.08, iridescence: 0.30, iridescenceIOR: 1.8, reflection: 1.0 },
  },
  {
    id: 'solid', name: '纯色金属', nameEn: 'Solid',
    finishStyle: 'solid',
    defaultTexture: 'black_steel_tex',
    handle: { gain: 0.85, tintHex: '#2a2d33', desat: 0.55 },
    // 纯金属保持较高金属度（本就该平），微降 reflection + 靠曲率 AO/roughness 出层次
    material: { metalness: 0.90, roughness: 0.34, reflection: 0.95 },
  },
];

/*
 * 皮肤定义（向后兼容包装层）。
 * 每个 Skin = 一个 Finish 引用 + 可选 Texture 覆盖 + 可选 Handle 覆盖。
 * 新 UI 以 finishId 为主选，textureOverride 用于特定纹理组合。
 */
const SKINS = [
  { id: 'original', name: '原版', nameEn: 'Default' },
  // Patina 工艺族
  { id: 'blue_steel',    name: '蓝钢',        finish: 'patina',    texture: 'blue_steel_tex' },
  { id: 'case_hardened', name: '表面淬火',    finish: 'patina',    texture: 'case_hardened_tex', handle: { gain: 0.95, tintHex: '#7d8694', desat: 0.60 } },
  { id: 'slaughter',     name: '屠夫',        finish: 'patina',    texture: 'slaughter_tex',     handle: { gain: 0.9, tintHex: '#7a4038', desat: 0.55 } },
  { id: 'damascus',      name: '大马士革钢',  finish: 'patina',    texture: 'damascus_tex',     handle: { gain: 1, tintHex: '#8b929c', desat: 0.60 } },
  { id: 'autotronic',    name: '自动化',      finish: 'patina',    texture: 'autotronic_tex',   handle: { gain: 0.85, tintHex: '#5d6068', desat: 0.70 } },
  { id: 'marble_fade',   name: '大理石渐变',  finish: 'patina',    texture: 'marble_fade_tex',  handle: { gain: 0.95, tintHex: '#77808e', desat: 0.55 } },
  { id: 'ultraviolet',   name: '紫罗兰',      finish: 'patina',    texture: 'ultraviolet_tex',  handle: { gain: 0.8, tintHex: '#3d2c50', desat: 0.45 } },
  // Fade 工艺
  { id: 'fade', name: '渐变之色', finish: 'fade', texture: 'fade_tex' },
  // Anodized 工艺族
  { id: 'doppler',       name: '多普勒',      finish: 'anodized_multicolored', texture: 'doppler_tex' },
  { id: 'doppler_purple',name: '多普勒·粉紫宝石', finish: 'anodized_multicolored', texture: 'doppler_purple_tex', handle: { gain: 0.75, tintHex: '#4a2a48', desat: 0.45 } },
  // Solid 工艺族
  { id: 'black_steel', name: '黑钢', finish: 'solid', texture: 'black_steel_tex' },
  { id: 'silver_steel', name: '银钢', finish: 'solid', texture: 'silver_steel_tex', handle: { gain: 0.8, tintHex: '#3a3f47', desat: 0.6 } },
  { id: 'gold',      name: '黄金',  finish: 'solid', texture: 'gold_tex',       handle: { gain: 0.75, tintHex: '#4a3a1e', desat: 0.5 } },
];

/**
 * 根据 finish ID + texture ID 派生最终材质 profile（合并默认 + 覆盖）。
 * 这是 engine.applySkin 和 effectiveParams 的核心查找逻辑。
 */
function resolveSkinProfile(skinId) {
  const s = SKINS.find((sk) => sk.id === skinId) || SKINS[0];
  if (s.id === 'original') return null;
  const fin = FINISHES.find((f) => f.id === s.finish) || FINISHES[0];
  // 纹理：优先用 skin 显式指定的，否则用 finish 的默认
  const texId = s.texture || fin.defaultTexture || null;
  // handle：skin 显式覆盖 > finish 默认
  const handle = { ...fin.handle, ...(s.handle || {}) };
  // material：直接取 finish 的（不变，由用户滑块单独覆盖）
  const material = { ...fin.material };
  return { finish: fin, texture: texId, handle, material };
}

/**
 * 刀柄默认质感（三层体系的 L3 层）。各皮肤只覆盖差异项，其余继承这里。
 * 刀柄是配件（聚合物/橡胶/涂层金属），默认取"哑光弱金属"：
 *   金属度 0.35 / 粗糙度 0.62 / 反射 1.0
 * 刀身才是高金属度（1.0），两层互不干扰、可分别调整。
 */
const HANDLE_DEFAULTS = Object.freeze({
  gain: 1, tintHex: '#ffffff', desat: 0,
  metalness: 0.35, roughness: 0.62, reflection: 1.0,
  material: null,           // 刀柄材质默认关闭（回退到三层体系后的「模型贴图+色调」；材质预设仍可手动选）
});

/**
 * 12 种刀柄材质预设。每项 = 「颜色 + 质感 + 程序化纹理」。
 * 纹理 kind 对应 atlas.js 的 HANDLE_KINDS（灰度结构），颜色由 tintHex 给 ——
 * 所以换材质保留纹理结构、换色板保留材质，两者可自由组合。
 * 选中时一次性写入整组参数，之后每个滑块仍可单独微调（不锁死）。
 */
const HANDLE_MATERIALS = [
  { id: 'wood',     name: '木质',     tintHex: '#6b4423', desat: 0.15, gain: 1.00,
    metalness: 0.00, roughness: 0.75, reflection: 1.0, pattern: { kind: 'wood',     seed: 21 } },
  { id: 'jade',     name: '玉质',     tintHex: '#a8d8c0', desat: 0.10, gain: 1.05,
    metalness: 0.00, roughness: 0.25, reflection: 1.2, pattern: { kind: 'jade',     seed: 22 } },
  { id: 'bamboo',   name: '竹质',     tintHex: '#c4b05a', desat: 0.12, gain: 1.00,
    metalness: 0.00, roughness: 0.55, reflection: 1.1, pattern: { kind: 'bamboo',   seed: 23 } },
  { id: 'leather',  name: '皮革',     tintHex: '#3d2418', desat: 0.20, gain: 0.95,
    metalness: 0.00, roughness: 0.85, reflection: 0.9, pattern: { kind: 'leather',  seed: 24 } },
  { id: 'carbon',   name: '碳纤维',   tintHex: '#2a2a2e', desat: 0.25, gain: 1.00,
    metalness: 0.50, roughness: 0.35, reflection: 1.3, pattern: { kind: 'carbon',   seed: 25 } },
  { id: 'machined', name: '机械',     tintHex: '#8a9099', desat: 0.30, gain: 1.00,
    metalness: 0.90, roughness: 0.45, reflection: 1.2, pattern: { kind: 'machined', seed: 26 } },
  { id: 'polymer',  name: '聚合物',   tintHex: '#7a8089', desat: 0.35, gain: 1.00,
    metalness: 0.10, roughness: 0.60, reflection: 1.0, pattern: { kind: 'polymer',  seed: 27 } },
  { id: 'brushed',  name: '拉丝金属', tintHex: '#b8bcc2', desat: 0.30, gain: 1.00,
    metalness: 0.95, roughness: 0.35, reflection: 1.3, pattern: { kind: 'brushed',  seed: 28 } },
  { id: 'ceramic',  name: '陶瓷',     tintHex: '#f0efe9', desat: 0.20, gain: 1.05,
    metalness: 0.00, roughness: 0.15, reflection: 1.3, pattern: { kind: 'ceramic',  seed: 29 } },
  { id: 'marble',   name: '大理石',   tintHex: '#e8e6e0', desat: 0.25, gain: 1.00,
    metalness: 0.00, roughness: 0.30, reflection: 1.2, pattern: { kind: 'marble',   seed: 30 } },
  { id: 'rubber',   name: '橡胶',     tintHex: '#26262a', desat: 0.30, gain: 0.90,
    metalness: 0.00, roughness: 0.90, reflection: 0.8, pattern: { kind: 'rubber',   seed: 31 } },
  { id: 'g10',      name: 'G10 战术', tintHex: '#4a5240', desat: 0.20, gain: 1.00,
    metalness: 0.20, roughness: 0.55, reflection: 1.0, pattern: { kind: 'g10',      seed: 32 } },
];

// 注：早期用手写 BLADE_GAIN 补偿深色皮肤亮度，已被 atlas.js 的 targetLum 自动归一化取代，移除。
/**
 * 护手+尾部默认材质（区域 1）。护手多为金属件，默认取「亮钢」：
 *   金属度 1.0 / 粗糙度 0.35，白色基色（沿用模型贴图明暗）。
 */
const GUARD_DEFAULTS = Object.freeze({
  // ⚠ roughness 0.35 → 0.60：护手/尾部常落在模型自带的**亮金属**上，
  //   低粗糙度＝镜面反射整个环境 → 在皮肤旁边读作一条惨白（用户报的"块与块之间发白"）。
  //   实测（tools/region_brightness.js，karambit）：护手区亮度 >0.40 的像素占比 34.9% → 12.2%。
  //   desat 也上调一点（金属灰更中性、不抢皮肤色）。
  gain: 0.92, tintHex: '#4a4e55', desat: 0.66,
  metalness: 1.0, roughness: 0.60, reflection: 1.0,
});

K3D.skins = {
  SKINS,
  FINISHES,
  HANDLE_DEFAULTS,
  HANDLE_MATERIALS,
  GUARD_DEFAULTS,
  deriveHandle,
  toneToMask,
  /**
   * 解析皮肤配方：合并 Finish 默认 + Skin 覆盖。
   * 返回对象保持向后兼容字段（texture/material/handle/finishStyle），
   * 同时暴露新的 finish 字段。
   */
  resolve: resolveSkinProfile,
  /** 某套皮肤最终生效的护手+尾部配置（默认 + 用户覆盖） */
  guardOf: (userOverride = {}, handleTone = null) => {
    const o = { ...GUARD_DEFAULTS };
    // ── 护手默认色**跟随皮肤** ─────────────────────────────────────
    // 以前所有皮肤共用同一个中性灰 tintHex('#4a4e55')，于是护手/尾部那块金属在彩色皮肤
    // 旁边永远读作"没上漆的白块"（用户报的"块与块之间的连接处发白"）。
    // 现在取该皮肤刀柄色调的**色相**，但把亮度压到 0.32、饱和度封顶 0.35：
    //   → "同族的暗金属"（跟皮肤是一家人），又不会因为亮/艳而在皮肤旁边发白。
    // ⚠ 亮度必须压住：早先版本乘了 1.25 提亮，结果护手比原来更白（实测发白占比 0.5%→29.8%）。
    const hex = handleTone && handleTone.tintHex;
    if (typeof hex === 'string' && /^#[0-9a-f]{6}$/i.test(hex)) {
      const [h, s] = rgbToHsv(hex);
      o.tintHex = rgbToHex(hsvToRgb(h, Math.min(0.35, s * 0.6), 0.32));
    }
    for (const [k, v] of Object.entries(userOverride)) if (v !== undefined && v !== null) o[k] = v;
    return o;
  },
  /** 按 id 取刀柄材质预设（id 为空 → null，即不启用程序化刀柄纹理） */
  materialOf: (id) => (id ? (HANDLE_MATERIALS.find((m) => m.id === id) || null) : null),
  /** 某套皮肤最终生效的刀柄配置（默认 + 皮肤覆盖 + 用户覆盖） */
  handleOf: (skinId, userOverride = {}) => {
    const profile = K3D.skins.resolve(skinId);
    const o = { ...HANDLE_DEFAULTS, ...(profile ? profile.handle : {}) };
    for (const [k, v] of Object.entries(userOverride)) if (v !== undefined && v !== null) o[k] = v;
    return o;
  },
  /**
   * 向后兼容入口：返回带 material/handle/texture/finishStyle 的对象。
   * 内部调用 resolve() 完成合并。
   */
  get: (id) => {
    const s = SKINS.find((sk) => sk.id === id) || SKINS[0];
    if (s.id === 'original') return s;
    const p = resolveSkinProfile(id);
    return {
      id: s.id, name: s.name, nameEn: s.nameEn,
      finish: p.finish,
      finishStyle: p.finish.finishStyle,
      texture: p.texture,
      handle: p.handle,
      material: p.material,
    };
  },
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = K3D.skins;
}
})(typeof window !== 'undefined' ? window : globalThis);
